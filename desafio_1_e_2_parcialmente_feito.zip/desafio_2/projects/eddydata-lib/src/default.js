function atualizarMascarasData() {
    for (const input_calendar_primeng of $('span.ui-calendar input')) {
        IMask(input_calendar_primeng, {
            mask: [
                {
                    mask: 'd/m/a',
                    blocks: {
                        d: { mask: IMask.MaskedRange, from: 1, to: 31, maxLength: 2 },
                        m: { mask: IMask.MaskedRange, from: 1, to: 12, maxLength: 2 },
                        a: { mask: IMask.MaskedRange, from: 1900, to: 2100, maxLength: 4 }
                    }
                },
                {
                    mask: /[0-9]{2,2,4}$/i
                }
            ]
        });
    }
}

function convertEnterParaTab() {
    $('body:not(.login2background)').on('keydown', 'input:not(.ui-autocomplete-input), select', function (e) {
        var self = $(this)
            , form = self.parents('form:not(#login-form):eq(0)')
            , focusable
            , next
            ;
        if (e.keyCode === 13) {
            focusable = form.find('input,a,select,textarea').filter(':visible');
            next = focusable.eq(focusable.index(this) + 1);
            if (next.length) {
                next.focus();
            }
            return false;
        }
    });
    $('body:not(.login2background)').on('keydown', '.ui-autocomplete-input', function (e) {
        var self = $(this)
            , form = self.parents('form:not(#login-form):eq(0)')
            , focusable
            , next
            ;
        if (e.keyCode === 13 && (e.value === '' || !e.value)) {
            focusable = form.find('input,a,select,textarea').filter(':visible');
            next = focusable.eq(focusable.index(this) + 1);
            if (next.length) {
                next.focus();
            }
            return false;
        }
    });
}