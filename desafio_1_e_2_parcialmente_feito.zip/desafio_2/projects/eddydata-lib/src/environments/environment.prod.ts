export const environment = {
  production: true,
  url: 'http://localhost:3001/api/v1/dev/',
  orgao: '020000',
  cidade: 1
};
