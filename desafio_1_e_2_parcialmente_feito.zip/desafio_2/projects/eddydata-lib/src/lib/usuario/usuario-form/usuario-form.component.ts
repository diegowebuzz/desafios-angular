import { Component, ElementRef, Injector, ViewChild } from '@angular/core';
import { Validators } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { takeUntil } from 'rxjs/operators';
import { UsuarioService } from '../service/usuario.service';
import * as toastr from 'toastr';
import { BaseResourceFormComponent } from '../../models/base-resource-form';
import { Usuario } from '../../entidade/comum/usuario.model';
import { LoginContabil } from '../../entidade/login/login-contabil';
import { EddyAutoComplete } from '../../models/form-components';
import { Setor } from '../../entidade/almoxarifado/setor.model';
import { Sistemas } from '../../components/types';
import { Acesso } from '../../entidade/comum/acesso.model';
import { GlobalService } from '../../util/global.service';
import { FuncaoService } from '../../util/funcao.service';
import {
  Comum, ControleInterno, Planejamento, Tesouraria,
  Compra, Contabilidade, Patrimonio, Protocolo,
  Almoxarifado, Pagina, DiarioOficial, Legislativo, TerceiroSetor, Folha, PortalEntidade, Transparencia
} from '../../entidade/comum/pagina';
import { SetorService } from '../../almoxarifado/setor/service/setor.service';
import { Favorecido } from '../../entidade/compra/favorecido.model';
import { Unidade } from '../../entidade/planejamento/unidade.model';
import { UnidadeService } from '../../unidade/service/unidade.service';
import { Estoque } from '../../entidade/almoxarifado/estoque.model';
import { EstoqueService } from '../../almoxarifado/estoque/service/estoque.service';
import { FavorecidoService } from '../../favorecido/service/favorecido.service';

@Component({
  selector: 'lib-usuario-form',
  templateUrl: './usuario-form.component.html'
})
export class UsuarioFormComponent extends BaseResourceFormComponent<Usuario, LoginContabil> {

  /**
   * Declaração de variáveis
   */
  @ViewChild('tipo_') inputField: ElementRef;

  public setorAutoComplete: EddyAutoComplete<Setor>;
  public estoqueAutoComplete: EddyAutoComplete<Estoque>;
  public unidadeAutoComplete: EddyAutoComplete<Unidade>;
  public favorecidoAutoComplete: EddyAutoComplete<Favorecido>;
  public acessos: { sistema: Sistemas, acessos: Acesso[] }[];
  public opcoesAcesso: any[] = [
    { label: 'Sem acesso', value: 0, icon: 'lock_break.png' },
    { label: 'Visualizar', value: 1, icon: 'zoom.png' },
    { label: 'Incluir/Alterar', value: 2, icon: 'pencil.png' }
  ];
  public listaSistemas: { id: Sistemas, nome: string }[];
  public listaUsuariosCC: Usuario[];
  public acessosCC: Acesso[];

  /**
   * Construtor com as injeções de dependencias
   */
  constructor(
    protected injector: Injector,
    protected messageService: MessageService,
    public globalService: GlobalService,
    protected funcaoService: FuncaoService,
    protected setorService: SetorService,
    protected estoqueService: EstoqueService,
    protected unidadeService: UnidadeService,
    protected favorecidoService: FavorecidoService,
    protected usuarioService: UsuarioService) {
    super(new Usuario(), injector, Usuario.converteJson, usuarioService);
  }


  protected criarCamposForm(): void {
    this.entidadeForm = this.fb.group({
      id: [null],
      nome: [null, [Validators.required, Validators.minLength(2)]],
      sobrenome: [null, [Validators.required, Validators.minLength(2)]],
      email: [null, [Validators.required, Validators.minLength(2)]],
      senha: [null],
      sistema: [null],
      cpf: [null, [Validators.required]],
      telefone: [null, [Validators.required]],
      ativo: [null],
      convidado: [null, [Validators.required]],
      administrador: [null, [Validators.required]],
      solicitacao: [null],
      setor: [null],
      estoque: [null],
      unidade: [null],
      favorecido: [null],
      orgao: [null, [Validators.required]],
      acessos: [null]
    });
  }

  protected parametrosExtras(): {} {
    return { relations: 'orgao,acessos,setor,estoque,favorecido,unidade' };
  }

  protected afterLoad() {
    this.preencherAcessos(this.entidade.acessos);
  }

  protected afterInit(): void {
    this.listaSistemas = this.globalService.obterListaSistemas();
    this.carregarAutoCompletes();
  }

  protected campoFoco(): ElementRef {
    return this.inputField;
  }

  protected beforeSubmit(): void {
    this.entidadeForm.get('acessos').setValue(this.unificarPermissoes());
  }

  protected afterSubmit(entidade: Usuario): void {
    this.mensagemSucesso = `Registro salvo com sucesso!`;
    if (this.currentActionRoute === 'novo' && this.login.redirecionar_liquidar_pagar
      && this.podeIncluir('/liquidacoes')) {
      this.router.navigate(['/liquidacoes', 'novo', entidade.id]);
    } else if (this.currentActionRoute === 'novo' && !this.limparTela) {
      this.router.navigate(['/empenhos', entidade.id, 'editar']);
    }
  }


  // ========================================================================
  //                            MÉTODOS DA CLASSE
  // ========================================================================

  public verificaCheck() {
    if (this.entidadeForm.get('administrador').value) {
      this.entidadeForm.get('convidado').setValue(false);
    }
    if (this.entidadeForm.get('convidado').value) {
      this.entidadeForm.get('administrador').setValue(false);
    }
  }

  private carregarAutoCompletes() {
    // autocomplete para setor
    this.setorAutoComplete = new EddyAutoComplete(this.entidadeForm.get('setor'), this.setorService,
      'id', ['codigo', 'nome'],
      { orgao_id: this.login.orgao.id, relations: 'unidade,orgao', orderBy: 'nome' }, { number: ['codigo'], text: ['nome'] });

    // autocomplete para estoque
    this.estoqueAutoComplete = new EddyAutoComplete(this.entidadeForm.get('estoque'), this.estoqueService,
      'id', ['nome'],
      { orgao_id: this.login.orgao.id, orderBy: 'nome' }, { text: ['nome'] });

    // autocomplete para favorecido
    this.favorecidoAutoComplete = new EddyAutoComplete(this.entidadeForm.get('favorecido'), this.favorecidoService,
      'id', ['nome'], { cidade_id: this.login.cidade.id, orderBy: 'nome' }, { number: ['id', 'cpf_cnpj'], text: ['nome'] });

    // autocomplete para unidade administrativa 3 setor
    this.unidadeAutoComplete = new EddyAutoComplete(this.entidadeForm.get('unidade'), this.unidadeService,
      'id', ['codigo', 'nome'], { ppa_id: this.login.ppa.id, orderBy: 'nome' }, { number: ['codigo'], text: ['nome'] });
  }

  autorizar() {
    this.entidade.solicitacao = false;
    this.entidade.ativo = true;
    this.usuarioService.autorizar(this.entidade).pipe(takeUntil(this.unsubscribe))
      .subscribe(() => {
        this.entidadeForm.get('solicitacao').setValue(this.entidade.solicitacao);
        this.entidadeForm.get('ativo').setValue(this.entidade.ativo);
        this.submitForm();
      });
  }

  private unificarPermissoes(): Acesso[] {
    const retorno: Acesso[] = [];

    // unifica os acessos dos sistemas em um só para ser salvo
    for (const acesso of this.acessos) {
      for (const acessoPagina of acesso.acessos) {
        retorno.push(acessoPagina);
      }
    }

    return retorno;
  }

  public carregarUsuariosCC() {
    this.usuarioService.filtrar(1, -1, {
      'orgao.id': this.login.orgao.id,
      id$ne: this.entidade.id,
      convidado: false,
      relations: 'acessos',
      orderBy: 'nome'
    }).pipe(takeUntil(this.unsubscribe))
      .subscribe((res) => {
        this.listaUsuariosCC = res ? res.content : [];
      }, error => this.messageService.add({ severity: 'error', summary: 'Atenção', detail: error }));
  }

  public importarPermissoes() {
    if (!this.acessosCC || this.acessosCC.length === 0) {
      toastr.warning('Selecione o usuário a ter as suas permissões importadas!');
      return;
    }

    const acessos: Acesso[] = this.unificarPermissoes();

    for (const acessoCC of this.acessosCC) {
      for (const acesso of acessos) {
        if (acessoCC.pagina === acesso.pagina) {
          acesso.permissao = acessoCC.permissao;
        }
      }
    }

    this.preencherAcessos(acessos);

    toastr.info('Permissões importadas!');
  }

  public preencherAcessos(acessosEntidade: Acesso[]) {
    const acessosTotal: Acesso[] = [];

    // unifica todas as paginas em um objeto para percorrer do banco de dados e criar os que nao existirem
    let paginas = new Comum().paginas();
    paginas = paginas.concat(new ControleInterno().paginas());
    paginas = paginas.concat(new Planejamento().paginas());
    paginas = paginas.concat(new Tesouraria().paginas());
    paginas = paginas.concat(new Compra().paginas());
    paginas = paginas.concat(new Contabilidade().paginas());
    paginas = paginas.concat(new Patrimonio().paginas());
    paginas = paginas.concat(new Folha().paginas());
    paginas = paginas.concat(new Protocolo().paginas());
    paginas = paginas.concat(new Almoxarifado().paginas());
    paginas = paginas.concat(new DiarioOficial().paginas());
    paginas = paginas.concat(new Legislativo().paginas());
    paginas = paginas.concat(new TerceiroSetor().paginas());
    paginas = paginas.concat(new PortalEntidade().paginas());
    paginas = paginas.concat(new Transparencia().paginas());

    for (const pagina of paginas) {
      let encontrou = false;
      if (acessosEntidade) {
        for (const acesso of acessosEntidade) {
          if (acesso.pagina === Pagina[pagina]) {
            acesso.usuario = this.login.usuario;
            acesso.nomePagina = pagina;
            acessosTotal.push(acesso);
            encontrou = true;
            break;
          }
        }
      }
      if (!encontrou) {
        const acesso = new Acesso();
        acesso.id = null;
        acesso.pagina = Pagina[pagina];
        acesso.permissao = 0;
        acesso.usuario = this.login.usuario;
        acesso.nomePagina = pagina;
        acessosTotal.push(acesso);
      }
    }

    // atribuir os acessos por sistema
    this.acessos = [];
    let acessosSistema: Acesso[];
    // Comum
    acessosSistema = [];
    for (const pagina of new Comum().paginas()) {
      for (const acesso of acessosTotal) {
        if (acesso.pagina === Pagina[pagina]) {
          acessosSistema.push(acesso);
          break;
        }
      }
    }
    this.acessos.push({ sistema: 'comum', acessos: acessosSistema });

    // ControleInterno
    acessosSistema = [];
    for (const pagina of new ControleInterno().paginas()) {
      for (const acesso of acessosTotal) {
        if (acesso.pagina === Pagina[pagina]) {
          acessosSistema.push(acesso);
          break;
        }
      }
    }
    this.acessos.push({ sistema: 'controle-interno', acessos: acessosSistema });

    // Planejamento
    acessosSistema = [];
    for (const pagina of new Planejamento().paginas()) {
      for (const acesso of acessosTotal) {
        if (acesso.pagina === Pagina[pagina]) {
          acessosSistema.push(acesso);
          break;
        }
      }
    }
    this.acessos.push({ sistema: 'planejamento', acessos: acessosSistema });

    // Tesouraria
    acessosSistema = [];
    for (const pagina of new Tesouraria().paginas()) {
      for (const acesso of acessosTotal) {
        if (acesso.pagina === Pagina[pagina]) {
          acessosSistema.push(acesso);
          break;
        }
      }
    }
    this.acessos.push({ sistema: 'tesouraria', acessos: acessosSistema });

    // Compra
    acessosSistema = [];
    for (const pagina of new Compra().paginas()) {
      for (const acesso of acessosTotal) {
        if (acesso.pagina === Pagina[pagina]) {
          acessosSistema.push(acesso);
          break;
        }
      }
    }
    this.acessos.push({ sistema: 'compras', acessos: acessosSistema });

    // Contabilidade
    acessosSistema = [];
    for (const pagina of new Contabilidade().paginas()) {
      for (const acesso of acessosTotal) {
        if (acesso.pagina === Pagina[pagina]) {
          acessosSistema.push(acesso);
          break;
        }
      }
    }
    this.acessos.push({ sistema: 'contabil', acessos: acessosSistema });

    // Patrimonio
    acessosSistema = [];
    for (const pagina of new Patrimonio().paginas()) {
      for (const acesso of acessosTotal) {
        if (acesso.pagina === Pagina[pagina]) {
          acessosSistema.push(acesso);
          break;
        }
      }
    }
    this.acessos.push({ sistema: 'patrimonio', acessos: acessosSistema });

    // Protocolo
    acessosSistema = [];
    for (const pagina of new Protocolo().paginas()) {
      for (const acesso of acessosTotal) {
        if (acesso.pagina === Pagina[pagina]) {
          acessosSistema.push(acesso);
          break;
        }
      }
    }
    this.acessos.push({ sistema: 'protocolo', acessos: acessosSistema });

    // Almoxarifado
    acessosSistema = [];
    for (const pagina of new Almoxarifado().paginas()) {
      for (const acesso of acessosTotal) {
        if (acesso.pagina === Pagina[pagina]) {
          acessosSistema.push(acesso);
          break;
        }
      }
    }
    this.acessos.push({ sistema: 'almoxarifado', acessos: acessosSistema });

    // Folha
    acessosSistema = [];
    for (const pagina of new Folha().paginas()) {
      for (const acesso of acessosTotal) {
        if (acesso.pagina === Pagina[pagina]) {
          acessosSistema.push(acesso);
          break;
        }
      }
    }
    this.acessos.push({ sistema: 'recursos-humanos', acessos: acessosSistema });

    // DiarioOficial
    acessosSistema = [];
    for (const pagina of new DiarioOficial().paginas()) {
      for (const acesso of acessosTotal) {
        if (acesso.pagina === Pagina[pagina]) {
          acessosSistema.push(acesso);
          break;
        }
      }
    }
    this.acessos.push({ sistema: 'diario-oficial', acessos: acessosSistema });

    // Legislativo
    acessosSistema = [];
    for (const pagina of new Legislativo().paginas()) {
      for (const acesso of acessosTotal) {
        if (acesso.pagina === Pagina[pagina]) {
          acessosSistema.push(acesso);
          break;
        }
      }
    }
    this.acessos.push({ sistema: 'legislativo', acessos: acessosSistema });

    // TerceiroSetor
    acessosSistema = [];
    for (const pagina of new TerceiroSetor().paginas()) {
      for (const acesso of acessosTotal) {
        if (acesso.pagina === Pagina[pagina]) {
          acessosSistema.push(acesso);
          break;
        }
      }
    }
    this.acessos.push({ sistema: 'terceiro-setor', acessos: acessosSistema });

    // PortalEntidade
    acessosSistema = [];
    for (const pagina of new PortalEntidade().paginas()) {
      for (const acesso of acessosTotal) {
        if (acesso.pagina === Pagina[pagina]) {
          acessosSistema.push(acesso);
          break;
        }
      }
    }
    this.acessos.push({ sistema: 'portal-entidade', acessos: acessosSistema });

    // Transparência
    acessosSistema = [];
    for (const pagina of new Transparencia().paginas()) {
      for (const acesso of acessosTotal) {
        if (acesso.pagina === Pagina[pagina]) {
          acessosSistema.push(acesso);
          break;
        }
      }
    }
    this.acessos.push({ sistema: 'transparencia', acessos: acessosSistema });

    this.entidadeForm.get('acessos').setValue(this.acessos);
  }
}
