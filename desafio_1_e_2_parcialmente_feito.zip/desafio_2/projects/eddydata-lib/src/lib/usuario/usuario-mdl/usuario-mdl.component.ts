import { Component, Injector, Input, OnChanges, SimpleChanges } from '@angular/core';
import { Observable } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import * as toastr from 'toastr';
import { Coluna, FormatoExportacao } from '../../components/types';
import { Usuario } from '../../entidade/comum/usuario.model';
import { LoginContabil } from '../../entidade/login/login-contabil';
import { BaseResourceListComponent, Filtro } from '../../models/base-resource-list';
import { GlobalService } from '../../util/global.service';
import { UsuarioService } from '../service/usuario.service';

declare var $: any;

@Component({
  selector: 'lib-usuario-mdl',
  templateUrl: './usuario-mdl.component.html'
})
export class UsuarioMdlComponent extends BaseResourceListComponent<Usuario, LoginContabil> {

  /**
   * Declaração de variáveis
   */
  public filtro: string;
  public usuario: Usuario = new Usuario();
  @Input() public titulo : string = 'Usuários';

  public _setor: number;
  

  @Input() set setor(val: number) {
    this._setor = val;
    super.ngOnInit();
  };

  /**
   * Construtor com as injeções de dependencias
   */
  constructor(
    protected injector: Injector,
    public globalService: GlobalService,
    private usuarioService: UsuarioService) {
    super(usuarioService, injector);
  }


  // ========================================================================
  //                        MÉTODOS ABSTRAÍDOS
  // ========================================================================

  ngOnInit(){}

  protected relations(): string {
    return 'orgao,favorecido';
  }

  protected condicoesGrid(): {} {
    let parametros: {} = {};
    if (this._setor)
      parametros['setor.id'] = this._setor;
    parametros['orgao.id'] = this.login.orgao.id;
    return parametros;
  }

  protected ordenacaoGrid(): string[] {
    return ['id$DESC'];
  }

  protected filtrosGrid(): Filtro {
    return {
      number: ['id', 'cpf'],
      text: ['nome', 'sobrenome', 'email', 'telefone', 'sistema']
    };
  }

  protected afterInit(): void {
  }

  protected acaoRemover(model: Usuario): Observable<Usuario> {
    return null;
  }

  protected colunasRelatorio(): string[] | Coluna[] {
    return null;
  }

  // ========================================================================
  //                            MÉTODOS DA CLASSE
  // ========================================================================


}

export const abrirModalListagemUsuarios = () => {
  $('#dialog_mdl_usuario').modal('show');
}
