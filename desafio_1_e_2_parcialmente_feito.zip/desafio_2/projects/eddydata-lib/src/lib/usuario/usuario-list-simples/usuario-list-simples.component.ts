import { Component, Injector, Input } from '@angular/core';
import { Observable } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Coluna, FormatoExportacao } from '../../components/types';
import { Usuario } from '../../entidade/comum/usuario.model';
import { LoginContabil } from '../../entidade/login/login-contabil';
import { BaseResourceListComponent, Filtro } from '../../models/base-resource-list';
import { GlobalService } from '../../util/global.service';
import { UsuarioService } from '../service/usuario.service';

@Component({
  selector: 'lib-usuario-list-simples',
  templateUrl: './usuario-list-simples.component.html'
})
export class UsuarioListSimplesComponent extends BaseResourceListComponent<Usuario, LoginContabil> {

  /**
   * Declaração de variáveis
   */
  public filtro: string;
  public usuario: Usuario = new Usuario();

  public _parametros: {} ;

  @Input() set parametros(val : {}){
    this._parametros = val;
    this.ngOnInit();
  }

  /**
   * Construtor com as injeções de dependencias
   */
  constructor(
    protected injector: Injector,
    public globalService: GlobalService,
    private usuarioService: UsuarioService) {
    super(usuarioService, injector);
  }

  // ========================================================================
  //                        MÉTODOS ABSTRAÍDOS
  // ========================================================================

  protected relations(): string {
    return 'orgao,favorecido';
  }

  protected condicoesGrid(): {} {
    if (!this._parametros)
      this._parametros = {};
    this._parametros['orgao.id'] = this.login.orgao.id;
    return this._parametros;
  }

  protected ordenacaoGrid(): string[] {
    return ['id$DESC'];
  }

  protected filtrosGrid(): Filtro {
    return {
      number: ['id', 'cpf'],
      text: ['nome', 'sobrenome', 'email', 'telefone', 'sistema']
    };
  }

  protected afterInit(): void {
  }

  protected acaoRemover(model: Usuario): Observable<Usuario> {
    return null;
  }

  protected colunasRelatorio(): string[] | Coluna[] {
    return [
      { titulo: 'Sistema', coluna: 'sistema', agrupar: true },
      { titulo: 'id', coluna: 'id' },
      { titulo: 'Nome', coluna: 'nome' },
      { titulo: 'Sobrenome', coluna: 'sobrenome' },
      { titulo: 'E-mail', coluna: 'email' },
      { titulo: 'CPF', coluna: 'cpf' },
      { titulo: 'Telefone', coluna: 'telefone' }
    ];
  }

  public exportarListagem(formato: FormatoExportacao) {
    const parametros = this.obterParametros();
    parametros['relations'] = 'orgao';
    this.usuarioService
      .filtrar(1, -1,
        parametros
      )
      .pipe(takeUntil(this.unsubscribe))
      .subscribe(
        lista => {
          if (formato === 'pdf') {
            this.imprimir('LISTAGEM DE USUÁRIOS',
              this.login.usuario.nome, this.login.orgao.nome, this.login.brasao, 'portrait',
              'Listagem usuarios', ['auto', '*', 'auto', 'auto', 'auto', 'auto'], lista.content);
          } else {
            this.exportar(formato, lista.content);
          }
        },
        () => alert('erro ao retornar lista')
      );
  }

  // ========================================================================
  //                            MÉTODOS DA CLASSE
  // ========================================================================

}
