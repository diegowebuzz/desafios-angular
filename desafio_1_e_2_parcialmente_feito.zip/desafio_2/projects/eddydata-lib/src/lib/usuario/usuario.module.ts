import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TabViewModule } from 'primeng/tabview';
import { SelectButtonModule } from 'primeng/selectbutton';
import { UsuarioRoutingModule } from './usuario-routing.module';
import { FormsModule } from '@angular/forms';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { AccordionModule } from 'primeng/accordion';
import { CalendarModule } from 'primeng/calendar';
import { SharedModule } from '../util/shared.module';
import { IMaskModule } from 'angular-imask';
import { UsuarioListComponent } from './usuario-list/usuario-list.component';
import { UsuarioFormComponent } from './usuario-form/usuario-form.component';
import { MessageService } from 'primeng/api';
import { UsuarioViewComponent } from './usuario-view/usuario-view.component';
import { UsuarioAcessoComponent } from './usuario-acesso/usuario-acesso.component';
import { UsuarioRegistroComponent } from './usuario-registro/usuario-registro.component';
import { UsuarioMdlComponent } from './usuario-mdl/usuario-mdl.component';
import { UsuarioListSimplesComponent } from './usuario-list-simples/usuario-list-simples.component';

@NgModule({
  declarations: [
    UsuarioListComponent,
    UsuarioFormComponent,
    UsuarioViewComponent,
    UsuarioAcessoComponent,
    UsuarioRegistroComponent,
    UsuarioMdlComponent,
    UsuarioListSimplesComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    UsuarioRoutingModule,
    AutoCompleteModule,
    AccordionModule,
    CalendarModule,
    IMaskModule,
    TabViewModule,
    SelectButtonModule
  ],
  exports: [
    UsuarioListComponent,
    UsuarioFormComponent,
    UsuarioRegistroComponent,
    UsuarioMdlComponent,
    UsuarioListSimplesComponent
  ],
  providers: [MessageService]
})
export class UsuarioModule { }
