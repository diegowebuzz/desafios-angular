import { Component, Injector, ElementRef } from '@angular/core';
import { UsuarioService } from '../service/usuario.service';
import { Validators } from '@angular/forms';
import { BaseResourceFormComponent } from '../../models/base-resource-form';
import { Usuario } from '../../entidade/comum/usuario.model';
import { LoginContabil } from '../../entidade/login/login-contabil';
import { GlobalService } from '../../util/global.service';

@Component({
  selector: 'lib-usuario-view',
  templateUrl: './usuario-view.component.html'
})
export class UsuarioViewComponent extends BaseResourceFormComponent<Usuario, LoginContabil> {

  /**
   * Declaração de variáveis
   */


  /**
   * Construtor com as injeções de dependencias
   */
  constructor(
    protected injector: Injector,
    protected globalService: GlobalService,
    protected usuarioService: UsuarioService) {
    super(new Usuario(), injector, Usuario.converteJson, usuarioService);
  }

  // ========================================================================
  //                        MÉTODOS ABSTRAÍDOS
  // ========================================================================

  protected criarCamposForm(): void {
    this.entidadeForm = this.fb.group({
      id: [null],
      nome: [null, [Validators.required, Validators.minLength(2)]],
      sobrenome: [null, [Validators.required, Validators.minLength(2)]],
      email: [null, [Validators.required, Validators.minLength(2)]],
      cpf: [null, [Validators.required]],
      telefone: [null, [Validators.required]],
      orgao: [null, [Validators.required]],
      administrador: [null, [Validators.required]]
    });
  }

  protected parametrosExtras(): {} {
    return { relations: 'orgao' };
  }

  protected afterLoad() {
  }

  protected afterInit(): void {
  }

  protected campoFoco(): ElementRef {
    return null;
  }

  protected beforeSubmit(): void {
  }

  protected afterSubmit(entidade: Usuario): void {
  }

  // ========================================================================
  //                            MÉTODOS DA CLASSE
  // ========================================================================


}
