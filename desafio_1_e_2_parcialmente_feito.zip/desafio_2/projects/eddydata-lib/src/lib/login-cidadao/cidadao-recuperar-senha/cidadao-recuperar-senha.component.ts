import { Component, Injector, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../../login/servico/login.service';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'lib-cidadao-recuperar-senha',
  templateUrl: './cidadao-recuperar-senha.component.html',
  styleUrls: ['./cidadao-recuperar-senha.component.css']
})
export class CidadaoRecuperarSenhaComponent implements OnInit {

  public msgs: string;
  public email: string;

  @Input() sistema: string;

  protected router: Router;

  constructor(
    protected injector: Injector,
    private messageService: MessageService,
    private authService: LoginService) {
    this.router = this.injector.get(Router);
  }

  ngOnInit() {
  }

  async enviarEmail() {
    try {
      const resultado = await this.authService.recuperarSenha(this.email);
      if (resultado && resultado.error) {
        this.msgs = resultado.error.message;
      } else {
        this.router.navigate([`${this.sistema}/recuperar-senha-sucesso`]);
      }
    } catch (ex) {
      this.messageService.add({ severity: 'error', summary: 'Atenção', detail: ex.error });
    }
  }

  voltar() {
    this.router.navigate([`${this.sistema}/login`]);
  }

}
