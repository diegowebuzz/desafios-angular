import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IMaskModule } from 'angular-imask';
import { AccordionModule } from 'primeng/accordion';
import { MessageService } from 'primeng/api';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { CalendarModule } from 'primeng/calendar';
import { ToastModule } from 'primeng/toast';
import { ExercicioFormComponent } from './exercicio-form/exercicio-form.component';
import { ExercicioListComponent } from './exercicio-list/exercicio-list.component';
import { ExercicioRoutingModule } from './exercicio-routing.module';
import { ExercicioViewComponent } from './exercicio-view/exercicio-view.component';
import { SharedModule } from '../util/shared.module';
import { TrocarExercicioComponent } from './trocar-exercicio/trocar-exercicio.component';


@NgModule({
  declarations: [ExercicioListComponent, ExercicioViewComponent, ExercicioFormComponent, TrocarExercicioComponent],
  imports: [
    CommonModule,
    ExercicioRoutingModule,
    SharedModule,
    FormsModule,
    AutoCompleteModule,
    AccordionModule,
    CalendarModule,
    IMaskModule,
    ToastModule,
  ],
  exports: [
    ExercicioListComponent,
    ExercicioViewComponent,
    ExercicioFormComponent,
    TrocarExercicioComponent
  ],
  providers: [MessageService]
})
export class ExercicioModule { }
