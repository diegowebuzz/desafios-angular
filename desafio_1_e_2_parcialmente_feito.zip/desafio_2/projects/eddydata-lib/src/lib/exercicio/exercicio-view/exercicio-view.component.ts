import { Component, Injector } from '@angular/core';
import { Validators } from '@angular/forms';
import { ExercicioService } from '../service/exercicio.service';
import { BaseResourceFormComponent } from '../../models/base-resource-form';
import { Exercicio } from '../../entidade/comum/exercicio.model';
import { LoginContabil } from '../../entidade/login/login-contabil';
import { GlobalService } from '../../util/global.service';
import { FuncaoService } from '../../util/funcao.service';

@Component({
  selector: 'lib-exercicio-view',
  templateUrl: './exercicio-view.component.html'
})
export class ExercicioViewComponent extends BaseResourceFormComponent<Exercicio, LoginContabil> {

  /**
   * Declaração de variáveis
   */
  public listaSistemas: { id: string, nome: string }[];
  public listaNaturezas: { id: string, nome: string }[];
  public listaSuperavits: { id: string, nome: string }[];
  public listaVariacoes: { id: string, nome: string }[];
  public listaEncerramentos: { id: string, nome: string }[];


  /**
   * Construtor com as injeções de dependencias
   */
  constructor(
    protected injector: Injector,
    protected globalService: GlobalService,
    protected planoService: ExercicioService) {
    super(new Exercicio(), injector, Exercicio.converteJson, planoService);
  }

  // ========================================================================
  //                        MÉTODOS ABSTRAÍDOS
  // ========================================================================

  protected criarCamposForm(): void {
    this.entidadeForm = this.fb.group({
      id: [null],
      codigo: [null, [Validators.required]],
      nome: [null, [Validators.required]],
      n1: [null],
      n2: [null],
      n3: [null],
      n4: [null],
      n5: [null],
      n6: [null],
      n7: [null],
      n8: [null],
      nivel: [null],
      escrituracao: [null, [Validators.required]],
      conta_consumo: [null],
      sistema: [null],
      encerramento: [null],
      natureza: [null],
      superavit_financeiro: [null],
      conta_corrente: [null],
      variacao: [null],
      descricao: [null],
      exercicio: [this.login.exercicio, [Validators.required]],
    });
  }

  protected afterLoad() {
  }

  protected parametrosExtras(): {} {
    return {};
  }

  protected afterInit(): void {
    this.listaSistemas = [
      { id: 'O', nome: 'Orçamentário' },
      { id: 'P', nome: 'Patrimonial' },
      { id: 'C', nome: 'Compensado' },
    ];
    this.listaNaturezas = [
      { id: 'D', nome: 'Débito' },
      { id: 'C', nome: 'Crédito' },
    ];
    this.listaSuperavits = [
      { id: 'F', nome: 'F' },
      { id: 'P', nome: 'P' },
    ];
    this.listaVariacoes = [
      { id: 'IS', nome: 'IS' },
      { id: 'NIS', nome: 'NIS' },
    ];
    this.listaEncerramentos = [
      { id: 'M12', nome: 'M12' },
      { id: 'M13', nome: 'M13' },
      { id: 'M14', nome: 'M14' },
      { id: 'NENC', nome: 'NENC' },
    ];
  }

  public valorSelect(tipo: 'S' | 'N' | 'F' | 'V' | 'E', valor: string): string {
    let lista: { id: string, nome: string }[];
    if (tipo === 'S') {
      lista = this.listaSistemas;
    } else if (tipo === 'N') {
      lista = this.listaNaturezas;
    } else if (tipo === 'F') {
      lista = this.listaSuperavits;
    } else if (tipo === 'V') {
      lista = this.listaVariacoes;
    } else {
      lista = this.listaEncerramentos;
    }

    let obj: { id: string, nome: string };
    obj = lista.find(({ id }) => id === valor);
    return obj ? obj.nome : '';
  }

  protected beforeSubmit(): void {
  }

  protected afterSubmit(entidade: Exercicio): void {
  }

}
