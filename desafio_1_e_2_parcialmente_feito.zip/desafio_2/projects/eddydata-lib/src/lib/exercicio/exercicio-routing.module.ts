import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ExercicioListComponent } from './exercicio-list/exercicio-list.component';
import { ExercicioFormComponent } from './exercicio-form/exercicio-form.component';
import { ExercicioViewComponent } from './exercicio-view/exercicio-view.component';
import { AuthGuard } from '../util/auth.guard';

const routes: Routes = [
  { path: '', component: ExercicioListComponent, canActivate: [AuthGuard] },
  { path: 'novo', component: ExercicioFormComponent, canActivate: [AuthGuard] },
  { path: ':id/editar', component: ExercicioFormComponent, canActivate: [AuthGuard] },
  { path: ':id/visualizar', component: ExercicioViewComponent, canActivate: [AuthGuard] }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ExercicioRoutingModule { }
