import { Component, OnInit, OnDestroy } from '@angular/core';
import { ExercicioService } from '../service/exercicio.service';
import { Router } from '@angular/router';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { Login } from '../../entidade/login/login';
import { Exercicio } from '../../entidade/comum/exercicio.model';
import { FuncaoService } from '../../util/funcao.service';

@Component({
  selector: 'lib-trocar-exercicio',
  templateUrl: './trocar-exercicio.component.html'
})
export class TrocarExercicioComponent implements OnInit, OnDestroy {

  public login: Login = new Login();
  public exercicio: Exercicio = new Exercicio();
  public listaExercicios: Array<any>;
  protected unsubscribe: Subject<void> = new Subject();

  constructor(
    protected router: Router,
    protected funcaoService: FuncaoService,
    private exercicioService: ExercicioService,
  ) { }

  ngOnInit() {
    this.login = JSON.parse(sessionStorage.getItem('login'));
    if (this.login) {
    this.exercicio = this.login.exercicio;
    this.exercicioService.obterTodosOrdenadoPorAno(this.login.cidade.id).pipe(takeUntil(this.unsubscribe))
      .subscribe(dados => {
        this.listaExercicios = dados.content;
      });
    }
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  enviar() {
    this.login.exercicio = this.exercicio;
    sessionStorage.setItem('meses_bar', '');
    sessionStorage.setItem('array1_bar', '');
    sessionStorage.setItem('array2_bar', '');
    sessionStorage.setItem('nomes_doughnut', '');
    sessionStorage.setItem('codigos_doughnut', '');
    sessionStorage.setItem('valores_doughnut', '');
    sessionStorage.setItem('meses_line', '');
    sessionStorage.setItem('array1_line', '');
    sessionStorage.setItem('array2_line', '');
    sessionStorage.setItem('nome_pie', '');
    sessionStorage.setItem('array_pie', '');
    sessionStorage.setItem('totalArrecadado', '');
    sessionStorage.setItem('totalEmpenhado', '');
    sessionStorage.setItem('totalLiquidado', '');
    sessionStorage.setItem('totalPago', '');
    sessionStorage.setItem('login', JSON.stringify(this.login));
    location.reload();
  }

  compareFn(c1: any, c2: any): boolean {
    return c1 && c2 ? c1.id === c2.id : c1 === c2;
  }

}
