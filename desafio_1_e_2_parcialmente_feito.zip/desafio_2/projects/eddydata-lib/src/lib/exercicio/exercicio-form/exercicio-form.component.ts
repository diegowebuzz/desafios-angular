import { Component, Injector } from '@angular/core';
import { Validators } from '@angular/forms';
import { takeUntil } from 'rxjs/operators';
import { BaseResourceFormComponent } from '../../models/base-resource-form';
import { Exercicio } from '../../entidade/comum/exercicio.model';
import { LoginContabil } from '../../entidade/login/login-contabil';
import { GlobalService } from '../../util/global.service';
import { ExercicioService } from '../service/exercicio.service';
import { Assinatura } from '../../entidade/comum/assinatura.model';


@Component({
  selector: 'lib-exercicio-form',
  templateUrl: './exercicio-form.component.html'
})
export class ExercicioFormComponent extends BaseResourceFormComponent<Exercicio, LoginContabil> {

  /**
   * Declaração de variáveis
   */


  /**
   * Construtor com as injeções de dependencias
   */
  constructor(
    protected injector: Injector,
    protected globalService: GlobalService,
    protected exercicioService: ExercicioService) {
    super(new Exercicio(), injector, Exercicio.converteJson, exercicioService);
  }

  // ========================================================================
  //                        MÉTODOS ABSTRAÍDOS
  // ========================================================================

  protected criarCamposForm(): void {
    this.entidadeForm = this.fb.group({
      id: [null],
      ano: [null, [Validators.required]],
      cidade: [this.login.cidade, [Validators.required]],
      assinatura: this.fb.group({
        id: [null],
        prefeito: ['-', [Validators.required]],
        cargoPrefeito: ['-', [Validators.required]],
        contador: ['-', [Validators.required]],
        cargoContador: ['-', [Validators.required]],
        tesoureiro: ['-', [Validators.required]],
        cargoTesoureiro: ['-', [Validators.required]],
        ordenador: ['-', [Validators.required]],
        cargoOrdenador: ['-', [Validators.required]],
        assinatura1: ['-', [Validators.required]],
        cargoAssinatura1: ['-', [Validators.required]],
        assinatura2: ['-', [Validators.required]],
        cargoAssinatura2: ['-', [Validators.required]],
        assinatura3: ['-', [Validators.required]],
        cargoAssinatura3: ['-', [Validators.required]],
        responsavelCompra: ['-', [Validators.required]],
        cargoCompra: [null, [Validators.required]],
        exercicio: [this.entidade, [Validators.required]],
        orgao: [this.login.orgao, [Validators.required]],
      })
    });
  }

  protected afterLoad() {
  }

  protected parametrosExtras(): {} {
    return { relations: 'assinatura' };
  }

  protected afterInit(): void {
    if (this.currentActionRoute === 'novo') {
      this.exercicioService.proximoAno(this.login.cidade.id)
        .pipe(takeUntil(this.unsubscribe))
        .subscribe((res) => {
          this.entidadeForm.get('ano').setValue(res);
        });
    }
  }

  protected beforeSubmit(): void {
  }

  protected afterSubmit(entidade: Exercicio): void {
    if (!this.limparTela) {
      if (!this.entidade.id && entidade.id) {
        this.router.navigate(['/exercicios', entidade.id, 'editar']);
      } else {
        this.criarCamposForm();
        this.loadResource();
      }
    }
  }

  public importarAssinaturas() {
    this.exercicioService.filtrar(0, 1, {
      ano$lt: this.entidadeForm.get('ano').value,
      relations: 'assinatura',
      orderBy: 'ano$DESC'
    })
      .pipe(takeUntil(this.unsubscribe))
      .subscribe((res) => {
        const anterior: Assinatura = res.content[0].assinatura;
        const atual: Assinatura = this.entidadeForm.get('assinatura').value;

        atual.assinatura1 = anterior.assinatura1;
        atual.assinatura2 = anterior.assinatura2;
        atual.assinatura3 = anterior.assinatura3;
        atual.cargoAssinatura1 = anterior.cargoAssinatura1;
        atual.cargoAssinatura2 = anterior.cargoAssinatura2;
        atual.cargoAssinatura3 = anterior.cargoAssinatura3;
        atual.cargoCompra = anterior.cargoCompra;
        atual.cargoContador = anterior.cargoContador;
        atual.cargoOrdenador = anterior.cargoOrdenador;
        atual.cargoPrefeito = anterior.cargoPrefeito;
        atual.cargoTesoureiro = anterior.cargoTesoureiro;
        atual.contador = anterior.contador;
        atual.ordenador = anterior.ordenador;
        atual.prefeito = anterior.prefeito;
        atual.responsavelCompra = anterior.responsavelCompra;
        atual.tesoureiro = anterior.tesoureiro;

        this.entidadeForm.get('assinatura').setValue(atual);
      });
  }

}
