import { Component, Injector } from '@angular/core';
import { Observable } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Coluna, FormatoExportacao } from '../../components/types';
import { Exercicio } from '../../entidade/comum/exercicio.model';
import { LoginContabil } from '../../entidade/login/login-contabil';
import { BaseResourceListComponent, Filtro } from '../../models/base-resource-list';
import { ExercicioService } from '../service/exercicio.service';

@Component({
  selector: 'lib-exercicio-list',
  templateUrl: './exercicio-list.component.html'
})
export class ExercicioListComponent extends BaseResourceListComponent<Exercicio, LoginContabil> {

  /**
   * Declaração de variáveis
   */

  /**
   * Construtor com as injeções de dependencias
   */
  constructor(
    protected injector: Injector,
    private exService: ExercicioService) {
    super(exService, injector);
  }

  // ========================================================================
  //                        MÉTODOS ABSTRAÍDOS
  // ========================================================================

  protected relations(): string {
    return 'assinatura,assinatura.orgao';
  }

  protected condicoesGrid(): {} {
    return {
      ['cidade.id']: this.login.cidade.id,
      ['assinatura.orgao.id']: this.login.orgao.id
    };
  }

  protected ordenacaoGrid(): string[] {
    return ['ano$DESC'];
  }

  protected filtrosGrid(): Filtro {
    return {
      number: ['ano'],
      text: ['assinatura.prefeito', 'assinatura.contador', 'assinatura.tesoureiro']
    };
  }

  protected afterInit(): void {
  }

  protected acaoRemover(model: Exercicio): Observable<Exercicio> {
    return null;
  }

  protected colunasRelatorio(): string[] | Coluna[] {
    return [
      { titulo: 'Ano', coluna: 'ano' },
      { titulo: 'Prefeito', coluna: 'assinatura.prefeito' },
      { titulo: 'Contador', coluna: 'assinatura.contador' },
      { titulo: 'Tesoureiro', coluna: 'assinatura.tesoureiro' },
    ];
  }

  public exportarListagem(formato: FormatoExportacao) {
    const parametros = this.obterParametros();
    parametros['relations'] = 'assinatura';
    this.exService
      .filtrar(1, -1,
        parametros
      )
      .pipe(takeUntil(this.unsubscribe))
      .subscribe(
        lista => {
          if (formato === 'pdf') {
            this.imprimir('LISTAGEM DE EXERCÍCIOS',
              this.login.usuario.nome, this.login.orgao.nome, this.login.brasao, 'landscape',
              'Listagem exercícios', ['auto', '*', '*', '*'], lista.content);
          } else {
            this.exportar(formato, lista.content);
          }
        },
        () => alert('erro ao retornar lista')
      );
  }

  // ========================================================================
  //                            MÉTODOS DA CLASSE
  // ========================================================================

}
