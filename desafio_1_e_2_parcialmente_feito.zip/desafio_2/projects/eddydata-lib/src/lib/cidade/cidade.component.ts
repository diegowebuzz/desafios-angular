import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-cidade',
  templateUrl: './cidade.component.html'
})
export class CidadeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
