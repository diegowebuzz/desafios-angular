import { Relatorio } from '../components/report';
import { Boleto } from './boleto';
import { BancoBrasil } from './banco/banco-brasil';
import { BancoReal } from './banco/banco-real';
import { Bancoob } from './banco/bancoob';
import { Bradesco } from './banco/bradesco';
import { CaixaEconomicaNovo } from './banco/caixa-economica-novo';
import { Hsbc } from './banco/hsbc';
import { Itau } from './banco/itau';
import { Santander } from './banco/santander';
import { RelatorioBoleto } from './relatorio-boleto';
import JsBarCode from 'jsbarcode';
import { ContaBancaria } from '../entidade/tesouraria/conta-bancaria.model';
import { Banco } from '../entidade/tesouraria/banco.model';

export class ImprimirBoleto {
  static imprimir(conta: ContaBancaria, boletos: Boleto[]) {
    const relatorio = new RelatorioBoleto(this.getBanco(conta.banco));
    for (const boleto of boletos) {
      relatorio.addBoleto(boleto);
    }
    Relatorio.imprimirPersonalizado('Boleto', '', '', null,
      this.montarConteudo(relatorio, conta.banco), 'portrait', 'boleto', null, true, true);
  }

  private static getBanco(conta: Banco) {
    // tslint:disable-next-line: radix
    switch (Number.parseInt(conta.febraban)) {
      case 1:
        return new BancoBrasil();
        break;
      case 356:
        return new BancoReal();
        break;
      case 756:
        return new Bancoob();
        break;
      case 237:
        return new Bradesco();
        break;
      case 104:
        return new CaixaEconomicaNovo();
        break;
      case 399:
        return new Hsbc();
        break;
      case 341:
        return new Itau();
        break;
      case 33:
        return new Santander();
        break;
    }
  }

  static montarConteudo(relatorio: RelatorioBoleto, banco: Banco): {}[] {
    let count = 0;
    const retorno: {}[] = [];
    for (const boleto of relatorio.getBoletos()) {
      let pageBreak = false;
      if (count > 2) {
        count = 0;
        pageBreak = true;
      }
      const canvas = document.createElement('CANVAS') as HTMLCanvasElement;
      JsBarCode(canvas, boleto.codbarra, { displayValue: false, format: 'ITF', width: 4, height: 150 });
      const img = canvas.toDataURL();
      const marginTop = (+count * 280);
      const marginLeft = 15;
      count++;
      if (pageBreak) {
        retorno.push({
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 106, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft, y: marginTop + 39 }, pageBreak: 'before'
        });
      } else {
        retorno.push({
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 106, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft, y: marginTop + 39 }
        });
      }
      retorno.push({
        // tslint:disable-next-line: max-line-length
        image: `data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCAAvANADAREAAhEBAxEB/8QAHAABAAEFAQEAAAAAAAAAAAAAAAYDBAUHCAkB/8QANBAAAQMDBAIABQMDAgcAAAAAAQIDBAUGBwAIERITIQkUIjFRFTJBFiNCcYEkQ0RhY8HR/8QAFwEBAQEBAAAAAAAAAAAAAAAAAAECA//EACARAQEBAAMBAQADAQEAAAAAAAABEQIhMRJBMlFhcSL/2gAMAwEAAhEDEQA/APVPQNA0DQNA0DQNA0DQNA0DQNA0DQNA0DQNA0DQNA0DQNA0DQWNIrlFuGH+o0CrwqlE8i2fPDkIeb8iFFK09kEjlKgQR9wQQdBcS5kSAwZM6UzHZSpKS46sISCpQSkcn1ySQB+SQNBW0DQNA0DQNA0DQNA0DQNA0DQNA0DQNA0DQNA0EDzDnLF+B7YcuvJ11RaTG4UIzBPeTMcA58bDQ+pxR/7ehzyoge9S3Fkt8eZGV99l57uL9gYdoF7x8NY5rUj5OXUpRcclSG1ev+JcZ/alQ+kMpUhvlRDjpT7Tm3XScfntIa7iDLGyXJciNtKzVT7zlsw0z63Ykx5t2ouNpRypa4SCPMOPqHiKX0pKeAQexZnibOU7SHHuR7Z305+tKs3hnOs2b/TUuLUmcbzG0NNu1KMttYMR/kNyQpaVkhxsPoAISFJ5Wl/KlnzHVG9fdHWdqlh0K8KLaUKvuVer/pi2ZUpTIbT4XHOw6gknlHH4961bjPGfTnirfEf3HWnY9Gyxde1KO1ZVZLSotTarCw0+lfJSAsIX4yrqeO6f9tZ+q18TzXZuIM42XmLDtMzZSHl0ugzoj8qR+oLQ2YXgWtD4dVz1AQppf1c8FICvsdal3tizLjJ2FmDFeU3JrWN8h2/cy6aG1S00uoNySwF9uhWEE9QeiuOfwdN0ss9UGc34dk3wcaMZOtly7A+uMaKmptGYHkpKlN+Lt27BIJ4459abDL6yEfJ+Opd9ScYxr2ort2w2g/IoiJiDNabKEuBSmuewHRxCuSPsoH+dXTP1CZu7nbNT7pNlzc32m1V0P/KraM9PjQ9zwUKdH9tKgQQQVDg+j71Nh81Nb4yjjnGlBZui/wC+KJQKVIWluPLnzUNNvrUkqCWyT/cUUgq4TyeAT9gTq6ZrEY1z9hbML78TGeS6DcEqMjyvRYkofMIb547lpXC+vJA7cccke/epLKWWevt/Z7wvi2sM2/kbJ1u25UpEZMxqLUZyGXFsKUpCXAlR5KSptY5/KTpshJayVh5ZxhlFiRIxxkC37lRE6/MCl1FqQpjt9u6UKJRzweOQOeNXdLLEbvHdBt4x/cC7UvHMlq0ursr8b8N2oILsdfHPV0JJ8R498L4+4/I1NhlqT1S/qMvG1SyRaFTp1dp8ekyanCkxJKXo0oNNqUOriCQUkp4JB/Ommd44Uxf8RzcvmlNWVi3a1T7j/Q0NLnpiVZfZkO9/H9KgCoq8a+Ank/SdZ+rW7wk9rbu1f4hNlZ7j3HT76oTVh1e1KearUFSZwXCMNLiW3HfIpKS30W42FJUPXccKPvizlrN443DF3X7ZJshuJGz7YKnXlBCEmvxhyo/YclfGrsT5qc3TfVmWPbi7vvC6qVRqG34+1Rmy0Mxx5CAj+4ohP1EgD3751UzVG0cj2BftvvXZZV6UWuUWOtxp6oQZrb0dpaEhSwpxJKUlKSCeT6BB00zEHnbt9sNNlOQpefLGS80opWlFaYcAIPBHKVEc/wC+psX5qX1bLGMqFecHHVZv6gwroqSUKh0d+e2iY+FlQR0aJ7HkpVx698HTTL6WtljGV8V6qWvZ1/UGt1eiqUmowoE9t96KUrKFeRCSSnhYKff8+tNMsSzVRqTczY+368caTVbik0aLbsMEoqk51LDsJ1Q4BjvfuS4fsEp5Kj66q+2pc/Vlu9PK2zYVvU2ZWkbTqa9DpVKeP6rmC9fEwukskEpTDHUJiLKAoAoC5TpUegb5CU4/463/AFSsloR11edtyQH5kErcuTNF5H5ZEBxwErMIOdvlVLAUUr4dmrK1dOn20/4X/XXnw+MY7PZb0u7rRvdvI2TIslx+ZUa9GLEthffkyIkV4lSUkkHz8rc5UQVI5LY1xxjlaqfF8hTZ2FLMagw35C03SFFLTJWQPlH/AGSPY/8Af+2nI4euXcmR9487ZvY9Hu+3KZGxBHEHxvUphDtSLPYhhUhtTnb0T6CQgFXUKI5Gs941M1vfJ2RbCsb4YtFtfCkWtts3Sf6eTHntH9QQ6t5b1RU8lH8K6up5H09XmwPRA1b4k/l2hm0S3K5tR3rUjGk8STRL8tOAw/Ic58Qmuwm5HJ49BQmNPsJB9gOD86TqnL/1Goc/2xkOJury5mOwWJHz2PLqj1tHVhauUCShsOp6/uCHS0FJH+K1Ekce5fWp5jZgyROu3dxmLOFnwKhF/UsQyKtTyWVdo8s29DPiUof8xt0KSQCfqQQPzq7tTOpEu2Q7SMe552dXNQbzoxpVaq92KUiuCC2ahFbjNxlIS0pxPIQQp9JH/mc/OkmxOXLKjm6nFDtB3Ibadts2TVbltGgQqLT1PTWysOMyqutl5K+o4H9lhpHHPHVCQAANLO8ON6tSXMtmxsR/E6xdMxdbbVCgVlukma1S4nhihL7r8R8dGwEJ7MoHI/P1H2dL1SXeK/3qWsxdPxG8J06r24ir0aVTaJHnMSYYkRnWjVZvdDqVAoUkpPsK9cH3pfTj/GsS7b8PAvxRY0XF1vM0O3ahTFIkwYEMohhLtLWtTfVPpILzTTnVPX6uOB+XlPePaN7B8QW3ljHO4C68uWdDrVXnwglmbVoSFvMOuMy3XXmeQFNrLnjV3QUnlCepBGkmryuZjYHw3p1wL2kZktSpRZqWoCp78Nt5pQI89O4UlHP8dmueAOOVE/dR0nlTl7Ggtg727q2/6/G26yrenyJTNOFUFwpU0tsAyAypgrdbQSCp0qCu32T6/Mm/i8s/X3btSbUhYf3DRLgpV0t5YlWjPRIE6GERTETKbL7bRH1KeLvhUsKA9J+kcJWdIX2MRDtuw3dltv2g9iB6TlK87rej2/XRT22C2hqQwlxD0tZSQjq4EdVnoPKlXI6kh+L+t97kbPvyBi3bLsnr8hyRUqjMiOXI9HWVNRmUuBhlsuJASpCEvPj7/wDToP1Hg6t/IzPbUS2+Y9yLPsjcnsgt2cYFVXI+eoMiUvo3L+WloaktFwDqfOw3HSCOAOST654k/pbZ1VjtOruK9uVSnYl3gbW/BVpdU+ah3PVrXRUfl0dUp6K8iFKDKVIKkuR+4JcPKfXbSZPTlt7lbLz2hys/FBxJXaQ2ubTnodGeblsJLjKm1KkKCgseuCkg88/YjVvqT+K7+HpTqjF3g5/kyoMlppyVUOjjjaglXNUWfRPPPr39z/qdOPpy8j0a1tzcW/Ehru3yXRLTx1le0Ltr9zVmQ45b39LtAzoY5Sh1xPchDvPIAZIV3IH7PSxnljfDfxydfeMsr7ZbZpFqbgsbO5UwOiaxUYEkF6DLpCnuOwStCw9CdUCErjulTKlfShXf6xnM9all89VNyFy413dz7ExLs5xvdr0ijso5hMtiHR4LKwrv3je0NuhSk95KlJSeOOXOQoL34TePddUbQfhu2ng+fSslZOqIuG+oKkyYjUZ1aIFMd4I5QPRfWAojsv6QfYTyArWpxxnlz3qJh8QfblkbcpjS3LWxqimKn0uuioPifJ8CfD8u6j0rg++y0+v/AJpympxuOdq1tN+INfeH6Ft1rtbx9SbHpKIrHVqWryOIYUSgurS2pa+CQrgAAlCft/My+NfXGXWRuT4buR5q8N4rRVaZU8d2gtU+6ZapZjPypcuUFz0sNpT26hhllttRIVzyTxp8n37WVz98Np2gXTYt77OaBTqHU7fnmfObqdZkrQp9lxl2K4hTyln0pDgIBH8at4/0k5/22XjDadeLOfs6XjkumUxVn5Vpr0FllmWHngh5Se6Vp6jqQOeCOfYB/GknZeXUxpHbF8OHL2N8j3SnI02i/wBK161q1bKpkCYVyFImN+FLgaKR1PUlXBV6+3OpOK3nL4srZ2sb9saYduXbLZ1JtldAuGtt1QXVEuAx3ovVTBUG/aXUJV8s3yA2T9Sx77HTL4bxt1Os57DswuW5h28cW3TDuO/sWxWW5oq8taU1N5uV82lxtxw/4vrdBDik8oKeFJKeCvFJynbJ2Ptk3G5g3b0TcxuNt+27UgWqy0mDRqdOExx5xhCixwpClJSkPOKdKlK55SEhPB7C5bdpbJMjIbuNsWf8g7prEz7h2n2zMas2l09KGaxPUylyXHnSX+qkpHJQUuo9hQP3/Gll3TjZJlX2F9pOaK3uZk7qtzlVtQ1lqKY9NolA8zkdpRjfLhSi59kJbU59BLhUpZUSOACk72l5TMjWNjbWt4W12XkyxcIWxa13Wpf7RjRanMqiYsinthDyGnChaknyJS+ewHdJLYIPsgzLPFtl9bz2qbSLhwFtpurHdXqMKZd14sTX5hYdUYrDrsbwssJUQOQkDlSuP3KVxyANWTIzeW3XNeAdpfxBttKLiGLVY/jO3M3HblvTJgkKR4PL41NhSOoILyz7BB4Hr8ySxq8uN9SPGHw3MqWtZOVbkva7aJVcgXxbs2kU+JFeX8o27JdQ66888ptJ8ilNhICU9UhS/auR1fJecZmBsAv2rbHHMGXQKOxfdJuF+4aI61K7xwtXCC2tzqCEraLgI44CvGo89dPnpPrvVhb+xTNGbM9U3IO8KFRahbtPt9mmORKZWXSuU6xHDTfYo6LQFOKcfV1UPrPHsE8stva/UkyK9T2MZewPuYg5e2h0G2UW7Dp/RFLrdXfKfK4ytp9tZWVOKSeUuA9/RIA440zL0n1LMq63D4G34br6FSrFv+28P23SYE9NQTNhy5K5CHAhaCO6g4QgpXyUpSCSkcq49atlpLx4sjM2P5Po+5zDV+W9Npk+0ccUGiUaZMkSvFKeMJDiVrSzwf3dkkDt65459aZ2fUxgcY7bN6OBM4ZGyfjW18d1WNek+apDdYqjo6R3Jin21ANdOquCAR7H+mpllW2WY72tB26JFq0d+94sCLcLkFhdVYgLUqM1LKAXUNKV7KAvsAT74A1tzfJFoWtMuiJesugQX69T4zkOHUXWUqfjMrPK0NrPtAV/l1454APIGgyUuJEqER6BPisyY0ltTLzLyAtt1tQ4UlST6UkgkEH0QdBG8fYrxxiimyqRjayqRbcObIVLkM06MlkOuq/yVx9+B6A+yRwBwBxpmLbvqVaIaBoGgaBoGgaBoGgaBoGgaBoGgaBoGgaBoGgaD//Z`,
        fit: [98, 21], absolutePosition: { x: marginLeft, y: marginTop + 17 }
      },
        {
          // tslint:disable-next-line: max-line-length
          image: `data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCAAvANADAREAAhEBAxEB/8QAHAABAAEFAQEAAAAAAAAAAAAAAAYDBAUHCAkB/8QANBAAAQMDBAIABQMDAgcAAAAAAQIDBAUGBwAIERITIQkUIjFRFTJBFiNCcYEkQ0RhY8HR/8QAFwEBAQEBAAAAAAAAAAAAAAAAAAECA//EACARAQEBAAMBAQADAQEAAAAAAAABEQIhMRJBMlFhcSL/2gAMAwEAAhEDEQA/APVPQNA0DQNA0DQNA0DQNA0DQNA0DQNA0DQNA0DQNA0DQNA0DQWNIrlFuGH+o0CrwqlE8i2fPDkIeb8iFFK09kEjlKgQR9wQQdBcS5kSAwZM6UzHZSpKS46sISCpQSkcn1ySQB+SQNBW0DQNA0DQNA0DQNA0DQNA0DQNA0DQNA0DQNA0EDzDnLF+B7YcuvJ11RaTG4UIzBPeTMcA58bDQ+pxR/7ehzyoge9S3Fkt8eZGV99l57uL9gYdoF7x8NY5rUj5OXUpRcclSG1ev+JcZ/alQ+kMpUhvlRDjpT7Tm3XScfntIa7iDLGyXJciNtKzVT7zlsw0z63Ykx5t2ouNpRypa4SCPMOPqHiKX0pKeAQexZnibOU7SHHuR7Z305+tKs3hnOs2b/TUuLUmcbzG0NNu1KMttYMR/kNyQpaVkhxsPoAISFJ5Wl/KlnzHVG9fdHWdqlh0K8KLaUKvuVer/pi2ZUpTIbT4XHOw6gknlHH4961bjPGfTnirfEf3HWnY9Gyxde1KO1ZVZLSotTarCw0+lfJSAsIX4yrqeO6f9tZ+q18TzXZuIM42XmLDtMzZSHl0ugzoj8qR+oLQ2YXgWtD4dVz1AQppf1c8FICvsdal3tizLjJ2FmDFeU3JrWN8h2/cy6aG1S00uoNySwF9uhWEE9QeiuOfwdN0ss9UGc34dk3wcaMZOtly7A+uMaKmptGYHkpKlN+Lt27BIJ4459abDL6yEfJ+Opd9ScYxr2ort2w2g/IoiJiDNabKEuBSmuewHRxCuSPsoH+dXTP1CZu7nbNT7pNlzc32m1V0P/KraM9PjQ9zwUKdH9tKgQQQVDg+j71Nh81Nb4yjjnGlBZui/wC+KJQKVIWluPLnzUNNvrUkqCWyT/cUUgq4TyeAT9gTq6ZrEY1z9hbML78TGeS6DcEqMjyvRYkofMIb547lpXC+vJA7cccke/epLKWWevt/Z7wvi2sM2/kbJ1u25UpEZMxqLUZyGXFsKUpCXAlR5KSptY5/KTpshJayVh5ZxhlFiRIxxkC37lRE6/MCl1FqQpjt9u6UKJRzweOQOeNXdLLEbvHdBt4x/cC7UvHMlq0ursr8b8N2oILsdfHPV0JJ8R498L4+4/I1NhlqT1S/qMvG1SyRaFTp1dp8ekyanCkxJKXo0oNNqUOriCQUkp4JB/Ommd44Uxf8RzcvmlNWVi3a1T7j/Q0NLnpiVZfZkO9/H9KgCoq8a+Ank/SdZ+rW7wk9rbu1f4hNlZ7j3HT76oTVh1e1KearUFSZwXCMNLiW3HfIpKS30W42FJUPXccKPvizlrN443DF3X7ZJshuJGz7YKnXlBCEmvxhyo/YclfGrsT5qc3TfVmWPbi7vvC6qVRqG34+1Rmy0Mxx5CAj+4ohP1EgD3751UzVG0cj2BftvvXZZV6UWuUWOtxp6oQZrb0dpaEhSwpxJKUlKSCeT6BB00zEHnbt9sNNlOQpefLGS80opWlFaYcAIPBHKVEc/wC+psX5qX1bLGMqFecHHVZv6gwroqSUKh0d+e2iY+FlQR0aJ7HkpVx698HTTL6WtljGV8V6qWvZ1/UGt1eiqUmowoE9t96KUrKFeRCSSnhYKff8+tNMsSzVRqTczY+368caTVbik0aLbsMEoqk51LDsJ1Q4BjvfuS4fsEp5Kj66q+2pc/Vlu9PK2zYVvU2ZWkbTqa9DpVKeP6rmC9fEwukskEpTDHUJiLKAoAoC5TpUegb5CU4/463/AFSsloR11edtyQH5kErcuTNF5H5ZEBxwErMIOdvlVLAUUr4dmrK1dOn20/4X/XXnw+MY7PZb0u7rRvdvI2TIslx+ZUa9GLEthffkyIkV4lSUkkHz8rc5UQVI5LY1xxjlaqfF8hTZ2FLMagw35C03SFFLTJWQPlH/AGSPY/8Af+2nI4euXcmR9487ZvY9Hu+3KZGxBHEHxvUphDtSLPYhhUhtTnb0T6CQgFXUKI5Gs941M1vfJ2RbCsb4YtFtfCkWtts3Sf6eTHntH9QQ6t5b1RU8lH8K6up5H09XmwPRA1b4k/l2hm0S3K5tR3rUjGk8STRL8tOAw/Ic58Qmuwm5HJ49BQmNPsJB9gOD86TqnL/1Goc/2xkOJury5mOwWJHz2PLqj1tHVhauUCShsOp6/uCHS0FJH+K1Ekce5fWp5jZgyROu3dxmLOFnwKhF/UsQyKtTyWVdo8s29DPiUof8xt0KSQCfqQQPzq7tTOpEu2Q7SMe552dXNQbzoxpVaq92KUiuCC2ahFbjNxlIS0pxPIQQp9JH/mc/OkmxOXLKjm6nFDtB3Ibadts2TVbltGgQqLT1PTWysOMyqutl5K+o4H9lhpHHPHVCQAANLO8ON6tSXMtmxsR/E6xdMxdbbVCgVlukma1S4nhihL7r8R8dGwEJ7MoHI/P1H2dL1SXeK/3qWsxdPxG8J06r24ir0aVTaJHnMSYYkRnWjVZvdDqVAoUkpPsK9cH3pfTj/GsS7b8PAvxRY0XF1vM0O3ahTFIkwYEMohhLtLWtTfVPpILzTTnVPX6uOB+XlPePaN7B8QW3ljHO4C68uWdDrVXnwglmbVoSFvMOuMy3XXmeQFNrLnjV3QUnlCepBGkmryuZjYHw3p1wL2kZktSpRZqWoCp78Nt5pQI89O4UlHP8dmueAOOVE/dR0nlTl7Ggtg727q2/6/G26yrenyJTNOFUFwpU0tsAyAypgrdbQSCp0qCu32T6/Mm/i8s/X3btSbUhYf3DRLgpV0t5YlWjPRIE6GERTETKbL7bRH1KeLvhUsKA9J+kcJWdIX2MRDtuw3dltv2g9iB6TlK87rej2/XRT22C2hqQwlxD0tZSQjq4EdVnoPKlXI6kh+L+t97kbPvyBi3bLsnr8hyRUqjMiOXI9HWVNRmUuBhlsuJASpCEvPj7/wDToP1Hg6t/IzPbUS2+Y9yLPsjcnsgt2cYFVXI+eoMiUvo3L+WloaktFwDqfOw3HSCOAOST654k/pbZ1VjtOruK9uVSnYl3gbW/BVpdU+ah3PVrXRUfl0dUp6K8iFKDKVIKkuR+4JcPKfXbSZPTlt7lbLz2hys/FBxJXaQ2ubTnodGeblsJLjKm1KkKCgseuCkg88/YjVvqT+K7+HpTqjF3g5/kyoMlppyVUOjjjaglXNUWfRPPPr39z/qdOPpy8j0a1tzcW/Ehru3yXRLTx1le0Ltr9zVmQ45b39LtAzoY5Sh1xPchDvPIAZIV3IH7PSxnljfDfxydfeMsr7ZbZpFqbgsbO5UwOiaxUYEkF6DLpCnuOwStCw9CdUCErjulTKlfShXf6xnM9all89VNyFy413dz7ExLs5xvdr0ijso5hMtiHR4LKwrv3je0NuhSk95KlJSeOOXOQoL34TePddUbQfhu2ng+fSslZOqIuG+oKkyYjUZ1aIFMd4I5QPRfWAojsv6QfYTyArWpxxnlz3qJh8QfblkbcpjS3LWxqimKn0uuioPifJ8CfD8u6j0rg++y0+v/AJpympxuOdq1tN+INfeH6Ft1rtbx9SbHpKIrHVqWryOIYUSgurS2pa+CQrgAAlCft/My+NfXGXWRuT4buR5q8N4rRVaZU8d2gtU+6ZapZjPypcuUFz0sNpT26hhllttRIVzyTxp8n37WVz98Np2gXTYt77OaBTqHU7fnmfObqdZkrQp9lxl2K4hTyln0pDgIBH8at4/0k5/22XjDadeLOfs6XjkumUxVn5Vpr0FllmWHngh5Se6Vp6jqQOeCOfYB/GknZeXUxpHbF8OHL2N8j3SnI02i/wBK161q1bKpkCYVyFImN+FLgaKR1PUlXBV6+3OpOK3nL4srZ2sb9saYduXbLZ1JtldAuGtt1QXVEuAx3ovVTBUG/aXUJV8s3yA2T9Sx77HTL4bxt1Os57DswuW5h28cW3TDuO/sWxWW5oq8taU1N5uV82lxtxw/4vrdBDik8oKeFJKeCvFJynbJ2Ptk3G5g3b0TcxuNt+27UgWqy0mDRqdOExx5xhCixwpClJSkPOKdKlK55SEhPB7C5bdpbJMjIbuNsWf8g7prEz7h2n2zMas2l09KGaxPUylyXHnSX+qkpHJQUuo9hQP3/Gll3TjZJlX2F9pOaK3uZk7qtzlVtQ1lqKY9NolA8zkdpRjfLhSi59kJbU59BLhUpZUSOACk72l5TMjWNjbWt4W12XkyxcIWxa13Wpf7RjRanMqiYsinthDyGnChaknyJS+ewHdJLYIPsgzLPFtl9bz2qbSLhwFtpurHdXqMKZd14sTX5hYdUYrDrsbwssJUQOQkDlSuP3KVxyANWTIzeW3XNeAdpfxBttKLiGLVY/jO3M3HblvTJgkKR4PL41NhSOoILyz7BB4Hr8ySxq8uN9SPGHw3MqWtZOVbkva7aJVcgXxbs2kU+JFeX8o27JdQ66888ptJ8ilNhICU9UhS/auR1fJecZmBsAv2rbHHMGXQKOxfdJuF+4aI61K7xwtXCC2tzqCEraLgI44CvGo89dPnpPrvVhb+xTNGbM9U3IO8KFRahbtPt9mmORKZWXSuU6xHDTfYo6LQFOKcfV1UPrPHsE8stva/UkyK9T2MZewPuYg5e2h0G2UW7Dp/RFLrdXfKfK4ytp9tZWVOKSeUuA9/RIA440zL0n1LMq63D4G34br6FSrFv+28P23SYE9NQTNhy5K5CHAhaCO6g4QgpXyUpSCSkcq49atlpLx4sjM2P5Po+5zDV+W9Npk+0ccUGiUaZMkSvFKeMJDiVrSzwf3dkkDt65459aZ2fUxgcY7bN6OBM4ZGyfjW18d1WNek+apDdYqjo6R3Jin21ANdOquCAR7H+mpllW2WY72tB26JFq0d+94sCLcLkFhdVYgLUqM1LKAXUNKV7KAvsAT74A1tzfJFoWtMuiJesugQX69T4zkOHUXWUqfjMrPK0NrPtAV/l1454APIGgyUuJEqER6BPisyY0ltTLzLyAtt1tQ4UlST6UkgkEH0QdBG8fYrxxiimyqRjayqRbcObIVLkM06MlkOuq/yVx9+B6A+yRwBwBxpmLbvqVaIaBoGgaBoGgaBoGgaBoGgaBoGgaBoGgaBoGgaD//Z`,
          fit: [57, 13], absolutePosition: { x: marginLeft + 125, y: marginTop + 25 }
        },
        {
          image: img,
          fit: [300, 40], absolutePosition: { x: marginLeft + 129, y: marginTop + 230 }
        },
        { text: 'Nº DO DOCUMENTO', absolutePosition: { x: marginLeft + 2, y: marginTop + 40 }, fontSize: 4 },
        { text: boleto.documento, absolutePosition: { x: marginLeft + 2, y: marginTop + 46 }, fontSize: 7 },
        {
          canvas: [
            {
              type: 'rect',
              x: 0,
              y: 0,
              w: 66,
              h: 16,
              color: '#cccccc',
            }], absolutePosition: { x: marginLeft, y: marginTop + 56 }
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 106, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft, y: marginTop + 56 }
        },
        { text: 'VENCIMENTO', absolutePosition: { x: marginLeft + 2, y: marginTop + 57 }, fontSize: 4 },
        { text: boleto.dt_vencimento, absolutePosition: { x: marginLeft + 2, y: marginTop + 62 }, fontSize: 7 },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 0, y2: 16, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 66, y: marginTop + 56 }
        },
        { text: 'PARCELA', absolutePosition: { x: marginLeft + 67, y: marginTop + 57 }, fontSize: 4 },
        { text: boleto.parcela, absolutePosition: { x: marginLeft + 67, y: marginTop + 62 }, fontSize: 7 },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 106, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft, y: marginTop + 72 }
        },
        { text: 'AGÊNCIA / CÓDIGO DO CEDENTE', absolutePosition: { x: marginLeft + 2, y: marginTop + 73 }, fontSize: 4 },
        { text: boleto.conta_corrente, absolutePosition: { x: marginLeft + 2, y: marginTop + 79 }, fontSize: 7 },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 106, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft, y: marginTop + 89 }
        },
        { text: 'NOSSO NÚMERO / COD. DO DOCUMENTO', absolutePosition: { x: marginLeft + 2, y: marginTop + 90 }, fontSize: 4 },
        { text: boleto.nosso_numero, absolutePosition: { x: marginLeft + 2, y: marginTop + 96 }, fontSize: 7 },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 106, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft, y: marginTop + 106 }
        },
        { text: 'CEDENTE', absolutePosition: { x: marginLeft + 2, y: marginTop + 107 }, fontSize: 4 },
        { text: boleto.cedente, absolutePosition: { x: marginLeft + 2, y: marginTop + 113 }, fontSize: 4 },
        {
          canvas: [
            {
              type: 'rect',
              x: 0,
              y: 0,
              w: 106,
              h: 19,
              color: '#cccccc',
            }], absolutePosition: { x: marginLeft, y: marginTop + 125 }
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 106, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft, y: marginTop + 125 }
        },
        { text: '( = ) VALOR DO DOCUMENTO', absolutePosition: { x: marginLeft + 2, y: marginTop + 126 }, fontSize: 4 },
        {
          alignment: 'right', columns: [{ text: boleto.valor, width: 100 }],
          absolutePosition: { x: marginLeft + 2, y: marginTop + 132 }, fontSize: 7
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 106, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft, y: marginTop + 144 }
        },
        { text: '( -  ) OUTRAS DEDUÇÕES', absolutePosition: { x: marginLeft + 2, y: marginTop + 145 }, fontSize: 4 },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 106, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft, y: marginTop + 164 }
        },
        { text: '( + ) OUTROS ACRESCIMOS', absolutePosition: { x: marginLeft + 2, y: marginTop + 165 }, fontSize: 4 },
        {
          canvas: [
            {
              type: 'rect',
              x: 0,
              y: 0,
              w: 106,
              h: 20,
              color: '#cccccc',
            }], absolutePosition: { x: marginLeft, y: marginTop + 184 }
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 106, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft, y: marginTop + 184 }
        },
        { text: '( = ) VALOR COBRADO', absolutePosition: { x: marginLeft + 2, y: marginTop + 185 }, fontSize: 4 },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 106, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft, y: marginTop + 204 }
        },
        {
          text: 'NOME DO PAGADOR/CPF/CNPJ/ENDEREÇO/', absolutePosition: { x: marginLeft + 2, y: marginTop + 205 },
          fontSize: 4
        },
        {
          text: 'CIDADE/UF/CEP:', absolutePosition: { x: marginLeft + 2, y: marginTop + 210 },
          fontSize: 4
        },
        {
          text: boleto.sacado_nome, absolutePosition: { x: marginLeft + 2, y: marginTop + 217 },
          fontSize: 6
        },
        {
          text: boleto.sacado_cpf_cnpj, absolutePosition: { x: marginLeft + 2, y: marginTop + 227 },
          fontSize: 6
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 106, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft, y: marginTop + 238 }
        },
        {
          canvas: [{
            type: 'line', x1: 0, y1: 0, x2: 0, y2: 254, dash: { length: 2, space: 2 },
            lineWidth: 0.5
          }], absolutePosition: { x: marginLeft + 114, y: marginTop + 18 }
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 0, y2: 14, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 182, y: marginTop + 25 }
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 0, y2: 14, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 217, y: marginTop + 25 }
        },
        {
          canvas: [
            {
              type: 'rect',
              x: 0,
              y: 0,
              w: 103,
              h: 17,
              color: '#cccccc',
            }], absolutePosition: { x: marginLeft + 450, y: marginTop + 39 }
        },
        {
          canvas: [
            {
              type: 'rect',
              x: 0,
              y: 0,
              w: 103,
              h: 17,
              color: '#cccccc',
            }], absolutePosition: { x: marginLeft + 450, y: marginTop + 89 }
        },
        {
          canvas: [
            {
              type: 'rect',
              x: 0,
              y: 0,
              w: 103,
              h: 17,
              color: '#cccccc',
            }], absolutePosition: { x: marginLeft + 450, y: marginTop + 169 }
        },
        {
          alignment: 'center', columns: [{ text: boleto.banco, width: 35 }],
          absolutePosition: { x: marginLeft + 182, y: marginTop + 27 }, fontSize: 9
        },
        {
          alignment: 'right', columns: [{ text: boleto.digito_codbarra, width: 328 }],
          absolutePosition: { x: marginLeft + 217, y: marginTop + 27 }, fontSize: 9
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 428, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 125, y: marginTop + 39 }
        },
        { text: 'LOCAL DE PAGAMENTO', absolutePosition: { x: marginLeft + 126, y: marginTop + 40 }, fontSize: 4 },
        { text: boleto.local_pagamento, absolutePosition: { x: marginLeft + 126, y: marginTop + 46 }, fontSize: 7 },
        { text: 'PARCELA', absolutePosition: { x: marginLeft + 416, y: marginTop + 40 }, fontSize: 4 },
        { text: boleto.parcela, absolutePosition: { x: marginLeft + 416, y: marginTop + 46 }, fontSize: 7 },
        { text: 'VENCIMENTO', absolutePosition: { x: marginLeft + 452, y: marginTop + 40 }, fontSize: 4 },
        {
          alignment: 'right', columns: [{ text: boleto.dt_vencimento, width: 92 }],
          absolutePosition: { x: marginLeft + 452, y: marginTop + 46 }, fontSize: 7
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 0, y2: 17, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 414, y: marginTop + 39 }
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 0, y2: 147, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 450, y: marginTop + 39 }
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 428, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 125, y: marginTop + 56 }
        },
        { text: 'CEDENTE', absolutePosition: { x: marginLeft + 126, y: marginTop + 57 }, fontSize: 4 },
        { text: boleto.cedente, absolutePosition: { x: marginLeft + 126, y: marginTop + 63 }, fontSize: 7 },
        { text: 'AGÊNCIA /CODIGO DO CEDENTE', absolutePosition: { x: marginLeft + 452, y: marginTop + 57 }, fontSize: 4 },
        {
          alignment: 'right', columns: [{ text: boleto.conta_corrente, width: 92 }],
          absolutePosition: { x: marginLeft + 452, y: marginTop + 63 }, fontSize: 7
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 428, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 125, y: marginTop + 73 }
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 0, y2: 16, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 189, y: marginTop + 73 }
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 0, y2: 16, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 324, y: marginTop + 73 }
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 0, y2: 16, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 363, y: marginTop + 73 }
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 0, y2: 16, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 391, y: marginTop + 73 }
        },
        { text: 'DATA DO DOCUMENTO', absolutePosition: { x: marginLeft + 126, y: marginTop + 74 }, fontSize: 4 },
        {
          alignment: 'center', columns: [{ text: boleto.dt_doc, width: 62 }],
          absolutePosition: { x: marginLeft + 126, y: marginTop + 79 }, fontSize: 7
        },
        { text: 'N° DO DOCUMENTO', absolutePosition: { x: marginLeft + 192, y: marginTop + 74 }, fontSize: 4 },
        { text: boleto.documento, absolutePosition: { x: marginLeft + 192, y: marginTop + 79 }, fontSize: 7 },
        { text: 'ESPÉCIE DOC.', absolutePosition: { x: marginLeft + 325, y: marginTop + 74 }, fontSize: 4 },
        { text: boleto.especie_doc, absolutePosition: { x: marginLeft + 325, y: marginTop + 79 }, fontSize: 7 },
        { text: 'ACEITE', absolutePosition: { x: marginLeft + 365, y: marginTop + 74 }, fontSize: 4 },
        { text: boleto.aceite, absolutePosition: { x: marginLeft + 365, y: marginTop + 79 }, fontSize: 7 },
        { text: 'DATA PROCESSAMENTO', absolutePosition: { x: marginLeft + 393, y: marginTop + 74 }, fontSize: 4 },
        {
          alignment: 'center', columns: [{ text: boleto.dt_processamento, width: 55 }],
          absolutePosition: { x: marginLeft + 394, y: marginTop + 79 }, fontSize: 7
        },
        { text: 'NOSSO NÚMERO / CÓD. DO DOCUMENTO', absolutePosition: { x: marginLeft + 452, y: marginTop + 74 }, fontSize: 4 },
        {
          alignment: 'right', columns: [{ text: boleto.nosso_numero, width: 92 }],
          absolutePosition: { x: marginLeft + 452, y: marginTop + 79 }, fontSize: 7
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 428, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 125, y: marginTop + 89 }
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 0, y2: 17, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 239, y: marginTop + 89 }
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 0, y2: 17, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 270, y: marginTop + 89 }
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 0, y2: 17, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 315, y: marginTop + 89 }
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 0, y2: 17, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 377, y: marginTop + 89 }
        },
        { text: 'USO DO BANCO', absolutePosition: { x: marginLeft + 126, y: marginTop + 90 }, fontSize: 4 },
        { text: 'CARTEIRA', absolutePosition: { x: marginLeft + 240, y: marginTop + 90 }, fontSize: 4 },
        { text: boleto.carteira, absolutePosition: { x: marginLeft + 240, y: marginTop + 96 }, fontSize: 7 },
        { text: 'ESPÉCIE', absolutePosition: { x: marginLeft + 272, y: marginTop + 90 }, fontSize: 4 },
        { text: boleto.especie, absolutePosition: { x: marginLeft + 272, y: marginTop + 96 }, fontSize: 7 },
        { text: 'QUANTIDADE DE MOEDA', absolutePosition: { x: marginLeft + 317, y: marginTop + 90 }, fontSize: 4 },
        { text: 'VALOR DA MOEDA', absolutePosition: { x: marginLeft + 380, y: marginTop + 90 }, fontSize: 4 },
        { text: '( = ) VALOR DO DOCUMENTO', absolutePosition: { x: marginLeft + 452, y: marginTop + 90 }, fontSize: 4 },
        {
          alignment: 'right', columns: [{ text: boleto.valor, width: 92 }],
          absolutePosition: { x: marginLeft + 452, y: marginTop + 96 }, fontSize: 7
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 428, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 125, y: marginTop + 106 }
        },
        {
          text: 'INSTRUÇÕES (TEXTO DE RESPONSABILIDADE DO CEDENTE)',
          absolutePosition: { x: marginLeft + 126, y: marginTop + 107 }, fontSize: 4
        },
        { text: boleto.instrucao1, absolutePosition: { x: marginLeft + 126, y: marginTop + 123 }, fontSize: 8 },
        { text: boleto.instrucao2, absolutePosition: { x: marginLeft + 126, y: marginTop + 134 }, fontSize: 8 },
        { text: boleto.instrucao3, absolutePosition: { x: marginLeft + 126, y: marginTop + 145 }, fontSize: 8 },
        { text: boleto.instrucao4, absolutePosition: { x: marginLeft + 126, y: marginTop + 156 }, fontSize: 8 },
        { text: boleto.instrucao5, absolutePosition: { x: marginLeft + 126, y: marginTop + 167 }, fontSize: 8 },
        { text: '( - ) DESCONTO / ABATIMENTO', absolutePosition: { x: marginLeft + 452, y: marginTop + 107 }, fontSize: 4 },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 103, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 450, y: marginTop + 121 }
        },
        { text: '( - ) OUTRAS DEDUÇÕES', absolutePosition: { x: marginLeft + 452, y: marginTop + 122 }, fontSize: 4 },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 103, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 450, y: marginTop + 137 }
        },
        { text: '( + ) MORA / MULTA', absolutePosition: { x: marginLeft + 452, y: marginTop + 138 }, fontSize: 4 },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 103, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 450, y: marginTop + 153 }
        },
        { text: '( + ) OUTROS ACRESCIMOS', absolutePosition: { x: marginLeft + 452, y: marginTop + 154 }, fontSize: 4 },
        {
          alignment: 'right', columns: [{ text: boleto.acrescimo, width: 92 }],
          absolutePosition: { x: marginLeft + 452, y: marginTop + 159 }, fontSize: 7
        },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 103, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 450, y: marginTop + 169 }
        },
        { text: '( = ) VALOR COBRADO', absolutePosition: { x: marginLeft + 452, y: marginTop + 170 }, fontSize: 4 },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 428, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 125, y: marginTop + 186 }
        },
        {
          text: 'NOME DO PAGADOR/CPF/CNPJ/ENDEREÇO/CIDADE/UF/CEP:',
          absolutePosition: { x: marginLeft + 126, y: marginTop + 187 }, fontSize: 4
        },
        { text: boleto.endereco1, absolutePosition: { x: marginLeft + 143, y: marginTop + 194 }, fontSize: 7 },
        { text: boleto.endereco2, absolutePosition: { x: marginLeft + 143, y: marginTop + 204 }, fontSize: 7 },
        { text: boleto.endereco3, absolutePosition: { x: marginLeft + 143, y: marginTop + 214 }, fontSize: 7 },
        {
          canvas: [{ type: 'line', x1: 0, y1: 0, x2: 428, y2: 0, lineWidth: 0.5 }],
          absolutePosition: { x: marginLeft + 125, y: marginTop + 226 }
        },
        { text: 'Código de Baixa', absolutePosition: { x: marginLeft + 491, y: marginTop + 220 }, fontSize: 4 },
        { text: 'FICHA DE COMPENSAÇÃO', absolutePosition: { x: marginLeft + 470, y: marginTop + 236 }, fontSize: 6, bold: true },
        { text: 'AUTENTICAR NO VERSO', absolutePosition: { x: marginLeft + 484, y: marginTop + 251 }, fontSize: 4 },
        {
          canvas: [{
            type: 'line', x1: 0, y1: 0, x2: 560, y2: 0, dash: { length: 5, space: 2 },
            lineWidth: 0.5, lineColor: '#cccccc'
          }], absolutePosition: { x: marginLeft, y: marginTop + 279 }
        }
      );
    }
    return retorno;
  }

  // const bancoService = new BancoService(this.injector);
  // bancoService.obterId(2)
  //   .pipe(takeUntil(this.unsubscribe))
  //   .subscribe(banco => {

  //     const conta = new ContaBancaria();
  //     conta.banco = banco;
  //     const boleto = new Boleto();
  //     boleto.setValorBoleto(471.21);
  //     boleto.setUfSacado('SP');
  //     boleto.setParcela('UNICA');
  //     boleto.setNumConvenio('1890635');
  //     let tamanho;

  //     tamanho = 10;

  //     boleto.setNossoNumero('6689961', tamanho);
  //     boleto.setNomeSacado('MARIA DA CONCEIÇÃO DE JESUS REIS');
  //     boleto.setMoeda('9');
  //     boleto.setLocalPagamento('PAGAVEL EM QUALQUER AGENCIA ATE O VENCIMENTO');
  //     boleto.setInstrucao5('NÃO RECEBER APÓS O VENCIMENTO							Nº CADASTRO: 0000011610112101');
  //     boleto.setInstrucao4('GUIA UNICA COM DESCONTO DE 20%');
  //     boleto.setInstrucao3('Após o vencimento, cobrar multa de 2% e juros de 1% ao mês.');
  //     boleto.setInstrucao2('NÃO RECEBER APÓS 30/06/2020');
  //     boleto.setInstrucao1('FINALIDADE: IPTU');
  //     boleto.setEspecieDocumento('R$');
  //     boleto.setEspecie('R$');
  //     boleto.setEnderecoSacado('RUA MANOEL BORBA, 1640');
  //     boleto.setDvContaCorrente('1');
  //     boleto.setDvAgencia('4');
  //     boleto.setDocumento('0000011610112101-1/1');
  //     boleto.setDataVencimento('30/06/2020');
  //     boleto.setDataProcessamento('18/06/2020');
  //     boleto.setDataDocumento('18/06/2020');
  //     boleto.setCpfSacado('34375292857');
  //     boleto.setContaCorrente('130009');
  //     boleto.setCidadeSacado('AMÉRICO BRASILIENSE');
  //     boleto.setCepSacado('14823394');
  //     boleto.setCedente('Eddydata 43.976.166/0001-50');
  //     boleto.setCarteira('17');
  //     boleto.setBairroSacado(' JARDIM SANTA RITA');
  //     boleto.setAgencia('4562');
  //     boleto.setAcrescimo(0);
  //     boleto.setAceite('N');

  //     ImprimirBoleto.imprimir(conta, [boleto, boleto, boleto, boleto, boleto, boleto, boleto, boleto, boleto, boleto]);
  //   });
}
