import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RacaRoutingModule } from './raca-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RacaRoutingModule
  ]
})
export class RacaModule { }
