import { Injectable, Injector } from '@angular/core';
import { BaseResourceService } from '../../models/services/base-resource.service';
import { Assinatura } from '../../entidade/comum/assinatura.model';

@Injectable({
  providedIn: 'root'
})
export class AssinaturaService extends BaseResourceService<Assinatura> {

  constructor(
    protected injector: Injector
  ) {
    super(`assinaturas`, injector);
  }

}
