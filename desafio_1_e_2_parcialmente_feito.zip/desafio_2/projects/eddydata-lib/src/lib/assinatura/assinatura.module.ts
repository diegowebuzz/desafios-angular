import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AssinaturaRoutingModule } from './assinatura-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AssinaturaRoutingModule
  ]
})
export class AssinaturaModule { }
