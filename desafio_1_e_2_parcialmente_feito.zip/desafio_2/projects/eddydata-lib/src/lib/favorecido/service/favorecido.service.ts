import { Injectable, Injector } from '@angular/core';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Favorecido } from '../../entidade/compra/favorecido.model';
import { BaseResourceService } from '../../models/services/base-resource.service';
import { Page } from '../../util/page';

@Injectable({
  providedIn: 'root'
})
export class FavorecidoService extends BaseResourceService<Favorecido> {

  constructor(
    protected injector: Injector
  ) {
    super(`favorecidos`, injector);
  }

  public obterPorNome(filtroTexto: string, cidadeId: number, page?: number, limit?: number): Observable<Page> {
    if (!Number.isInteger(page) || !Number.isInteger(page)) {
      page = 1;
      limit = 1000;
    }
    return this.http.get<Page>(
      `${cidadeId}/${this.api}/filtrar?nome$like=${filtroTexto}%&cidade_id=${cidadeId}`,
      this.httpOptions()
    ).pipe(
      map(res => res),
      catchError(err => this.handleError(err))
    );
  }

  public obterPorCpfCnpj(filtroTexto: string, cidadeId: number, page?: number, limit?: number): Observable<Page> {
    if (!Number.isInteger(page) || !Number.isInteger(page)) {
      page = 1;
      limit = 1000;
    }
    return this.http.get<Page>(
      `${cidadeId}/${this.api}/filtrar?cpf_cnpj$like=${filtroTexto}&cidade_id=${cidadeId}`,
      this.httpOptions()
    ).pipe(
      map(res => res),
      catchError(err => this.handleError(err))
    );
  }

  public obterPorCNPJ(filtroTexto: string, cidadeId: number): Observable<any> {
    return this.http.get<any>(
      `${cidadeId}/${this.api}/cnpj/${filtroTexto}/${cidadeId}`,
      this.httpOptions()
    ).pipe(
      map(res => res),
      catchError(err => this.handleError(err))
    );
  }

}
