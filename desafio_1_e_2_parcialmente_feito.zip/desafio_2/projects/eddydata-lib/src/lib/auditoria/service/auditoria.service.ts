import { Injectable, Injector } from '@angular/core';
import { BaseResourceService } from '../../models/services/base-resource.service';
import { Auditoria } from '../../entidade/comum/auditoria.model';
import { map, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuditoriaService extends BaseResourceService<Auditoria> {

  constructor(
    protected injector: Injector
  ) {
    super(`auditorias`, injector);
  }

  public getAlvos(): Observable<Array<string>> {
    return this.http.get<Array<string>>(
      `${this.login.cidade.id}/${this.api}/alvos`, this.httpOptions()).pipe(
        map(res => res),
        catchError(err => this.handleError(err))
      );
  }


}
