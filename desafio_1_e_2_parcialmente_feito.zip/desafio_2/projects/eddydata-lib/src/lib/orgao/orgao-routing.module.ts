import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrgaoShwComponent } from './orgao-shw/orgao-shw.component';
import { OrgaoLstComponent } from './orgao-lst/orgao-lst.component';
import { AuthGuard } from '../util/auth.guard';

const routes: Routes = [
  { path: '', component: OrgaoLstComponent, canActivate: [AuthGuard] },
  { path: ':id/editar', component: OrgaoShwComponent, canActivate: [AuthGuard] }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OrgaoRoutingModule { }
