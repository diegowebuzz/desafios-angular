import { Component, Injector, ElementRef, ViewChild } from '@angular/core';
import { distinctUntilChanged, switchMap, takeUntil } from 'rxjs/operators';
import { of } from 'rxjs';
import { ImageCroppedEvent } from 'ngx-image-cropper';
import { MessageService } from 'primeng/api';
import { OrgaoService } from '../service/orgao.service';
import { BaseResourceFormComponent } from '../../models/base-resource-form';
import { Orgao } from '../../entidade/comum/orgao.model';
import { LoginContabil } from '../../entidade/login/login-contabil';
import { GlobalService } from '../../util/global.service';
import { FuncaoService } from '../../util/funcao.service';

@Component({
  selector: 'lib-orgao-shw',
  templateUrl: './orgao-shw.component.html'
})
export class OrgaoShwComponent extends BaseResourceFormComponent<Orgao, LoginContabil> {

  /**
   * Declaração de variáveis
   */
  @ViewChild('codigo') inputField: ElementRef;

  public imageChangedEvent: any = '';
  public listaEspecies: Array<any>;

  /**
   * Construtor com as injeções de dependencias
   */
  constructor(
    private messageService: MessageService,
    protected injector: Injector,
    protected globalService: GlobalService,
    protected funcaoService: FuncaoService,
    protected orgaoService: OrgaoService) {
    super(new Orgao(), injector, Orgao.converteJson, orgaoService);
  }

  // ========================================================================
  //                        MÉTODOS ABSTRAÍDOS
  // ========================================================================

  protected criarCamposForm(): void {
    this.entidadeForm = this.fb.group({
      id: [null],
      codigo: [null],
      nome: [null],
      cnpj: [null],
      endereco: [null],
      bairro: [null],
      cep: [null],
      email: [null],
      siafi: [null],
      ativo: [null],
      site: [null],
      telefone: [null],
      especie: [null],
      tribunal: [null],
      cidade: [null],
      brasao: this.fb.group({
        id: [null],
        brasao: [null],
        orgao: [this.entidade],
      })
    });

    this.entidadeForm.get('codigo').statusChanges
      .pipe(
        distinctUntilChanged(),
        switchMap(status => status === 'VALID' && !this.entidade.id ?
          this.orgaoService.obterPorCodigo(this.entidadeForm.get('codigo').value, this.login.cidade.id)
          : of({})
        )
      )
      .pipe(takeUntil(this.unsubscribe))
      .subscribe(dados => dados && !this.entidade.id ?
        this.messageService.add({ severity: 'error', summary: 'Atenção', detail: 'Código já esta cadastrado!' }) : {});

  }

  protected parametrosExtras(): {} {
    return { relations: 'cidade,brasao' };
  }

  protected afterLoad() {
  }

  protected afterInit(): void {
    this.listaEspecies = this.globalService.obterListaTipoOrgaos();
  }

  protected campoFoco(): ElementRef {
    return this.inputField;
  }

  protected beforeSubmit(): void {

    this.entidadeForm.get('cidade').setValue(this.login.cidade);
  }

  protected afterSubmit(entidade: Orgao): void {
  }

  fileChangeEvent(event: any): void {
    this.imageChangedEvent = event;
  }

  imageCropped(event: ImageCroppedEvent) {
    this.entidadeForm.get('brasao').get('brasao').setValue(event.base64);
  }
}
