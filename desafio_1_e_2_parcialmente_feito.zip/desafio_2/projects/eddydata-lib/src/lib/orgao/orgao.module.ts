import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AutoCompleteModule } from 'primeng/autocomplete';
import { IMaskModule } from 'angular-imask';
import { MessageService } from 'primeng/api';
import { ImageCropperModule } from 'ngx-image-cropper';
import { CommonModule } from '@angular/common';
import { OrgaoRoutingModule } from './orgao-routing.module';
import { InputMaskModule } from 'primeng/inputmask';
import { ToastModule } from 'primeng/toast';
import { OrgaoLstComponent } from './orgao-lst/orgao-lst.component';
import { OrgaoShwComponent } from './orgao-shw/orgao-shw.component';
import { SharedModule } from '../util/shared.module';

@NgModule({
  declarations: [OrgaoLstComponent, OrgaoShwComponent],
  imports: [
    CommonModule,
    OrgaoRoutingModule,
    SharedModule,
    FormsModule,
    AutoCompleteModule,
    ImageCropperModule,
    IMaskModule,
    InputMaskModule,
    ToastModule
  ],
  exports: [
    OrgaoLstComponent,
    OrgaoShwComponent
  ],
  providers: [MessageService]
})
export class OrgaoModule { }
