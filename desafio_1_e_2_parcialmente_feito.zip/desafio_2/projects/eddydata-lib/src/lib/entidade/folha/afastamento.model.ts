// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Cidade } from '../geo/cidade.model';

export class Afastamento extends BaseResourceModel {
  constructor(
    public id?: number,
    public codigo?: string,
    public nome?: string,
    public tipo?: string,
    public cidade?: Cidade,
  ) {
    super();
  }
  static converteJson(json: any): Afastamento {
    return Object.assign(new Afastamento(), json);
  }
}
