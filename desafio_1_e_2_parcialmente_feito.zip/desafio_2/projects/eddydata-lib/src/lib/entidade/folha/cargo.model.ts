// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Cidade } from '../geo/cidade.model';
import { CargoHistorico } from './cargo-historico.model';

export class Cargo extends BaseResourceModel {
  constructor(
    public id?: number,
    public nome?: string,
    public cbo?: string,
    public escolaridade?: string,
    public provimento?: string,
    public atividade?: string,
    public norma?: string,
    public regime_juridico?: string,
    public vagas?: number,
    public salario_base?: number,
    public cidade?: Cidade,
    public aux?: number,
    public ativo?: boolean,
    public tipo?: 'C' | 'P',
    public historicos?: CargoHistorico[],
  ) {
    super();
  }
  static converteJson(json: any): Cargo {
    return Object.assign(new Cargo(), json);
  }
}
