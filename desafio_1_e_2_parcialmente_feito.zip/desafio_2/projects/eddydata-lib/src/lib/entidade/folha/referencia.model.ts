// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Orgao } from '../comum/orgao.model';

export class Referencia extends BaseResourceModel {
  constructor(
    public id?: number,
    public descricao?: string,
    public calculo?: string,
    public mes?: number,
    public ano?: number,
    public orgao?: Orgao,
    ) {
    super();
  }
  static converteJson(json: any): Referencia {
    return Object.assign(new Referencia(), json);
  }
}
