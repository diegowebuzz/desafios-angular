// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { ContaBancaria } from './conta-bancaria.model';
import { Exercicio } from '../comum/exercicio.model';
import { Orgao } from '../comum/orgao.model';
import { Recurso } from '../planejamento/recurso.model';
import { Usuario } from '../comum/usuario.model';

export class OrdemPagamento extends BaseResourceModel {
  constructor(
    public id?: number,
    public mes?: number,
    public aux?: number,
    public numero?: number,
    public data_op?: Date,
    public baixado?: boolean,
    public unico_fornecedor?: boolean,
    public anulado?: boolean,
    public fatura?: boolean,
    public exportado_febraban?: boolean,
    public pagamento_retencao?: boolean,
    public conta?: ContaBancaria,
    public exercicio?: Exercicio,
    public orgao?: Orgao,
    public usuario_cadastro?: Usuario,
  ) {
    super();
  }

  static converteJson(json: any): OrdemPagamento {
    return Object.assign(new OrdemPagamento(), json);
  }
}
