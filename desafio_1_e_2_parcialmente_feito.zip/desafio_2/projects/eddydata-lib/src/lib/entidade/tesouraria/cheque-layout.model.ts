// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Banco } from './banco.model';
import { Orgao } from '../comum/orgao.model';

export class ChequeLayout extends BaseResourceModel {
  constructor(
    public id?: number,
    public nome?: string,
    public valor_x?: number,
    public valor_y?: number,
    public valor_extenso1_x?: number,
    public valor_extenso1_y?: number,
    public valor_extenso2_x?: number,
    public valor_extenso2_y?: number,
    public beneficiario_x?: number,
    public beneficiario_y?: number,
    public cidade_x?: number,
    public cidade_y?: number,
    public dia_x?: number,
    public dia_y?: number,
    public mes_x?: number,
    public mes_y?: number,
    public ano_x?: number,
    public ano_y?: number,
    public canhoto_data_x?: number,
    public canhoto_data_y?: number,
    public canhoto_beneficiario_x?: number,
    public canhoto_beneficiario_y?: number,
    public canhoto_valor_x?: number,
    public canhoto_valor_y?: number,
    public cheque_altura?: number,
    public usar_canhoto?: boolean,
    public largura_folha?: number,
    public altura_folha?: number,
    public margem_esquerda?: number,
    public margem_superior?: number,
    public dois_digitos_ano?: boolean,
    public banco?: Banco,
    public orgao?: Orgao,
  ) {
    super();
  }

  static converteJson(json: any): ChequeLayout {
    return Object.assign(new ChequeLayout(), json);
  }
}
