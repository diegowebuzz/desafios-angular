// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { ContaBancaria } from './conta-bancaria.model';
import { Exercicio } from '../comum/exercicio.model';
import { Orgao } from '../comum/orgao.model';
import { EmpenhoExtra } from '../contabil/empenho-extra.model';
import { Usuario } from '../comum/usuario.model';

export class PagamentoExtra extends BaseResourceModel {
  constructor(
    public id?: number,
    public mes?: number,
    public parcela?: number,
    public data_pagamento?: Date,
    public especie?: string,
    public documento?: string,
    public historico?: string,
    public valor_pago?: number,
    public valor_retido?: number,
    public aux?: number,
    public impresso?: boolean,
    public anulacao?: boolean,
    public conta?: ContaBancaria,
    public exercicio?: Exercicio,
    public orgao?: Orgao,
    public empenho?: EmpenhoExtra,
    public usuario_cadastro?: Usuario,
    public data_cadastro?: Date,
    public data_alteracao?: Date,

  ) {
    super();
  }

  static converteJson(json: any): PagamentoExtra {
    return Object.assign(new PagamentoExtra(), json);
  }
}
