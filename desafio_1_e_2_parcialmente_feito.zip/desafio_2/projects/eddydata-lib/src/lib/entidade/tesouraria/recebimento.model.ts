// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { FichaReceita } from '../planejamento/ficha-receita.model';
import { ContaBancaria } from './conta-bancaria.model';
import { Orgao } from '../comum/orgao.model';
import { Exercicio } from '../comum/exercicio.model';
import { Favorecido } from '../compra/favorecido.model';
import { Contrato } from '../compra/contrato.model';
import { Convenio } from '../compra/convenio.model';
import { Retencao } from '../contabil/retencao.model';

export class Recebimento extends BaseResourceModel {
  constructor(
    public id?: number,
    public data_recebimento?: Date,
    public data_referencia?: Date,
    public mes?: number,
    public aux?: number,
    public especie?: string,
    public guia?: string,
    public historico?: string,
    public restituicao?: boolean,
    public retido?: boolean,
    public valor_recebido?: number,
    public ficha?: FichaReceita,
    public conta?: ContaBancaria,
    public data_cadastro?: Date,
    public data_alteracao?: Date,
    public orgao?: Orgao,
    public exercicio?: Exercicio,
    public favorecido?: Favorecido,
    public retencao?: Retencao,
    public contrato?: Contrato,
    public convenio?: Convenio,
  ) {
    super();
  }

  static converteJson(json: any): Recebimento {
    return Object.assign(new Recebimento(), json);
  }
}
