// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { ContaBancaria } from './conta-bancaria.model';
import { Recurso } from '../planejamento/recurso.model';

export class ContaBancariaRecurso extends BaseResourceModel {
  constructor(
    public id?: number,
    public conta?: ContaBancaria,
    public recurso?: Recurso,
    public aplicacao?: Recurso,
    public convenio?: Recurso,
    public aux?: number,
    public editavel?: boolean
  ) {
    super();
  }

  static converteJson(json: any): ContaBancariaRecurso {
    return Object.assign(new ContaBancariaRecurso(), json);
  }
}
