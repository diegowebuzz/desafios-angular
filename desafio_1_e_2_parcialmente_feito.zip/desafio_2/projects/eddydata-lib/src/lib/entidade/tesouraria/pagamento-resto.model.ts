// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { ContaBancaria } from './conta-bancaria.model';
import { Exercicio } from '../comum/exercicio.model';
import { Orgao } from '../comum/orgao.model';
import { LiquidacaoResto } from '../contabil/liquidacao-resto.model';

export class PagamentoResto extends BaseResourceModel {
  constructor(
    public id?: number,
    public mes?: number,
    public data_pagamento?: Date,
    public especie?: string,
    public documento?: string,
    public historico?: string,
    public valor_pago?: number,
    public valor_retido?: number,
    public valor_liquido?: number,
    public aux?: number,
    public impresso?: boolean,
    public anulacao?: boolean,
    public conta?: ContaBancaria,
    public exercicio?: Exercicio,
    public orgao?: Orgao,
    public liquidacao?: LiquidacaoResto,
    public data_cadastro?: Date,
    public data_alteracao?: Date,

  ) {
    super();
  }

  static converteJson(json: any): PagamentoResto {
    return Object.assign(new PagamentoResto(), json);
  }
}
