// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Orgao } from '../comum/orgao.model';
import { Banco } from './banco.model';
import { ContaBancariaSaldo } from './conta-bancaria-saldo.model';

export class ContaBancaria extends BaseResourceModel {
  constructor(
    public id?: number,
    public nome?: string,
    public agencia?: string,
    public agencia_nome?: string,
    public agencia_digito?: string,
    public tipo_conta?: string,
    public digito_agencia?: string,
    public numero_conta?: string,
    public digito_conta?: string,
    public gerente?: string,
    public assinatura?: string,
    public cargo?: string,
    public ativo?: boolean,
    public caixa?: boolean,
    public aux?: number,
    public orgao?: Orgao,
    public banco?: Banco,
    public data_cadastro?: Date,
    public data_alteracao?: Date,
    public saldos?: ContaBancariaSaldo[]
  ) {
    super();
  }

  static converteJson(json: any): ContaBancaria {
    return Object.assign(new ContaBancaria(), json);
  }
}
