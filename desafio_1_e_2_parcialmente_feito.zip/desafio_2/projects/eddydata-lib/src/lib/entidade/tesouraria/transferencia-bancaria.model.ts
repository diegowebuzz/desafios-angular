// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { ContaBancaria } from './conta-bancaria.model';
import { Exercicio } from '../comum/exercicio.model';
import { Orgao } from '../comum/orgao.model';

export class TransferenciaBancaria extends BaseResourceModel {
  constructor(
    public id?: number,
    public data_transfere?: Date,
    public data_referencia?: Date,
    public mes?: number,
    public especie?: string,
    public documento?: string,
    public tipo?: string,
    public historico?: string,
    public valor_transferido?: number,
    public conta_recebedora?: ContaBancaria,
    public conta_pagadora?: ContaBancaria,
    public exercicio?: Exercicio,
    public orgao?: Orgao,
    public data_cadastro?: Date,
    public data_alteracao?: Date,
  ) {
    super();
  }

  static converteJson(json: any): TransferenciaBancaria {
    return Object.assign(new TransferenciaBancaria(), json);
  }
}
