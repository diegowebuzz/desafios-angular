// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { FichaExtra } from '../contabil/ficha-extra.model';
import { ContaBancaria } from './conta-bancaria.model';
import { Exercicio } from '../comum/exercicio.model';
import { Orgao } from '../comum/orgao.model';

export class RecebimentoExtra extends BaseResourceModel {
  constructor(
    public id?: number,
    public data_recebimento?: Date,
    public data_referencia?: Date,
    public mes?: number,
    public especie?: string,
    public guia?: string,
    public historico?: string,
    public valor_recebido?: number,
    public retido?: boolean,
    public ficha?: FichaExtra,
    public conta?: ContaBancaria,
    public exercicio?: Exercicio,
    public orgao?: Orgao,
    public aux?: number,
    public data_cadasxtro?: Date,
    public data_alteracao?: Date,
  ) {
    super();
  }

  static converteJson(json: any): RecebimentoExtra {
    return Object.assign(new RecebimentoExtra(), json);
  }
}
