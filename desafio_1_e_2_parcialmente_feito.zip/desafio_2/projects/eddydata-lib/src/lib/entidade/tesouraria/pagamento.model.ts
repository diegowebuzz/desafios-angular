// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { ContaBancaria } from './conta-bancaria.model';
import { Exercicio } from '../comum/exercicio.model';
import { Liquidacao } from '../contabil/liquidacao.model';
import { Orgao } from '../comum/orgao.model';
import { Recurso } from '../planejamento/recurso.model';
import { Usuario } from '../comum/usuario.model';

export class Pagamento extends BaseResourceModel {
  constructor(
    public id?: number,
    public mes?: number,
    public data_pagamento?: Date,
    public especie?: string,
    public documento?: string,
    public historico?: string,
    public valor_pago?: number,
    public valor_retido?: number,
    public aux?: number,
    public impresso?: boolean,
    public anulacao?: boolean,
    public conta?: ContaBancaria,
    public exercicio?: Exercicio,
    public orgao?: Orgao,
    public liquidacao?: Liquidacao,
    public recurso?: Recurso,
    public aplicacao?: Recurso,
    public variavel?: Recurso,
    public usuario_cadastro?: Usuario,
    public data_cadastro?: Date,
    public data_alteracao?: Date,

  ) {
    super();
  }

  static converteJson(json: any): Pagamento {
    return Object.assign(new Pagamento(), json);
  }
}
