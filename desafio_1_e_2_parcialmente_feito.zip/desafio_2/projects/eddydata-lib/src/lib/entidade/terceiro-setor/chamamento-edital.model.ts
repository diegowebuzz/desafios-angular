// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Chamamento } from './chamamento.model';

export class ChamamentoEdital extends BaseResourceModel {
  constructor(
    public id?: number,
    public nome?: string,
    public caminho?: string,
    public tipo?: string,
    public tamanho?: string,
    public chamamento?: Chamamento
  ) {
    super();
  }
  static converteJson(json: any): ChamamentoEdital {
    return Object.assign(new ChamamentoEdital(), json);
  }
}
