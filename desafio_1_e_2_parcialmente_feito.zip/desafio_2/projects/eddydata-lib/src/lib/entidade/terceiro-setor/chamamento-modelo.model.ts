// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Orgao } from '../comum/orgao.model';

export class ChamamentoModelo extends BaseResourceModel {
  constructor(
    public id?: number,
    public nome?: string,
    public tipo?: string,
    public orgao?: Orgao
  ) {
    super();
  }
  static converteJson(json: any): ChamamentoModelo {
    return Object.assign(new ChamamentoModelo(), json);
  }
}
