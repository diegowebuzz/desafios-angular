// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { ChamamentoFavorecido } from './chamamento-favorecido.model';
import { ChamamentoPontuacao } from './chamamento-pontuacao.model';

export class CredenciamentoPontuacao extends BaseResourceModel {
  constructor(
    public id?: number,
    public situacao?: string,
    public ponto?: number,
    public pontuacao?: ChamamentoPontuacao,
    public favorecido?: ChamamentoFavorecido,
    public editavel?: boolean
  ) {
    super();
  }
  static converteJson(json: any): CredenciamentoPontuacao {
    return Object.assign(new CredenciamentoPontuacao(), json);
  }
}
