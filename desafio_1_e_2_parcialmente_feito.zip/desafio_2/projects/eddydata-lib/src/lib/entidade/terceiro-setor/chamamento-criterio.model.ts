// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Chamamento } from './chamamento.model';

export class ChamamentoCriterio extends BaseResourceModel {
  constructor(
    public id?: number,
    public descricao?: string,
    public atende?: boolean,
    public chamamento?: Chamamento,
    public editavel?: boolean
  ) {
    super();
  }
  static converteJson(json: any): ChamamentoCriterio {
    return Object.assign(new ChamamentoCriterio(), json);
  }
}
