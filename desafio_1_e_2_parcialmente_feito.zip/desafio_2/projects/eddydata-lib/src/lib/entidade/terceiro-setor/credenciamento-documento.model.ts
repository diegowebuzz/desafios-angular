// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { ChamamentoFavorecido } from './chamamento-favorecido.model';
import { ChamamentoCriterio } from './chamamento-criterio.model';

export class CredenciamentoDocumento extends BaseResourceModel {
  constructor(
    public id?: number,
    public situacao?: string,
    public observacao?: string,
    public nome?: string,
    public caminho?: string,
    public tipo?: string,
    public tamanho?: number,
    public criterio?: ChamamentoCriterio,
    public favorecido?: ChamamentoFavorecido,
    public editavel?: boolean
  ) {
    super();
  }
  static converteJson(json: any): CredenciamentoDocumento {
    return Object.assign(new CredenciamentoDocumento(), json);
  }
}
