// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Favorecido } from '../compra/favorecido.model';
import { MovimentoEstoque } from './movimento-estoque.model';
import { ProdutoConcentracao } from './produto-concentracao.model';
import { ProdutoUnidade } from './produto-unidade.model';

export class MovimentoItemEstoque extends BaseResourceModel {
  constructor(
    public id?: number,
    public fabricacao?: Date,
    public vencimento?: Date,
    public lote?: string,
    public valor_unitario?: number,
    public qtde?: number,
    public produto_unidade?: ProdutoUnidade,
    public fabricante?: Favorecido,
    public concentracao?: ProdutoConcentracao,
    public movimento?: MovimentoEstoque,
    public editavel?: boolean
  ) {
    super();
  }

  static converteJson(json: any): MovimentoItemEstoque {
    return Object.assign(new MovimentoItemEstoque(), json);
  }
}
