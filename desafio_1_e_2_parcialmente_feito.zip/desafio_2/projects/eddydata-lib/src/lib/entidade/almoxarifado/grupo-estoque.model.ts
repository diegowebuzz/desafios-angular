// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Cidade } from '../geo/cidade.model';
import { GrupoAlmoxarifado } from './grupo-almoxarifado.model';
import { SubGrupoEstoque } from './sub-grupo-estoque.model';

export class GrupoEstoque extends BaseResourceModel {
  constructor(
    public id?: number,
    public codigo?: string,
    public nome?: string,
    public bec?: boolean,
    public medicamento?: boolean,
    public cidade?: Cidade,
    public estoques?: GrupoAlmoxarifado[],
    public subgrupos?: SubGrupoEstoque[]
  ) {
    super();
  }
  static converteJson(json: any): GrupoEstoque {
    return Object.assign(new GrupoEstoque(), json);
  }
}
