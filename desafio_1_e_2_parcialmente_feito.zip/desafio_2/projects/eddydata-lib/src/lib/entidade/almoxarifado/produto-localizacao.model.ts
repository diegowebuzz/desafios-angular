// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Produto } from './produto.model';

export class ProdutoLocalizacao extends BaseResourceModel {
  constructor(
    public id?: number,
    public sala?: string,
    public armario?: string,
    public prateleira?: string,
    public produto?: Produto,
  ) {
    super();
  }

  static converteJson(json: any): ProdutoLocalizacao {
    return Object.assign(new ProdutoLocalizacao(), json);
  }
}
