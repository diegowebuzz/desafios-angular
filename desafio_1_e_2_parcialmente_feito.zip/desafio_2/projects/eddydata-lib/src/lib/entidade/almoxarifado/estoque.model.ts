// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Orgao } from '../comum/orgao.model';
import { GrupoAlmoxarifado } from './grupo-almoxarifado.model';
import { Usuario } from '../comum/usuario.model';
import { SetorAlmoxarifado } from './setor-almoxarifado.model';

export class Estoque extends BaseResourceModel {
  constructor(
    public id?: number,
    public nome?: string,
    public telefone?: string,
    public local_entrega?: string,
    public email?: string,
    public aux?: number,
    public orgao?: Orgao,
    public grupos?: GrupoAlmoxarifado[],
    public setores?: SetorAlmoxarifado[],
    public usuarios?: Usuario[],
  ) {
    super();
  }
  static converteJson(json: any): Estoque {
    return Object.assign(new Estoque(), json);
  }
}
