// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Cidade } from '../geo/cidade.model';

export class UnidadeFornecimento extends BaseResourceModel {
  constructor(
    public id?: number,
    public nome?: string,
    public ativo?: boolean,
    public bec?: boolean,
    public cidade?: Cidade
  ) {
    super();
  }
  static converteJson(json: any): UnidadeFornecimento {
    return Object.assign(new UnidadeFornecimento(), json);
  }
}
