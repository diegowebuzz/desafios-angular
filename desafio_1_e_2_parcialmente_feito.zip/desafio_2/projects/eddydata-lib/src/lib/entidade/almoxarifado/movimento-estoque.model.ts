// tslint:disable: variable-name
import { EspecieAlmoxarifado } from '../../components/types';
import { BaseResourceModel } from '../../models/base-resource.model';
import { Favorecido } from '../compra/favorecido.model';
import { Exercicio } from '../comum/exercicio.model';
import { Orgao } from '../comum/orgao.model';
import { Pessoa } from '../comum/pessoa.model';
import { Usuario } from '../comum/usuario.model';
import { SetorAlmoxarifado } from './setor-almoxarifado.model';
import { MovimentoItemEstoque } from './movimento-item-estoque.model';

export class MovimentoEstoque extends BaseResourceModel {
  constructor(
    public id?: number,
    public data_movimento?: Date,
    public data_documento?: Date,
    public documento?: string,
    public especie?: EspecieAlmoxarifado,
    public entrada?: boolean,
    public consumo_direto?: boolean,
    public recebedor?: Pessoa,
    public setorAlmoxarifado?: SetorAlmoxarifado,
    public favorecido?: Favorecido,
    public exercicio?: Exercicio,
    public orgao?: Orgao,
    public data_estorno?: Date,
    public motivo_estorno?: string,
    public usuario_estorno?: Usuario,
    public itens?: MovimentoItemEstoque[]
  ) {
    super();
  }

  static converteJson(json: any): MovimentoEstoque {
    return Object.assign(new MovimentoEstoque(), json);
  }
}
