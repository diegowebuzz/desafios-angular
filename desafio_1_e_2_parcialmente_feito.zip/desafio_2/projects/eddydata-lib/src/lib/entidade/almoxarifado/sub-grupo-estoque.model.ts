// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { GrupoEstoque } from './grupo-estoque.model';
import { Material } from './material.model';

export class SubGrupoEstoque extends BaseResourceModel {
  constructor(
    public id?: number,
    public codigo?: string,
    public nome?: string,
    public bec?: boolean,
    public grupo?: GrupoEstoque,
    public editavel?: boolean,
    public materiais?: Material[]
  ) {
    super();
  }
  static converteJson(json: any): SubGrupoEstoque {
    return Object.assign(new SubGrupoEstoque(), json);
  }
}
