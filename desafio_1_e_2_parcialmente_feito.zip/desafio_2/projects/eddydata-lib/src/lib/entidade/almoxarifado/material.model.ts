// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { SubGrupoEstoque } from './sub-grupo-estoque.model';
import { Produto } from './produto.model';

export class Material extends BaseResourceModel {
  constructor(
    public id?: number,
    public nome?: string,
    public codigo?: string,
    public contabilizar?: boolean,
    public servico?: boolean,
    public bec?: boolean,
    public sub_grupo?: SubGrupoEstoque,
    public produtos?: Produto[]
  ) {
    super();
  }
  static converteJson(json: any): Material {
    return Object.assign(new Material(), json);
  }
}
