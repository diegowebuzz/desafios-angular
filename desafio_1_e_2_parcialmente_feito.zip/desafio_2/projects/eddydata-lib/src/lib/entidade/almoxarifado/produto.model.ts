// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Material } from './material.model';
import { ProdutoLocalizacao } from './produto-localizacao.model';
import { ProdutoMedicamento } from './produto-medicamento.model';
import { ProdutoUnidade } from './produto-unidade.model';

export class Produto extends BaseResourceModel {
  constructor(
    public id?: number,
    public nome?: string,
    public codigo?: string,
    public descricao?: string,
    public bec?: boolean,
    public aux?: string,
    public curva?: 'A' | 'B' | 'C',
    public estoque_min?: number,
    public estoque_max?: number,
    public material?: Material,
    public localizacao?: ProdutoLocalizacao,
    public medicamento?: ProdutoMedicamento,
    public unidades?: ProdutoUnidade[],
  ) {
    super();
  }

  static converteJson(json: any): Produto {
    return Object.assign(new Produto(), json);
  }
}
