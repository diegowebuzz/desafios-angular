// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Orgao } from '../comum/orgao.model';
import { Unidade } from '../planejamento/unidade.model';
import { SetorAlmoxarifado } from './setor-almoxarifado.model';

export class Setor extends BaseResourceModel {
  constructor(
    public id?: number,
    public ativo?: boolean,
    public sigla?: string,
    public codigo?: string,
    public nome?: string,
    public email?: string,
    public telefone?: string,
    public cep?: string,
    public endereco?: string,
    public bairro?: string,
    public responsavel?: string,
    public cargo?: string,
    public setor_protocolo?: boolean,
    public orgao?: Orgao,
    public unidade?: Unidade,
    public estoques?: SetorAlmoxarifado[]
    ) {
    super();
  }
  static converteJson(json: any): Setor {
    return Object.assign(new Setor(), json);
  }
}
