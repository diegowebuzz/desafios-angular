import { BaseResourceModel } from '../../models/base-resource.model';
import { Convenio } from './convenio.model';
import { Empenho } from '../contabil/empenho.model';

// tslint:disable: variable-name
export class ConvenioPrestacao extends BaseResourceModel {
  constructor(
    public valor_previsao?: number,
    public data_previsao?: Date,
    public valor_prestacao?: number,
    public data_prestacao?: Date,
    public convenio?: Convenio,
    public empenho?: Empenho,
    public editavel?: boolean
    ) {
    super();
  }
  static converteJson(json: any): ConvenioPrestacao {
    return Object.assign(new ConvenioPrestacao(), json);
  }
}
