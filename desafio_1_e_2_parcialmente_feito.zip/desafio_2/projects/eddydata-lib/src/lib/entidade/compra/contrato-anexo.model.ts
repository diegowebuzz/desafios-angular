// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Contrato } from './contrato.model';

export class ContratoAnexo extends BaseResourceModel {
  constructor(
    public id?: number,
    public nome?: string,
    public caminho?: string,
    public tipo?: string,
    public documento?: string,
    public descricao?: string,
    public tamanho?: number,
    public contrato?: Contrato,
    public editavel?: boolean,
  ) {
    super();
  }

  static converteJson(json: any): ContratoAnexo {
    return Object.assign(new ContratoAnexo(), json);
  }
}
