// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Favorecido } from './favorecido.model';
import { Orgao } from '../comum/orgao.model';
import { Exercicio } from '../comum/exercicio.model';
import { FichaDespesa } from '../planejamento/ficha-despesa.model';
import { Despesa } from '../planejamento/despesa.model';
import { Modalidade } from '../licitacao/modalidade.model';
import { Licitacao } from '../licitacao/licitacao.model';
import { Convenio } from './convenio.model';
import { Contrato } from './contrato.model';
import { CompraItem } from './compra-item.model';
import { Usuario } from '../comum/usuario.model';
import { Rcms } from './rcms.model';

export class Compra extends BaseResourceModel {
  constructor(
    public id?: number,
    public requerente?: string,
    public numero?: number,
    public tipo_compra?: string,
    public data_compra?: Date,
    public data_previsao?: Date,
    public documento?: string,
    public subelemento?: Despesa,
    public processo?: string,
    public observacao?: string,
    public contrato?: Contrato,
    public convenio?: Convenio,
    public licitacao?: Licitacao,
    public modalidade?: Modalidade,
    public ficha?: FichaDespesa,
    public favorecido?: Favorecido,
    public rcms?: Rcms,
    public rcms_numero?: number,
    public orgao?: Orgao,
    public exercicio?: Exercicio,
    public usuario?: Usuario,
    public itens?: CompraItem[]
  ) {
    super();
  }
  static converteJson(json: any): Compra {
    return Object.assign(new Compra(), json);
  }
}
