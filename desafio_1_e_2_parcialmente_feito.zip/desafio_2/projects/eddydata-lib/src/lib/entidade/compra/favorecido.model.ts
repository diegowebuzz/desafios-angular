// tslint:disable: variable-name
import { Cidade } from '../geo/cidade.model';
import { BaseResourceModel } from '../../models/base-resource.model';
import { FavorecidoTipo } from './favorecido-tipo.model';

export class Favorecido extends BaseResourceModel {
    constructor(
        public id?: number,
        public nome?: string,
        public cpf_cnpj?: string,
        public nome_fantasia?: string,
        public cep?: string,
        public endereco?: string,
        public num_endereco?: string,
        public bairro?: string,
        public municipio?: string,
        public uf?: string,
        public ddd_fone?: string,
        public telefone?: string,
        public pis?: string,
        public email?: string,
        public tipo?: FavorecidoTipo,
        public url?: string,
        public autarquia?: boolean,
        public autorizado?: boolean,
        public servidor?: boolean,
        public simples_nacional?: boolean,
        public gasto_fixo?: boolean,
        public aux?: number,
        public terceiro_setor?: boolean,
        public cidade?: Cidade,
        public data_cadastro?: Date,
        public data_alteracao?: Date,
        public tipo_fornecedor?: string,
        public responsavel?: string
    ) {
        super();
    }
    static converteJson(json: any): Favorecido {
        return Object.assign(new Favorecido(), json);
    }
}
