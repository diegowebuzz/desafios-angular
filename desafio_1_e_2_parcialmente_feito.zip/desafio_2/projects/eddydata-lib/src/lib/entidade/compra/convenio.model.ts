// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Favorecido } from './favorecido.model';
import { Orgao } from '../comum/orgao.model';
import { Recurso } from '../planejamento/recurso.model';
import { Unidade } from '../planejamento/unidade.model';

export class Convenio extends BaseResourceModel {
  constructor(
    public id?: number,
    public numero?: string,
    public ano?: number,
    public processo?: string,
    public especie?: string,
    public tipo_convenio?: string,
    public legislacao?: string,
    public autorizacao?: string,
    public lei_numero?: string,
    public convenente?: string,
    public data_assinatura?: Date,
    public data_inicio?: Date,
    public data_termino?: Date,
    public data_prestacao?: Date,
    public data_quitacao?: Date,
    public tipo_fornecedor?: 'F' | 'C',
    public valor_convenio?: number,
    public valor_contrapartida?: number,
    public saldo_anterior?: number,
    public valor_aplicacao?: number,
    public valor_devolvido?: number,
    public valor_outros?: number,
    public valor_recurso?: number,
    public objeto?: string,
    public finalidade?: string,
    public aditivo?: string,
    public enviar_email?: boolean,
    public orgao?: Orgao,
    public favorecido?: Favorecido,
    public recurso?: Recurso,
    public aplicacao?: Recurso,
    public unidade?: Unidade,
    public parente?: Convenio
  ) {
    super();
  }
  static converteJson(json: any): Convenio {
    return Object.assign(new Convenio(), json);
  }
}
