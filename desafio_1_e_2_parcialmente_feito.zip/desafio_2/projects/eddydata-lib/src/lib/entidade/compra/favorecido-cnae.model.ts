import { BaseResourceModel } from '../../models/base-resource.model';
import { Favorecido } from './favorecido.model';
import { Cnae } from '../comum/cnae.model';

export class FavorecidoCnae extends BaseResourceModel {
  constructor(
    public id?: number,
    public cnae?: Cnae,
    public favorecido?: Favorecido,
    public editavel?: boolean
    ) {
    super();
  }
  static converteJson(json: any): FavorecidoCnae {
    return Object.assign(new FavorecidoCnae(), json);
  }
}
