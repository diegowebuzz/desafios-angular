import { BaseResourceModel } from '../../models/base-resource.model';

export class Prazo extends BaseResourceModel {
  constructor(
    public id?: number,
    public nome?: string,
  ) {
    super();
  }
  static converteJson(json: any): Prazo {
    return Object.assign(new Prazo(), json);
  }
}
