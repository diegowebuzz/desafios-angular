// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Compra } from './compra.model';
import { ProdutoUnidade } from '../almoxarifado/produto-unidade.model';
import { Produto } from '../almoxarifado/produto.model';

export class CompraItem extends BaseResourceModel {
  constructor(
    public id?: number,
    public aux?: number,
    public quantidade?: number,
    public valor_unitario?: number,
    public valor_total?: number,
    public valor_desconto?: number,
    public valor_icmsipi?: number,
    public produto?: Produto,
    public produto_unidade?: ProdutoUnidade,
    public compra?: Compra,
    public editavel?: boolean
  ) {
    super();
  }
  static converteJson(json: any): CompraItem {
    return Object.assign(new CompraItem(), json);
  }
}
