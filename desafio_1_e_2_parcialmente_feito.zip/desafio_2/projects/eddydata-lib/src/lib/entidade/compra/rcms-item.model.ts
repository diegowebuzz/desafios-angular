// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Rcms } from './rcms.model';
import { ProdutoUnidade } from '../almoxarifado/produto-unidade.model';

export class RcmsItem extends BaseResourceModel {
  constructor(
    public id?: number,
    public aux?: number,
    public quantidade?: number,
    public produto_unidade?: ProdutoUnidade,
    public rcms?: Rcms,
    public editavel?: boolean
  ) {
    super();
  }
  static converteJson(json: any): RcmsItem {
    return Object.assign(new RcmsItem(), json);
  }
}
