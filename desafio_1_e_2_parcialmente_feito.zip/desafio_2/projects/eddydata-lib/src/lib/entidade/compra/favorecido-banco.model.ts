// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Favorecido } from './favorecido.model';
import { Banco } from '../tesouraria/banco.model';

export class FavorecidoBanco extends BaseResourceModel {
  constructor(
    public id?: number,
    public agencia?: string,
    public numero_conta?: string,
    public tipo_conta?: string,
    public banco?: Banco,
    public favorecido?: Favorecido,
    public ativo?: boolean,
    public editavel?: boolean
    ) {
    super();
  }
  static converteJson(json: any): FavorecidoBanco {
    return Object.assign(new FavorecidoBanco(), json);
  }
}
