// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Orgao } from '../comum/orgao.model';
import { Exercicio } from '../comum/exercicio.model';
import { FichaDespesa } from '../planejamento/ficha-despesa.model';
import { Despesa } from '../planejamento/despesa.model';
import { Modalidade } from '../licitacao/modalidade.model';
import { Licitacao } from '../licitacao/licitacao.model';
import { Convenio } from './convenio.model';
import { Contrato } from './contrato.model';
import { Prazo } from './prazo.model';
import { Setor } from '../almoxarifado/setor.model';

export class Rcms extends BaseResourceModel {
  constructor(
    public id?: number,
    public requerente?: string,
    public prioridade?: string,
    public numero?: number,
    public tipo_rcms?: string,
    public data_rcms?: Date,
    public data_vencimento?: Date,
    public adiantamento?: boolean,
    public autorizado?: boolean,
    public em_cotacao?: boolean,
    public bloqueado_compra?: boolean,
    public compra_direta?: boolean,
    public encaminhado_gabinete?: boolean,
    public processo_licitatorio?: boolean,
    public subelemento?: Despesa,
    public processo?: string,
    public observacao?: string,
    public documento?: string,
    public contrato?: Contrato,
    public convenio?: Convenio,
    public licitacao?: Licitacao,
    public modalidade?: Modalidade,
    public ficha?: FichaDespesa,
    public prazo?: Prazo,
    public orgao?: Orgao,
    public exercicio?: Exercicio,
    public setor?: Setor
    ) {
    super();
  }
  static converteJson(json: any): Rcms {
    return Object.assign(new Rcms(), json);
  }
}
