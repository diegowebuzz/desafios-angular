// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Orgao } from '../comum/orgao.model';
import { Licitacao } from '../licitacao/licitacao.model';
import { Favorecido } from './favorecido.model';
import { Prazo } from './prazo.model';

export class Contrato extends BaseResourceModel {
  constructor(
    public id?: number,
    public numero?: string,
    public ano?: number,
    public data_assinatura?: Date,
    public data_inicio?: Date,
    public data_termino?: Date,
    public processo?: string,
    public tipo_contrato?: string,
    public contratacao?: string,
    public objeto?: string,
    public finalidade?: string,
    public aditivo?: number,
    public valor_contrato?: number,
    public valor_garantia?: number,
    public valor_caucao?: number,
    public enviar_email?: boolean,
    public parente?: Contrato,
    public orgao?: Orgao,
    public favorecido?: Favorecido,
    public licitacao?: Licitacao,
    public prazo?: Prazo,
    public data_alteracao?: Date,
    public data_cadastro?: Date
  ) {
    super();
  }
  static converteJson(json: any): Contrato {
    return Object.assign(new Contrato(), json);
  }
}
