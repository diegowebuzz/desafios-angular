// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Favorecido } from './favorecido.model';

export class FavorecidoResponsavel extends BaseResourceModel {
    constructor(
        public id?: number,
        public nome?: string,
        public cargo?: string,
        public cpf?: string,
        public rg?: string,
        public telefone?: string,
        public cep?: string,
        public endereco?: string,
        public num_endereco?: string,
        public bairro?: string,
        public municipio?: string,
        public email?: string,
        public data_nomeacao?: Date,
        public data_registro?: Date,
        public data_vigencia?: Date,
        public favorecido?: Favorecido,
        public data_cadastro?: Date,
        public data_alteracao?: Date,
        public editavel?: boolean
    ) {
        super();
    }
    static converteJson(json: any): FavorecidoResponsavel {
        return Object.assign(new FavorecidoResponsavel(), json);
    }
}
