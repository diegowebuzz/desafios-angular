export enum Pagina {

    'Órgãos' = '/orgaos',
    'Usuários' = '/usuarios',
    'Setores' = '/setores',
    'Agendamentos' = '/agendamentos',
    'Parâmetros de E-mail' = '/parametros-email',
    'Relatórios Personalizados' = '/relatorios-personalizados',
    'Exercícios e Assinaturas' = '/exercicios',

    'Estoques' = '/estoques',
    'Grupos de Estoque' = '/grupos-estoque',
    'Unidades de Fornecimento' = '/unidades-fornecimento',
    'Subgrupos de Estoque' = '/subgrupos-estoque',
    'Materiais' = '/materiais',
    'Produtos' = '/produtos',
    'Entradas' = '/entradas',
    'Saídas' = '/saidas',

    'Processos' = '/processos',
    'Fiscalizações' = '/fiscalizacoes',
    'Questionários' = '/questionarios',
    'Auditoria de Empenhos' = '/auditoria-empenhos',
    'Auditoria de Adiantamentos' = '/auditoria-adiantamentos',
    'Auditoria de Contratos' = '/auditoria-contratos',
    'Auditoria de Licitações' = '/auditoria-licitacoes',
    'Auditoria de Avaliações' = '/auditoria-avaliacoes',
    'Auditoria de Patrimônios' = '/auditoria-patrimonios',
    'Audesp-TCE-SP' = '/importar-audesp',

    'Contratos' = '/contratos',
    'Licitações' = '/licitacoes',
    'Favorecidos' = '/favorecidos',
    'Ordens Fornecimento' = '/compras',
    'Parâmetros do compra' = '/parametros-compra',

    'Bens Patrimoniais' = '/tombamentos',

    'Diário Oficial' = '/diario-oficial',
    'Seções' = '/secoes',
    'Subseções' = '/subsecoes',
    'Feriados' = '/feriados',

    'Vereadores' = '/vereadores',
    'Partidos' = '/partidos',
    'Ritos' = '/ritos',
    'Quóruns' = '/quoruns',
    'Votação - Turnos' = '/votacao-turnos',
    'Votação - Tipos' = '/votacao-tipos',
    'Expediêntes' = '/expedientes',
    'Votação - Resultados' = '/votacao-resultados',
    'Legislação - Tipos' = '/legislacao-tipos',

    'Estatísticas' = '/estatisticas',
    'Assuntos' = '/assuntos',
    'Cidadãos' = '/cidadaos',
    'Protocolo - Agendamentos' = '/protocolo/agendamentos',
    'Protocolo - cidadão' = '/protocolo-cidadao',
    'Protocolo - Ajuda' = '/protocolo/ajuda',

    'Chamamentos' = '/chamamentos',
    'Credenciamentos' = '/credenciamentos',
    'Prestação de Contas' = '/prestacao-contas',
    'Solicitação de Credenciamento' = '/credenciamento-solicitacao',
    'Convênios' = '/convenios',
    'Modelos' = '/modelos',
    'Parâmetros do Terceiro Setor' = '/parametros-terceiro-setor',

    'Portal da Entidade' = '/portal-entidade',

    'Cargos' = '/cargos',
    'Departamentos' = '/departamentos',
    'Funcionários' = '/funcionarios',
    'Holerites' = '/holerites',

    'Metas de governo' = '/metas-governo',
    'Ações do governo' = '/acoes-governo',
    'Adiantamentos' = '/adiantamentos',
    'Empenhos Orçamentários' = '/empenhos',
    'Empenhos Extra-orçamentários' = '/empenhos-extra',
    'Empenhos de Restos' = '/empenhos-resto',
    'Liquidações Orçamentárias' = '/liquidacoes',
    'Liquidações de Restos' = '/liquidacoes-restos-pagar',
    'Balancetes' = '/balancetes',
    'Anexos LRF' = '/anexos-lrf',
    'Quadros de ensino' = '/quadros-ensino',
    'Quadros da saúde' = '/quadros-saude',
    'Recebimentos' = '/recebimentos',
    'Recebimentos Extra-orçamentários' = '/recebimentos-extras',
    'Pagamentos' = '/pagamentos',
    'Pagamentos Extra-orçamentários' = '/pagamentos-extras',
    'Pagamentos de Restos' = '/pagamentos-restos-pagar',
    'Transferências Bancárias' = '/transferencias-bancarias',
    'Planos Plurianuais' = '/planos-plurianuais',
    'Audiências públicas' = '/audiencias-publica',
    'Unidades' = '/unidades',
    'Fontes de Financiamento' = '/fontes-financiamento',
    'Receitas Orçamentárias' = '/receitas-orcamentaria',
    'Despesas Orçamentárias' = '/despesas-orcamentaria',
    'LDO' = '/ldo',
    'Anexos PPA' = '/anexos-ppa',
    'Anexos LDO' = '/anexos-ldo',
    'Fichas de Receita' = '/fichas-receita',
    'Receitas Previstas' = '/receitas-prevista',
    'Fichas de Despesa' = '/fichas-despesa',
    'Despesas Previstas' = '/despesas-prevista',
    'Transferências Previstas' = '/transferencias-prevista',
    'Créditos Adicionais' = '/creditos',
    'Reservas de dotação' = '/reservas-dotacao',
    'Anexos LOA' = '/anexos-loa',
    'Plano de Contas' = '/plano-contas',
    'Fichas Extras' = '/fichas-extra',
    'Variações' = '/variacoes',
    'Eventos Contábeis' = '/eventos-contabeis',
    'Balanços' = '/balancos',
    'Razonetes' = '/razonetes',
    'Matriz de Saldos Contábeis' = '/matriz-saldos-contabeis',
    'Contas bancárias' = '/contas-bancarias',
    'AUDESP' = '/audesp-contabil',
    'AUDESP (layouts)' = '/layout-audesp',
    'Órdens de Pagamento (OP)' = '/ordens-pagamento',
    'Relatórios da Tesouraria' = '/relatorios-tesouraria',
    'Paramêtros Contábil' = '/parametros-contabil',
    'Ações' = '/acoes',
    'Programas' = '/programas',
    'Funções do governo' = '/funcoes-governo',
    'Recursos' = '/recursos',
    'Aplicação de Recursos' = '/aplicacao-recursos',
    'Tipo de Favorecidos' = '/favorecidos-tipos',
    'Precatórios' = '/precatorios',
    'Cheques Layout' = '/cheques-layout',
    'Grupos da Receita' = '/grupos-receita',
    'PASEP' = '/pasep',
    'Retenções IRRF' = '/retencoes-irrf',
    'Planejamento' = '/planejamento',

    'Parâmetros da transparência' = '/transparencia/parametros-transparencia',
    'Atas de Registro de Preços - Anexo' = '/transparencia/atas-registro-anexos',
    'Anexos de Empenhos Orçamentários' = '/transparencia/empenhos-orcamentarios-anexos',
    'Anexos de Contratos e Aditivos' = '/transparencia/contratos-anexos',
    'Anexos de Licitação' = '/transparencia/licitacoes-anexos',
    'Eventos (Holerite)' = '/transparencia/eventos-holerite',
}

interface ISistemas {
    paginas(): string[];
}

export class Comum implements ISistemas {
    paginas() {
        return [
            'Órgãos',
            'Usuários',
            'Setores',
            'Agendamentos',
            'Parâmetros de E-mail',
            'Relatórios Personalizados',
            'Exercícios e Assinaturas',
        ];
    }
}
export class Almoxarifado implements ISistemas {
    paginas() {
        return [
            'Estoques',
            'Grupos de Estoque',
            'Unidades de Fornecimento',
            'Subgrupos de Estoque',
            'Materiais',
            'Produtos',
            'Entradas',
            'Saídas',
        ];
    }
}

export class ControleInterno implements ISistemas {
    paginas() {
        return [
            'Processos',
            'Fiscalizações',
            'Questionários',
            'Auditoria de Empenhos',
            'Auditoria de Adiantamentos',
            'Auditoria de Contratos',
            'Auditoria de Licitações',
            'Auditoria de Avaliações',
            'Auditoria de Patrimônios',
            'Audesp-TCE-SP'
        ];
    }
}

export class Compra implements ISistemas {
    paginas() {
        return [
            'Contratos',
            'Licitações',
            'Favorecidos',
            'Ordens Fornecimento',
            'Parâmetros do compra',
        ];
    }
}

export class Patrimonio implements ISistemas {
    paginas() {
        return [
            'Bens Patrimoniais',
        ];
    }
}

export class DiarioOficial implements ISistemas {
    paginas() {
        return [
            'Diário Oficial',
            'Seções',
            'Subseções',
            'Feriados'
        ];
    }
}
export class Legislativo implements ISistemas {
    paginas() {
        return [
            'Vereadores',
            'Partidos',
            'Ritos',
            'Quóruns',
            'Votação - Turnos',
            'Votação - Tipos',
            'Expediêntes',
            'Votação - Resultados',
            'Legislação - Tipos',
        ];
    }
}

export class Protocolo implements ISistemas {
    paginas() {
        return [
            'Estatísticas',
            'Assuntos',
            'Cidadãos',
            'Protocolo - Agendamentos',
            'Protocolo - cidadão',
            'Protocolo - Ajuda',
        ];
    }
}

export class Folha implements ISistemas {
    paginas() {
        return [
            'Cargos',
            'Departamentos',
            'Funcionários',
            'Holerites',
        ];
    }
}

export class TerceiroSetor implements ISistemas {
    paginas() {
        return [
            'Chamamentos',
            'Credenciamentos',
            'Prestação de Contas',
            'Solicitação de Credenciamento',
            'Convênios',
            'Modelos',
            'Parâmetros do Terceiro Setor',
        ];
    }
}

export class PortalEntidade implements ISistemas {
    paginas() {
        return [
            'Chamamentos',
            'Credenciamentos',
            'Prestação de Contas',
            'Solicitação de Credenciamento',
            'Convênios',
            'Modelos',
            'Parâmetros do Terceiro Setor',
            'Portal da Entidade'
        ];
    }
}

export class Planejamento implements ISistemas {
    paginas() {
        return [
            'Planejamento',
            'Planos Plurianuais',
            'Audiências públicas',
            'Unidades',
            'Fontes de Financiamento',
            'Metas de governo',
            'Ações do governo',
            'LDO',
            'Anexos PPA',
            'Anexos LDO',
            'Receitas Orçamentárias',
            'Despesas Orçamentárias',
            'Fichas de Receita',
            'Receitas Previstas',
            'Fichas de Despesa',
            'Despesas Previstas',
            'Transferências Previstas',
            'Créditos Adicionais',
            'Reservas de dotação',
            'Anexos LOA',
        ];
    }
}

export class Tesouraria implements ISistemas {
    paginas() {
        return [
            'Transferências Bancárias',
            'Contas bancárias',
            'Órdens de Pagamento (OP)',
            'Relatórios da Tesouraria',
            'Recebimentos',
            'Recebimentos Extra-orçamentários',
            'Pagamentos',
            'Pagamentos Extra-orçamentários',
            'Pagamentos de Restos',
        ];
    }
}

export class Contabilidade implements ISistemas {
    paginas() {
        return [
            'Adiantamentos',
            'Empenhos Orçamentários',
            'Empenhos Extra-orçamentários',
            'Empenhos de Restos',
            'Liquidações Orçamentárias',
            'Liquidações de Restos',
            'Balancetes',
            'Anexos LRF',
            'Quadros de ensino',
            'Quadros da saúde',
            'Plano de Contas',
            'Fichas Extras',
            'Variações',
            'Eventos Contábeis',
            'Balanços',
            'Razonetes',
            'Matriz de Saldos Contábeis',
            'AUDESP',
            'AUDESP (layouts)',
            'Paramêtros Contábil',
            'Ações',
            'Programas',
            'Funções do governo',
            'Recursos',
            'Aplicação de Recursos',
            'Tipo de Favorecidos',
            'Precatórios',
            'Cheques Layout',
            'Grupos da Receita',
            'PASEP',
            'Retenções IRRF',
        ];
    }
}
export class Transparencia implements ISistemas {
    paginas() {
        return [
            'Parâmetros da transparência',
            'Atas de Registro de Preços - Anexo',
            'Anexos de Empenhos Orçamentários',
            'Anexos de Contratos e Aditivos',
            'Anexos de Licitação',
            'Eventos (Holerite)',
        ];
    }
}

