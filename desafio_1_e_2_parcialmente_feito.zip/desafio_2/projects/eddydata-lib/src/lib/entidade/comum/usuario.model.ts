// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Orgao } from './orgao.model';
import { Acesso } from './acesso.model';
import { Setor } from '../almoxarifado/setor.model';
import { Sistemas } from '../../components/types';
import { Favorecido } from '../compra/favorecido.model';
import { Estoque } from '../almoxarifado/estoque.model';
import { Unidade } from '../planejamento/unidade.model';

export class Usuario extends BaseResourceModel {
  constructor(
    public id?: number,
    public nome?: string,
    public sobrenome?: string,
    public cpf?: string,
    public telefone?: string,
    public email?: string,
    public senha?: string,
    public administrador?: boolean,
    public convidado?: boolean,
    public ativo?: boolean,
    public solicitacao?: boolean,
    public orgao?: Orgao,
    public senha_nova?: string,
    public sistema?: Sistemas,
    public data_cadastro?: Date,
    public setor?: Setor,
    public unidade?: Unidade,
    public estoque?: Estoque,
    public favorecido?: Favorecido,
    public acessos?: Acesso[]
  ) {
    super();
  }

  static converteJson(json: any): Usuario {
    return Object.assign(new Usuario(), json);
  }

}
