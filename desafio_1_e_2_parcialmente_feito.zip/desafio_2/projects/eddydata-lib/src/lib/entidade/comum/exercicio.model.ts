import { BaseResourceModel } from '../../models/base-resource.model';
import { Cidade } from '../geo/cidade.model';
import { Assinatura } from './assinatura.model';

export class Exercicio  extends BaseResourceModel {
  constructor(
    public id?: number,
    public ano?: number,
    public cidade?: Cidade,
    public assinatura?: Assinatura
    ) {
      super();
    }
    static converteJson(json: any): Exercicio {
      return Object.assign(new Exercicio(), json);
    }
}
