// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Exercicio } from './exercicio.model';
import { Orgao } from './orgao.model';

export class Assinatura extends BaseResourceModel {
  constructor(
    public id?: number,
    public prefeito?: string,
    public cargoPrefeito?: string,
    public contador?: string,
    public cargoContador?: string,
    public tesoureiro?: string,
    public cargoTesoureiro?: string,
    public ordenador?: string,
    public cargoOrdenador?: string,
    public assinatura1?: string,
    public cargoAssinatura1?: string,
    public assinatura2?: string,
    public cargoAssinatura2?: string,
    public assinatura3?: string,
    public cargoAssinatura3?: string,
    public responsavelCompra?: string,
    public cargoCompra?: string,
    public exercicio?: Exercicio,
    public orgao?: Orgao,
    public data_cadastro?: Date,
    public data_alteracao?: Date
  ) {
    super();
  }
  static converteJson(json: any): Assinatura {
    return Object.assign(new Assinatura(), json);
  }
}
