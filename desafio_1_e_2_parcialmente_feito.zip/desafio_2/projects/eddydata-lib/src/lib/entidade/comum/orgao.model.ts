import { BaseResourceModel } from '../../models/base-resource.model';
import { Cidade } from '../geo/cidade.model';
import { OrgaoBrasao } from './orgao-brasao.model';

export class Orgao extends BaseResourceModel {

  constructor(
    public id?: number,
    public codigo?: string,
    public nome?: string,
    public cnpj?: string,
    public endereco?: string,
    public bairro?: string,
    public cep?: string,
    public email?: string,
    public siafi?: string,
    public ativo?: boolean,
    public site?: string,
    public telefone?: string,
    public especie?: string,
    public tribunal?: string,
    public cidade?: Cidade,
    public brasao?: OrgaoBrasao
  ) {
    super();
  }

  static converteJson(json: any): Orgao {
    return Object.assign(new Orgao(), json);
  }
}
