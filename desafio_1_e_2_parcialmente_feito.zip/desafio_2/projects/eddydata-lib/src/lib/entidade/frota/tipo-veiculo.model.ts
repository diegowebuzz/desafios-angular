import { BaseResourceModel } from '../../models/base-resource.model';
import { Orgao } from '../comum/orgao.model';

export class TipoVeiculo extends BaseResourceModel {
  constructor(
    public id?: number,
    public nome?: string,
    public orgao?: Orgao,
  ) {
    super();
  }

  static converteJson(json: any): TipoVeiculo {
    return Object.assign(new TipoVeiculo(), json);
  }
}
