import { BaseResourceModel } from '../../models/base-resource.model';
import { Orgao } from '../comum/orgao.model';

export class Portaria extends BaseResourceModel {
  constructor(
    public id?: number,
    public codigo?: string,
    public qtd_litros?: number,
    public vigencia_limite?: Date,
    public orgao?: Orgao,
  ) {
    super();
  }

  static converteJson(json: any): Portaria {
    return Object.assign(new Portaria(), json);
  }
}
