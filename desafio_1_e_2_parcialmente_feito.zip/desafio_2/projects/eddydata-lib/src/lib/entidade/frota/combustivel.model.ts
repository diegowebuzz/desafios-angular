// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Cidade } from '../geo/cidade.model';

export class Combustivel extends BaseResourceModel {
  constructor(
    public id?: number,
    public nome?: string,
    public descricao?: string,
    public cidade?: Cidade,
  ) {
    super();
  }

  static converteJson(json: any): Combustivel {
    return Object.assign(new Combustivel(), json);
  }
}
