// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Cidade } from '../geo/cidade.model';

export class Seguradora extends BaseResourceModel {
  constructor(
    public id?: number,
    public nome?: string,
    public email?: string,
    public telefone?: string,
    public cep?: string,
    public endereco?: string,
    public bairro?: string,
    public contato?: string,
    public site?: string,
    public cidade?: Cidade
    ) {
    super();
  }
  static converteJson(json: any): Seguradora {
    return Object.assign(new Seguradora(), json);
  }
}
