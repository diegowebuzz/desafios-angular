import { BaseResourceModel } from '../../models/base-resource.model';
import { Favorecido } from '../compra/favorecido.model';
import { Orgao } from '../comum/orgao.model';
import { Usuario } from '../comum/usuario.model';
import { Funcionario } from '../folha/funcionario.model';
import { OrdemServicoItem } from './ordem-servico-item.model';
import { Veiculo } from './veiculo.model';

export class OrdemServico extends BaseResourceModel {
  constructor(
    public id?: number,
    public data_servico?: Date,
    public km_atual?: string,
    public tipo_servico?: 'OLEO' | 'PNEU' | 'PECAS',
    public descricao?: string,
    public mecanico?: Funcionario,
    public favorecido?: Favorecido,
    public solicitante?: Usuario,
    public veiculo?: Veiculo,
    public orgao?: Orgao,
    public itens?: OrdemServicoItem[],
  ) {
    super();
  }

  static converteJson(json: any): OrdemServico {
    return Object.assign(new OrdemServico(), json);
  }
}
