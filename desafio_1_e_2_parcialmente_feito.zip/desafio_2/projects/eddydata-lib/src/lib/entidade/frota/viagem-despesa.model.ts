import { BaseResourceModel } from '../../models/base-resource.model';
import { Viagem } from './viagem.model';

export class ViagemDespesa extends BaseResourceModel {
  constructor(
    public id?: number,
    public descricao?: string,
    public valor?: number,
    public viagem?: Viagem,
  ) {
    super();
  }

  static converteJson(json: any): ViagemDespesa {
    return Object.assign(new ViagemDespesa(), json);
  }
}
