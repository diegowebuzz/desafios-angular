import { BaseResourceModel } from '../../models/base-resource.model';
import { Funcionario } from '../folha/funcionario.model';
import { Combustivel } from './combustivel.model';
import { Motorista } from './motorista.model';
import { Portaria } from './portaria.model';
import { PostoAbastecimento } from './posto-abastecimento.model';
import { Veiculo } from './veiculo.model';

export class Abastecimento extends BaseResourceModel {
  constructor(
    public id?: number,
    public km_anterior?: number,
    public km_atual?: number,
    public quantidade?: number,
    public valor_total?: number,
    public combustivel?: Combustivel,
    public frentista?: Funcionario,
    public veiculo?: Veiculo,
    public motorista?: Motorista,
    public portaria?: Portaria,
    public posto?: PostoAbastecimento,
  ) {
    super();
  }

  static converteJson(json: any): Abastecimento {
    return Object.assign(new Abastecimento(), json);
  }
}
