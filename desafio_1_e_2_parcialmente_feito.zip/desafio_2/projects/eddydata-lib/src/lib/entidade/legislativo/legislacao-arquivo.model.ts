// tslint:disable: variable-name
import { LegislacaoHistorico } from './legislacao-historico.model';

export class LegislacaoArquivo {

    id: number;

    nome: string;

    caminho: string;

    tipo: string;

    documento: any;

    tamanho: number;

    historico: LegislacaoHistorico;

    data_cadastro: Date;

    data_alteracao: Date;

}
