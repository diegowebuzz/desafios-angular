// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Cidade } from '../geo/cidade.model';

export class Rito extends BaseResourceModel {
  constructor(
    public id?: number,
    public nome?: string,
    public cidade?: Cidade
  ) {
    super();
  }
  static converteJson(json: any): Rito {
    return Object.assign(new Rito(), json);
  }
}
