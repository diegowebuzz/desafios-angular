// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { LiquidacaoResto } from './liquidacao-resto.model';
import { FichaExtra } from './ficha-extra.model';

export class RetencaoResto extends BaseResourceModel {
  constructor(
    public id?: number,
    public aux?: number,
    public data_vencimento?: Date,
    public cei?: string,
    public gps?: string,
    public valor_retido?: number,
    public ficha?: FichaExtra,
    public liquidacao?: LiquidacaoResto,
    public data_cadastro?: Date,
    public data_alteracao?: Date,
    public editavel?: boolean,
  ) {
    super();
  }

  static converteJson(json: any): RetencaoResto {
    return Object.assign(new RetencaoResto(), json);
  }
}
