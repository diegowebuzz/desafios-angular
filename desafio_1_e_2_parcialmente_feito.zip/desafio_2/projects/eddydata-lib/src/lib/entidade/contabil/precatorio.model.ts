// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Favorecido } from '../compra/favorecido.model';
import { Orgao } from '../comum/orgao.model';

export class Precatorio extends BaseResourceModel {
  constructor(
    public id?: number,
    public aux?: number,
    public ano?: number,
    public data_ajuizamento?: Date,
    public data_apresentacao?: Date,
    public tipo?: string,
    public numero_acao?: string,
    public numero_precatorio?: string,
    public valor_original?: number,
    public valor_vencido?: number,
    public valor_exercicio?: number,
    public valor_exercicio_anterior?: number,
    public valor_atualizacao?: number,
    public valor_cancelado?: number,
    public valor_pago?: number,
    public historico?: string,
    public orgao?: Orgao,
    public favorecido?: Favorecido,
  ) {
    super();
  }
  static converteJson(json: any): Precatorio {
    return Object.assign(new Precatorio(), json);
  }
}
