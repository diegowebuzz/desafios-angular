// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Orgao } from '../comum/orgao.model';
import { Exercicio } from '../comum/exercicio.model';
import { PlanoConta } from './plano-conta.model';
import { Recurso } from '../planejamento/recurso.model';
import { Favorecido } from '../compra/favorecido.model';

export class FichaExtra extends BaseResourceModel {
  constructor(
    public id?: number,
    public numero?: number,
    public nome?: string,
    public saldo_anterior?: number,
    public orgao?: Orgao,
    public exercicio?: Exercicio,
    public plano?: PlanoConta,
    public recurso?: Recurso,
    public aplicacao?: Recurso,
    public data_cadastro?: Date,
    public data_alteracao?: Date,
    public favorecido?: Favorecido
  ) {
    super();
  }

  static converteJson(json: any): FichaExtra {
    return Object.assign(new FichaExtra(), json);
  }
}
