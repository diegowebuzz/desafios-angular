// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Orgao } from '../comum/orgao.model';
import { FichaDespesa } from '../planejamento/ficha-despesa.model';
import { Favorecido } from '../compra/favorecido.model';
import { Despesa } from '../planejamento/despesa.model';
import { Compra } from '../compra/compra.model';
import { Contrato } from '../compra/contrato.model';
import { Convenio } from '../compra/convenio.model';
import { Exercicio } from '../comum/exercicio.model';
import { Licitacao } from '../licitacao/licitacao.model';
import { Modalidade } from '../licitacao/modalidade.model';
import { Usuario } from '../comum/usuario.model';
import { AtaRegistro } from '../licitacao/ata-registro.model';

export class Empenho extends BaseResourceModel {
  constructor(
    public id?: number,
    public numero?: number,
    public especie?: string,
    public tipo_empenho?: string,
    public valor_empenho?: number,
    public data_empenho?: Date,
    public data_vencimento?: Date,
    public adiantamento?: boolean,
    public fase4?: boolean,
    public processo?: string,
    public historico?: string,
    public orgao?: Orgao,
    public ficha?: FichaDespesa,
    public subelemento?: Despesa,
    public favorecido?: Favorecido,
    public compra?: Compra,
    public exercicio?: Exercicio,
    public contrato?: Contrato,
    public convenio?: Convenio,
    public licitacao?: Licitacao,
    public modalidade?: Modalidade,
    public ata?: AtaRegistro,
    public data_cadastro?: Date,
    public data_alteracao?: Date,
    public usuario_cadastro?: Usuario,
    public total_empenhado?: number,
    public total_empenho_sem_anulacao?: number,
    public total_liquidado?: number,
    public total_pago?: number,
    public total_empenhado_ficha?: number,
    public total_empenhado_ficha_anterior?: number,
    public total_dotacao_ficha?: number,
    public total_creditado_ficha?: number,
    public total_reservado?: number
  ) {
    super();
  }

  static converteJson(json: any): Empenho {
    return Object.assign(new Empenho(), json);
  }
}
