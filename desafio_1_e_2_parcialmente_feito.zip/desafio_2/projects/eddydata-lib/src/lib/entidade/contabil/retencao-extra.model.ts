// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { FichaExtra } from './ficha-extra.model';
import { EmpenhoExtra } from './empenho-extra.model';

export class RetencaoExtra extends BaseResourceModel {
  constructor(
    public id?: number,
    public aux?: number,
    public data_vencimento?: Date,
    public cei?: string,
    public gps?: string,
    public valor_retido?: number,
    public ficha?: FichaExtra,
    public empenho_extra?: EmpenhoExtra,
    public data_cadastro?: Date,
    public data_alteracao?: Date,
    public editavel?: boolean,
  ) {
    super();
  }

  static converteJson(json: any): RetencaoExtra {
    return Object.assign(new RetencaoExtra(), json);
  }
}
