// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { FichaExtra } from './ficha-extra.model';
import { Liquidacao } from './liquidacao.model';

export class Retencao extends BaseResourceModel {
  constructor(
    public id?: number,
    public aux?: number,
    public data_vencimento?: Date,
    public cei?: string,
    public gps?: string,
    public valor_retido?: number,
    public ficha?: FichaExtra,
    public liquidacao?: Liquidacao,
    public data_cadastro?: Date,
    public data_alteracao?: Date,
    public editavel?: boolean,
  ) {
    super();
  }

  static converteJson(json: any): Retencao {
    return Object.assign(new Retencao(), json);
  }
}
