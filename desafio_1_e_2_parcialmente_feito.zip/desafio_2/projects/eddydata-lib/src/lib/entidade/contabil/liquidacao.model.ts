
// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Empenho } from './empenho.model';
import { Exercicio } from '../comum/exercicio.model';
import { Orgao } from '../comum/orgao.model';
import { Usuario } from '../comum/usuario.model';

export class Liquidacao extends BaseResourceModel {
    constructor(
        public id?: number,
        public data_liquidacao?: Date,
        public mes?: number,
        public data_vencimento?: Date,
        public parcela?: number,
        public data_documento?: Date,
        public uf_fiscal?: string,
        public documento?: string,
        public documento_fiscal?: string,
        public historico?: string,
        public aux?: number,
        public valor_liquidado?: number,
        public impresso?: boolean,
        public anulacao?: boolean,
        public fase4?: boolean,
        public recolhimento_encargo?: boolean,
        public empenho?: Empenho,
        public exercicio?: Exercicio,
        public orgao?: Orgao,
        public usuario_cadastro?: Usuario,
        public data_cadastro?: Date,
        public data_alteracao?: Date,
    ) {
        super();
    }

    static converteJson(json: any): Liquidacao {
        return Object.assign(new Liquidacao(), json);
    }
}
