// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Orgao } from '../comum/orgao.model';

export class ParametroContabil extends BaseResourceModel {

  constructor(
    public id?: number,
    public redirecionar_liquidar_pagar?: boolean,
    public dias_bloquear_alteracoes?: number,
    public desdobramento_estoque?: boolean,
    public terceiro_setor_pagto_contabil?: boolean, // prestacao de contas considerando a soma dos pagamentos feitos na contabilidade
    public repetir_dados_empenho?: boolean,
    public orgao?: Orgao
  ) {
    super();
  }

  static converteJson(json: any): ParametroContabil {
    return Object.assign(new ParametroContabil(), json);
  }
}
