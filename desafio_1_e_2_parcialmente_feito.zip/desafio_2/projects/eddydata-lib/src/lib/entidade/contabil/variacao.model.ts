// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { FichaExtra } from './ficha-extra.model';
import { Liquidacao } from './liquidacao.model';
import { Exercicio } from '../comum/exercicio.model';
import { Orgao } from '../comum/orgao.model';
import { EventoContabil } from './evento-contabil.model';
import { VariacaoItem } from './variacao-item.model';

export class Variacao extends BaseResourceModel {
  constructor(
    public id?: number,
    public valor?: number,
    public historico?: string,
    public exercicio?: Exercicio,
    public orgao?: Orgao,
    public evento?: EventoContabil,
    public itens?: VariacaoItem[],
    public data_cadastro?: Date,
    public data_alteracao?: Date,
    public data_variacao?: Date,
    public mes?: number
  ) {
    super();
  }

  static converteJson(json: any): Variacao {
    return Object.assign(new Variacao(), json);
  }
}
