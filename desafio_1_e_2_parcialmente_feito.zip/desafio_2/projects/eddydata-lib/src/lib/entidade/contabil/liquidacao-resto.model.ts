
// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { EmpenhoResto } from './empenho-resto.model';

export class LiquidacaoResto extends BaseResourceModel {
    constructor(
        public id?: number,
        public data_liquidacao?: Date,
        public mes?: number,
        public data_vencimento?: Date,
        public parcela?: number,
        public data_documento?: Date,
        public uf_fiscal?: string,
        public documento?: string,
        public documento_fiscal?: string,
        public historico?: string,
        public aux?: number,
        public valor_liquidado?: number,
        public impresso?: boolean,
        public anulacao?: boolean,
        public recolhimento_encargo?: boolean,
        public empenho?: EmpenhoResto,
        public data_cadastro?: Date,
        public data_alteracao?: Date,
    ) {
        super();
    }

    static converteJson(json: any): LiquidacaoResto {
        return Object.assign(new LiquidacaoResto(), json);
    }
}
