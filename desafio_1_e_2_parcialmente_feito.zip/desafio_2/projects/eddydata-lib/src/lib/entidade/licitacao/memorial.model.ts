// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { ProdutoUnidade } from '../almoxarifado/produto-unidade.model';
import { Produto } from '../almoxarifado/produto.model';
import { Licitacao } from './licitacao.model';

export class Memorial extends BaseResourceModel {
  constructor(
    public id?: number,
    public quantidade?: number,
    public unidade?: string,
    public ordem?: number,
    public descricao?: string,
    public observacao?: string,
    public aux?: number,
    public licitacao?: Licitacao,
    public produto_unidade?: ProdutoUnidade,
    public editavel?: boolean
  ) {
    super();
  }
}
