import { BaseResourceModel } from "../../models/base-resource.model";
import { Pessoa } from "../comum/pessoa.model";
import { Comissao } from "./comissao.model";

export class ComissaoMembro extends BaseResourceModel {
    constructor(
        public id?: number,
        public pessoa?: Pessoa,
        public comissao?: Comissao,
    ) {
        super();
    }

    static converteJson(json: any): ComissaoMembro {
        return Object.assign(new ComissaoMembro(), json);
    }
}
