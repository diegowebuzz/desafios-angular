// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Cidade } from '../geo/cidade.model';
import { TipoContratacao } from './tipo-contratacao.model';

export class Modalidade extends BaseResourceModel {
  constructor(
    public id?: number,
    public codigo?: number,
    public nome?: string,
    public valor_limite?: number,
    public prazo_limite?: number,
    public exigir_contrato?: boolean,
    public exigir_licitacao?: boolean,
    public exigir_convenio?: boolean,
    public cidade?: Cidade,
    public tiposContratacao?: TipoContratacao[],
  ) {
    super();
  }

  static converteJson(json: any): Modalidade {
    return Object.assign(new Modalidade(), json);
  }
}
