import { SituacaoLicitacao } from '../../components/types';
import { BaseResourceModel } from '../../models/base-resource.model';
import { Setor } from '../almoxarifado/setor.model';
import { Exercicio } from '../comum/exercicio.model';
import { Orgao } from '../comum/orgao.model';
import { Pessoa } from '../comum/pessoa.model';
import { Comissao } from './comissao.model';
import { Memorial } from './memorial.model';
import { Modalidade } from './modalidade.model';
import { TipoContratacao } from './tipo-contratacao.model';

export class Licitacao extends BaseResourceModel {
  constructor(
    public id?: number,
    public formato_contratacao?: 'REGISTRO_PRECO' | 'RESERVA_VALOR',
    public justificativa?: string,
    public data_inicio?: Date,
    public data_termino?: Date,
    public prazo_pagamento?: number,
    public prazo_entrega?: number,
    public numero?: string,
    public data_abertura?: Date,
    public data_ata?: Date,
    public data_edital?: Date,
    public data_julgamento?: Date,
    public data_parecer?: Date,
    public data_publicacao?: Date,
    public data_homologacao?: Date,
    public data_cancelamento?: Date,
    public data_assinatura?: Date,
    public data_ratificacao?: Date,
    public data_abertura_env?: Date,
    public data_entrega_env?: Date,
    public situacao?: SituacaoLicitacao,
    public processo?: string,
    public objeto?: string,
    public valor_estimado?: number,
    public valor_licitado?: number,
    public enviar_transparencia?: boolean,
    public modalidade?: Modalidade,
    public orgao?: Orgao,
    public setor?: Setor,
    public exercicio?: Exercicio,
    public comissao?: Comissao,
    public tipo_contratacao?: TipoContratacao,
    public solicitante?: Pessoa,
    public processo_cc?: Licitacao,
    public itens?: Memorial[],
    public vencedores?: any,
  ) {
    super();
  }
  static converteJson(json: any): Licitacao {
    return Object.assign(new Licitacao(), json);
  }
}
