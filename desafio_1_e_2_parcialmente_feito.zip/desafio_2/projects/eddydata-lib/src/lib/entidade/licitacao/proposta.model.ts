// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Favorecido } from '../compra/favorecido.model';
import { Memorial } from './memorial.model';

export class Proposta extends BaseResourceModel {
  constructor(
    public id?: number,
    public quantidade?: number,
    public valor_unitario?: number,
    public classificacao?: number,
    public frustado?: number,
    public vencedor?: number,
    public marca?: string,
    public data_cotacao?: Date,
    public hora_cotacao?: Date,
    public motivo_desclassificacao?: string,
    public favorecido?: Favorecido,
    public memorial?: Memorial,
  ) {
    super();
  }
}
