import { BaseResourceModel } from "../../models/base-resource.model";
import { Orgao } from "../comum/orgao.model";
import { Pessoa } from "../comum/pessoa.model";
import { ComissaoMembro } from "./comissao-membro.model";

export class Comissao extends BaseResourceModel {
    constructor(
        public id?: number,
        public nome?: string,
        public portaria?: string,
        public presidente?: Pessoa,
        public orgao?: Orgao,
        public membros?: ComissaoMembro[]
    ) {
        super();
    }

    static converteJson(json: any): Comissao {
        return Object.assign(new Comissao(), json);
    }
}
