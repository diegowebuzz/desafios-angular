import { BaseResourceModel } from '../../models/base-resource.model';
import { Favorecido } from '../compra/favorecido.model';
import { Licitacao } from './licitacao.model';

export class Proponente extends BaseResourceModel {
  constructor(
    public id?: number,
    public epp_me?: number,
    public licitacao?: Licitacao,
    public favorecido?: Favorecido,
    public editavel?: boolean
  ) {
    super();
  }
}
