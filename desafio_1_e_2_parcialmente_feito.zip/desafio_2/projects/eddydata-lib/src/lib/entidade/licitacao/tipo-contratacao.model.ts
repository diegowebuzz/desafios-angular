import { BaseResourceModel } from "../../models/base-resource.model";
import { Orgao } from "../comum/orgao.model";
import { Modalidade } from "./modalidade.model";

export class TipoContratacao extends BaseResourceModel {
    constructor(
        public id?: number,
        public nome?: string,
        public tce?: number,
        public servico?: boolean,
        public material?: boolean,
        public locacao?: boolean,
        public concessao?: boolean,
        public modalidade?: Modalidade,
        public orgao?: Orgao,
    ) {
        super();
    }

    static converteJson(json: any): TipoContratacao {
        return Object.assign(new TipoContratacao(), json);
    }
}
