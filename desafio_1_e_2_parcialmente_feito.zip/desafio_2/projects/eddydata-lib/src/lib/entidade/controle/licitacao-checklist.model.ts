// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { AuditoriaLicitacao } from './auditoria-licitacao.model';

export class LicitacaoChecklist extends BaseResourceModel {
  constructor(
    public id?: number,
    public pergunta?: string,
    public tipo_resposta?: string,
    public descricao_resposta?: string,
    public resposta?: boolean,
    public observacao?: string,
    public auditoria_licitacao?: AuditoriaLicitacao
    ) {
      super();
    }
    static converteJson(json: any): LicitacaoChecklist {
      return Object.assign(new LicitacaoChecklist(), json);
    }
}
