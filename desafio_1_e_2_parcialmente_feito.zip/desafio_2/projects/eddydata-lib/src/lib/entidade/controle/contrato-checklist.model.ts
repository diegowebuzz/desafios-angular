// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { AuditoriaContrato } from './auditoria-contrato.model';

export class ContratoChecklist extends BaseResourceModel {
  constructor(
    public id?: number,
    public pergunta?: string,
    public tipo_resposta?: string,
    public descricao_resposta?: string,
    public resposta?: boolean,
    public observacao?: string,
    public auditoria_contrato?: AuditoriaContrato
    ) {
      super();
    }
    static converteJson(json: any): ContratoChecklist {
      return Object.assign(new ContratoChecklist(), json);
    }
}
