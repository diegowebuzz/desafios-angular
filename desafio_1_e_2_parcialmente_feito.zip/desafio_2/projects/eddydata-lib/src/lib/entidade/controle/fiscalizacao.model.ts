import { BaseResourceModel } from '../../models/base-resource.model';
import { Orgao } from '../comum/orgao.model';

export class Fiscalizacao extends BaseResourceModel {
  constructor(
    public id?: number,
    public mes?: number,
    public ano?: number,
    public responsavel?: string,
    public orgao?: Orgao,
  ) {
    super();
  }
  static converteJson(json: any): Fiscalizacao {
    return Object.assign(new Fiscalizacao(), json);
  }
}
