// tslint:disable: variable-name
import { Login } from './login';
import { Acesso } from '../comum/acesso.model';
import { Exercicio } from '../comum/exercicio.model';
import { Ppa } from '../planejamento/ppa.model';
import { Usuario } from '../comum/usuario.model';
import { Orgao } from '../comum/orgao.model';
import { Cidade } from '../geo/cidade.model';
import { Favorecido } from '../compra/favorecido.model';
import { Sistemas } from '../../components/types';

export class LoginProtocolo extends Login {
    constructor(
        public sistema?: Sistemas,
        public exercicio?: Exercicio,
        public usuario?: Usuario,
        public orgao?: Orgao,
        public cidade?: Cidade,
        public limite?: number,
        public token?: string,
        public brasao?: string,
        public prazo_termino_protocolo?: number,
        public responsavel_protocolo?: string,
        public responsavel_cargo_protocolo?: string,
        public enviar_email_protocolo?: boolean,
    ) {
        super(sistema, exercicio, usuario, orgao, cidade, limite, token, brasao);
    }
}
