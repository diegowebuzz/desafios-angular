import { Sistemas } from '../../components/types';
import { Acesso } from '../comum/acesso.model';
import { Exercicio } from '../comum/exercicio.model';
import { Orgao } from '../comum/orgao.model';
import { Usuario } from '../comum/usuario.model';
import { Cidade } from '../geo/cidade.model';

// tslint:disable: variable-name

export class Login {
  constructor(
    public sistema?: Sistemas,
    public exercicio?: Exercicio,
    public usuario?: Usuario,
    public orgao?: Orgao,
    public cidade?: Cidade,
    public limite?: number,
    public token?: string,
    public brasao?: string,
    public versao?: string,
    public acessos?: Acesso[],
  ) { }
}
