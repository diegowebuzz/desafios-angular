// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Usuario } from '../comum/usuario.model';
import { Tombamento } from './tombamento.model';
import { Orgao } from '../comum/orgao.model';
import { Exercicio } from '../comum/exercicio.model';

export class Depreciacao extends BaseResourceModel {
  constructor(
    public id?: number,
    public ano?: number,
    public mes?: number,
    public qtde_depreciada?: number,
    public data_depreciacao?: Date,
    public hora_depreciacao?: Date,
    public valor_anterior?: number,
    public valor_depreciado?: number,
    public valor_novo?: number,
    public valor_residual?: number,
    public qtde_depreciado?: number,
    public vida_util?: number,
    public perc_residual?: number,
    public tombamento?: Tombamento,
    public orgao?: Orgao,
    public exercicio?: Exercicio,
    public usuario?: Usuario
    ) {
    super();
  }

  static converteJson(json: any): Depreciacao {
    return Object.assign(new Depreciacao(), json);
  }
}
