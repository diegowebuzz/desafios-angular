// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Usuario } from '../comum/usuario.model';
import { Orgao } from '../comum/orgao.model';

export class Reavaliacao extends BaseResourceModel {
  constructor(
    public id?: number,
    public data_reavaliacao?: Date,
    public processo?: string,
    public obsevacao?: string,
    public encerrado?: boolean,
    public orgao?: Orgao,
    public usuario?: string
    ) {
    super();
  }

  static converteJson(json: any): Reavaliacao {
    return Object.assign(new Reavaliacao(), json);
  }
}
