// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Tombamento } from './tombamento.model';

export class TombamentoFoto extends BaseResourceModel {
  constructor(
    public id?: number,
    public titulo?: string,
    public descricao?: string,
    public foto?: string,
    public tombamento?: Tombamento
  ) {
    super();
  }

  static converteJson(json: any): TombamentoFoto {
    return Object.assign(new TombamentoFoto(), json);
  }
}
