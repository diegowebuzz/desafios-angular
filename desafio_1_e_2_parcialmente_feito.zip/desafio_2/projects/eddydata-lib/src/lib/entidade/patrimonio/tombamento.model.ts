import { BaseResourceModel } from '../../models/base-resource.model';
import { Favorecido } from '../compra/favorecido.model';
import { Produto } from '../almoxarifado/produto.model';
import { Exercicio } from '../comum/exercicio.model';
import { Orgao } from '../comum/orgao.model';
import { Depreciacao } from './depreciacao.model';
import { ReavaliacaoItem } from './reavaliacao-item.model';

export class Tombamento extends BaseResourceModel {
  constructor(
    public id?: number,
    public placa?: number,
    public data_aquisicao?: Date,
    public data_baixa?: Date,
    public data_exclusao?: Date,
    public ano?: number,
    public empenho?: number,
    public aux?: number,
    public marca?: string,
    public cor?: string,
    public medida?: string,
    public documento?: string,
    public localizacao?: string,
    public conservacao?: string,
    public situacao?: string,
    public valor_aquisicao?: number,
    public valor_depreciado?: number,
    public valor_atual?: number,
    public favorecido?: Favorecido,
    public produto?: Produto,
    public exercicio?: Exercicio,
    public orgao?: Orgao,
    public depreciacoes?: Depreciacao[],
    public reavaliacoes?: ReavaliacaoItem[],
  ) {
    super();
  }

  static converteJson(json: any): Tombamento {
    return Object.assign(new Tombamento(), json);
  }
}
