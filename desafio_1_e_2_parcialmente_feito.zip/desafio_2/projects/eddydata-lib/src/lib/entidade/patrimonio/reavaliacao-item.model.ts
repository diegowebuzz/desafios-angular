// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Tombamento } from './tombamento.model';
import { Reavaliacao } from './reavaliacao.model';

export class ReavaliacaoItem extends BaseResourceModel {
  constructor(
    public id?: number,
    public aux?: number,
    public processo?: string,
    public data_almoxarifado?: Date,
    public data_reavaliacao?: Date,
    public valor_entrada?: number,
    public valor_anterior?: number,
    public valor_reavaliado?: string,
    public usuario?: string,
    public reavaliacao?: Reavaliacao,
    public tombamento?: Tombamento,
  ) {
    super();
  }

  static converteJson(json: any): ReavaliacaoItem {
    return Object.assign(new ReavaliacaoItem(), json);
  }
}
