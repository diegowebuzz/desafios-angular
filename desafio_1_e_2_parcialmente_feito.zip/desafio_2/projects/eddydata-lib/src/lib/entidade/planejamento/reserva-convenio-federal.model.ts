// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { ReservaDotacao } from './reserva-dotacao.model';


export class ReservaConvenioFederal extends BaseResourceModel {
  constructor(
    public id?: number,
    public numero?: string,
    public ano?: string,
    public valor_reserva?: number,
    public valor_contrapartida?: number,
    public reserva?: ReservaDotacao,
    public editavel?: boolean
  ) {
    super();
  }

  static converteJson(json: any): ReservaConvenioFederal {
    return Object.assign(new ReservaConvenioFederal(), json);
  }

}
