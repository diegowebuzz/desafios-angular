// tslint:disable: variable-name
import { Ppa } from './ppa.model';
import { BaseResourceModel } from '../../models/base-resource.model';

export class Acao extends BaseResourceModel {
  constructor(
    public id?: number,
    public codigo?: string,
    public nome?: string,
    public descricao?: string,
    public data_cadastro?: Date,
    public data_alteracao?: Date,
    public ppa?: Ppa
  ) {
    super();
  }

  static converteJson(json: any): Acao {
    return Object.assign(new Acao(), json);
  }
}
