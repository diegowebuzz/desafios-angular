import { BaseResourceModel } from '../../models/base-resource.model';
import { Exercicio } from '../comum/exercicio.model';
import { Recurso } from './recurso.model';
import { Receita } from './receita.model';
import { Orgao } from '../comum/orgao.model';

// tslint:disable: variable-name

export class FichaReceita extends BaseResourceModel {
  constructor(
    public id?: number,
    public numero?: number,
    public especie?: string,
    public ativo?: boolean,
    public renuncia?: boolean,
    public exercicio?: Exercicio,
    public recurso?: Recurso,
    public aplicacao?: Recurso,
    public orgao?: Orgao,
    public valor_orcado?: number,
    public ensino?: number,
    public saude?: number,
    public redutor?: boolean,
    public restituicao?: boolean,
    public restencao?: boolean,
    public receita?: Receita,
    public recurso_siconfi?: Recurso,
    public data_cadastro?: Date,
    public data_alteracao?: Date,
    public exigir_credor?: boolean,
    public exigir_contrato?: boolean,
    public exigir_convenio?: boolean,
    public previsoes?: []
  ) {
    super();
  }

  static converteJson(json: any): FichaReceita {
    return Object.assign(new FichaReceita(), json);
  }

}
