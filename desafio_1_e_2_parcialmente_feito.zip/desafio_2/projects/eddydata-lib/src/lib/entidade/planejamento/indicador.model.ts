// tslint:disable: variable-name
import { Ppa } from './ppa.model';
import { BaseResourceModel } from '../../models/base-resource.model';
import { MetaGoverno } from './meta-governo.model';

export class Indicador extends BaseResourceModel {
  constructor(
    public id?: number,
    public codigo?: string,
    public nome?: string,
    public unidade_medida?: string,
    public recente?: number,
    public futuro?: number,
    public meta1?: number,
    public meta2?: number,
    public meta3?: number,
    public meta4?: number,
    public meta_realizada1?: number,
    public meta_realizada2?: number,
    public meta_realizada3?: number,
    public meta_realizada4?: number,
    public meta?: MetaGoverno,
    public editavel?: boolean
  ) {
    super();
  }

  static converteJson(json: any): Indicador {
    return Object.assign(new Indicador(), json);
  }
}
