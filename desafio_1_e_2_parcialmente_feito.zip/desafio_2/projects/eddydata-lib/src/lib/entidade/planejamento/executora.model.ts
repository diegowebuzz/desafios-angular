// tslint:disable: variable-name
import { Unidade } from './unidade.model';
import { BaseResourceModel } from '../../models/base-resource.model';


export class Executora extends BaseResourceModel {
  constructor(
    public id?: number,
    public codigo?: string,
    public nome?: string,
    public tribunal?: string,
    public atuacao?: string,
    public legislacao?: string,
    public ativo?: boolean,
    public data_cadastro?: Date,
    public data_alteracao?: Date,
    public unidade?: Unidade,
    public editavel?: boolean
  ) {
    super();
  }

  static converteJson(json: any): Executora {
    return Object.assign(new Executora(), json);
  }

}
