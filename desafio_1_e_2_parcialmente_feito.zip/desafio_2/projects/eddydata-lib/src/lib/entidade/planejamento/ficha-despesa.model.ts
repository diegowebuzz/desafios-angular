import { BaseResourceModel } from '../../models/base-resource.model';
import { Exercicio } from '../comum/exercicio.model';
import { Recurso } from './recurso.model';
import { Despesa } from './despesa.model';
import { Acao } from './acao.model';
import { Programa } from './programa.model';
import { FuncaoGoverno } from './funcao-governo.model';
import { Executora } from './executora.model';
import { Orgao } from '../comum/orgao.model';

// tslint:disable: variable-name

export class FichaDespesa extends BaseResourceModel {
  constructor(
    public id?: number,
    public numero?: number,
    public valor_orcado?: number,
    public valor_cota?: number,
    public especie?: string,
    public ensino?: number,
    public saude?: number,
    public convenio?: boolean,
    public consorcio?: boolean,
    public publicidade?: number,
    public terceiro_setor?: boolean,
    public ativo?: boolean,
    public exercicio?: Exercicio,
    public recurso?: Recurso,
    public recurso_siconfi?: Recurso,
    public aplicacao?: Recurso,
    public despesa?: Despesa,
    public acao?: Acao,
    public programa?: Programa,
    public funcao?: FuncaoGoverno,
    public subfuncao?: FuncaoGoverno,
    public executora?: Executora,
    public orgao?: Orgao,
    public data_cadastro?: Date,
    public data_alteracao?: Date,
    public previsoes?: []
  ) {
    super();
  }

  static converteJson(json: any): FichaDespesa {
    return Object.assign(new FichaDespesa(), json);
  }

}
