// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { Licitacao } from '../licitacao/licitacao.model';
import { FichaDespesa } from './ficha-despesa.model';

export class ReservaDotacao extends BaseResourceModel {
  constructor(
    public id?: number,
    public data_reserva?: Date,
    public data_liberacao?: Date,
    public data_cancelamento?: Date,
    public data_adjudicacao?: Date,
    public valor_reserva?: number,
    public valor_adjudicacao?: number,
    public saldo_anterior?: number,
    public processo?: string,
    public observacao?: string,
    public ativo?: boolean,
    public deduz_cota?: boolean,
    public contabiliza?: boolean,
    public data_cadastro?: Date,
    public data_alteracao?: Date,
    public ficha?: FichaDespesa,
    public licitacao?: Licitacao,
    public declaracao?: boolean,
    public convenio_estadual?: boolean,
    public convenio_federal?: boolean,
    public tesouro?: boolean,
    public fundo_especial?: boolean,
    public operacao_credito?: boolean,
    public outra_fonte?: boolean,
    public administracao_indireta?: boolean,
    public outro_observacao?: string,
    public data_declaracao?: Date
    ) {
    super();
  }

  static converteJson(json: any): ReservaDotacao {
    return Object.assign(new ReservaDotacao(), json);
  }
}
