import { BaseResourceModel } from '../../models/base-resource.model';
import { Cidade } from '../geo/cidade.model';

// tslint:disable: variable-name

export class Recurso extends BaseResourceModel {
  constructor(
    public id?: number,
    public codigo?: string,
    public nome?: string,
    public variavel?: string,
    public descricao?: string,
    public nivel?: number,
    public data_cadastro?: Date,
    public data_alteracao?: Date,
    public cidade?: Cidade
  ) {
    super();
  }

  static converteJson(json: any): Recurso {
    return Object.assign(new Recurso(), json);
  }
}
