// tslint:disable: variable-name
import { Ppa } from './ppa.model';
import { BaseResourceModel } from '../../models/base-resource.model';
import { Receita } from './receita.model';

export class FonteFinanciamento extends BaseResourceModel {
  constructor(
    public id?: number,
    public receita?: Receita,
    public data_cadastro?: Date,
    public data_alteracao?: Date,
    public ppa?: Ppa
  ) {
    super();
  }

  static converteJson(json: any): FonteFinanciamento {
    return Object.assign(new FonteFinanciamento(), json);
  }
}
