// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { ReservaDotacao } from './reserva-dotacao.model';


export class ReservaFinanciamento extends BaseResourceModel {
  constructor(
    public id?: number,
    public agente?: string,
    public contrato?: string,
    public ano?: string,
    public valor_repasse?: number,
    public reserva?: ReservaDotacao,
    public editavel?: boolean
  ) {
    super();
  }

  static converteJson(json: any): ReservaFinanciamento {
    return Object.assign(new ReservaFinanciamento(), json);
  }

}
