// tslint:disable: variable-name
import { BaseResourceModel } from '../../models/base-resource.model';
import { FichaDespesa } from './ficha-despesa.model';

export class DespesaPrevista extends BaseResourceModel {
  constructor(
    public id?: number,
    public mes?: number,
    public referencia?: number,
    public evento?: string,
    public valor_previsto?: number,
    public aux?: number,
    public ficha?: FichaDespesa,
    public data_cadastro?: Date,
    public data_alteracao?: Date,
    public editavel?: boolean
  ) {
    super();
  }

  static converteJson(json: any): DespesaPrevista {
    return Object.assign(new DespesaPrevista(), json);
  }
}
