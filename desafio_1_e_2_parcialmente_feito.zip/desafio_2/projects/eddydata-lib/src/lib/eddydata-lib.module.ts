import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EddydataLibComponent } from './eddydata-lib.component';

@NgModule({
  declarations: [EddydataLibComponent],
  imports: [
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [EddydataLibComponent]
})
export class EddydataLibModule { }
