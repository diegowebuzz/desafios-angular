import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RelatorioPersonalizadoShwComponent } from './relatorio-personalizado-shw/relatorio-personalizado-shw.component';
import { RelatorioPersonalizadoLstComponent } from './relatorio-personalizado-lst/relatorio-personalizado-lst.component';
import { RelatorioPersonalizadoViewComponent } from './relatorio-personalizado-view/relatorio-personalizado-view.component';
import { AuthGuard } from '../util/auth.guard';

const routes: Routes = [
  { path: '', component: RelatorioPersonalizadoLstComponent, canActivate: [AuthGuard] },
  { path: 'novo', component: RelatorioPersonalizadoShwComponent, canActivate: [AuthGuard] },
  { path: ':id/editar', component: RelatorioPersonalizadoShwComponent, canActivate: [AuthGuard] },
  { path: ':id/visualizar', component: RelatorioPersonalizadoViewComponent, canActivate: [AuthGuard] }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RelatorioPersonalizadoRoutingModule { }
