import { Agenda } from '../entidade/comum/agenda.model';
import { Orgao } from '../entidade/comum/orgao.model';
import { Usuario } from '../entidade/comum/usuario.model';

export class Coluna {
    agrupar?: boolean;
    titulo: string;
    coluna: string;
    converter?: Array<Converter>;
    alignment?: 'left' | 'center' | 'right';
    decimais?: number;
    funcao?: [Expressao];
    bold?: boolean;
    italic?: boolean;
    decoration?: 'underline' | 'lineThrough' | 'overline';
    fontSize?: number;
    subTitulo?: string;
    tipo?: 'String' | 'Number' | 'Date' | 'Boolean' | 'HTML';
}

export class Expressao {
    valor?: (number | '-' | '+' | '(' | ')' | '*' | '/' | string)[];
    se?: Se;
}

export class Se {
    condicao: string;
    verdadeiro: (number | '-' | '+' | '(' | ')' | '*' | '/' | string | {})[];
    falso: (number | '-' | '+' | '(' | ')' | '*' | '/' | string | {})[];
}

export class Converter {
    id: any;
    nome: any;
}

export type Sistemas =
    'controle-interno' | 'planejamento' | 'tesouraria' | 'compras' | 'contabil' | 'patrimonio' | 'recursos-humanos' | 'protocolo' |
    'almoxarifado' | 'terceiro-setor' | 'indicador-gestao' | 'transparencia' | 'frota' | 'portal-entidade' |
    'portal-cidadao' | 'e-sic' | 'protocolo-cidadao' | 'legislativo' | 'diario-oficial' | 'site' | 'comum' | 'teleonco' |
    'licitacao' | 'requisicao';

export type CondicoesFiltrar = 'eq' | 'ne' | 'gt' | 'ge' | 'lt' | 'le' | 'like' | 'in' | 'not_in' | 'null' | 'not_null';

export type AudespXML =
    'PLAN-CADASTRO' |
    'PLAN-LOA-INICIAL' | 'PLAN-LOA-ATUALIZADA' |
    'PLAN-LDO-INICIAL' | 'PLAN-LDO-ATUALIZADA' |
    'PLAN-PPA-INICIAL' | 'PLAN-PPA-ATUALIZADO' |
    'CADASTROS-CONTABEIS' |
    'BALANCETE-ISOLADO-CONTA-CORRENTE' | 'BALANCETE-ISOLADO-CONTA-CONTABIL';

export type ChaveValor = { chave: string, valor: any };

export type FieldPersonalizado = {
    nome: string;
    campo: string;
    tipoPrototype: any;
    tipo?: 'String' | 'Number' | 'Date' | 'Boolean' | 'HTML';
    classe?: string;
    nomeClasse?: string;
    modulos?: ModuloSistema[];
};

export class ModuloSistema {
    modulo: string;
    sistema: Sistemas;
}

export class FullCalendarProperties {
    agenda: Agenda;

    id?: number;
    allDay?: boolean;
    start?: string | Date;
    end?: string | Date;
    title?: string;
    color?: any;
    extendedProps?: any;

    descricao?: string;
    recorrente?: 'N' | 'D' | 'DS' | 'S' | 'M' | 'A';
    concluido?: boolean;
    orgao?: Orgao;
    usuario?: Usuario;

    url?: string;
    groupId?: any;
    daysOfWeek?: any;
    startTime?: string;
    endTime?: string;
    startRecur?: any;
    endRecur?: any;
    classNames?: any;
    editable?: any;
    startEditable?: any;
    durationEditable?: any;
    resourceEditable?: any;
    resourceIds?: any;
    rendering?: any;
    overlap?: any;
    constraint?: any;
    backgroundColor?: any;
    borderColor?: any;
    textColor?: any;
}

export const DIA_TIME: number = 24 * 60 * 60 * 1000;

/**
 * B = Baixa,
 * C = Compra,
 * I = Inventário,
 * O = Doação,
 * V = Devolução,
 * T = Transferência,
 * E = Estorno
 */
export type EspecieAlmoxarifado = 'B' | 'C' | 'I' | 'O' | 'V' | 'T' | 'E';

export type loteSaldo = { nome: string, saldo: number, vencimento: Date };

export type unidadeSaldo = { unidade: ChaveValor, lotes: loteSaldo[], saldo: number };

export type produtoSaldo = { produto: ChaveValor, unidades: unidadeSaldo[], saldo: number };


export class Ordem {
    campo: Coluna;
    asc: boolean;
}

export class FiltroPersonalizado {
    campo: Coluna;
    operador: CondicoesFiltrar;
    valor: any;
    valorTemp: any;

    retornarOperador(oper: string): CondicoesFiltrar {
        if (oper) {
            switch (oper) {
                case 'like':
                    return 'like';
                case 'gt':
                    return 'gt';
                case 'ge':
                    return 'ge';
                case 'lt':
                    return 'lt';
                case 'le':
                    return 'le';
                case 'ne':
                    return 'ne';
                case 'null':
                    return 'null';
                case 'not_null':
                    return 'not_null';
                case 'in':
                    return 'in';
                case 'not_in':
                    return 'not_in';
                default:
                    return 'eq';
            }
        } else {
            return null;
        }
    }
}

export type FormatoExportacao = 'pdf' | 'xlsx' | 'xml' | 'JSON' | 'csv' | 'docx';

export type SituacaoLicitacao = 'PENDENTE' | 'ADJUDICADA' | 'ATIVA' | 'ANULADA' | 'SUSPENSA' |
    'DESERTA' | 'FRACASSADA' | 'HOMOLOGADA' | 'HOMOLOGADA – PARCIAL' | 'REVOGADA' | 'OUTRA';