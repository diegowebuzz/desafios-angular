export class ExpressaoOpcoes {
    expressaoOpcoes: (number | '-' | '+' | '(' | ')' | '*' | '/' | string);
}
