import { Component, OnInit, Input, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'lib-paginacao',
  templateUrl: './paginacao.component.html'
})
export class PaginacaoComponent implements OnInit {

  @Input() paginaCorrente: number;
  @Input() paginaTotal: number;

  @Output() paginaAnterior = new EventEmitter();
  @Output() proximaPagina = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

  clickPaginaAnterior() {
    this.paginaAnterior.emit();
  }

  clickProximaPagina() {
    this.proximaPagina.emit();
  }

}
