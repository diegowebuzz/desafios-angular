export interface ProgressoState {
    show: boolean;
    id: number;
    funcao: Function;
}
