import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { FuncaoService } from '../util/funcao.service';
import { Coluna, Converter } from './types';

export class Relatorio {

  private static funcaoService = new FuncaoService();

  constructor() {
  }

  /**
   * Imprime de forma dinâmica um PDF
   * @param titulo - Título do relatório
   * @param usuario - Usuário logado
   * @param orgao - órgão logado
   * @param brasao - brasão do órgão em base64
   * @param lista - lista de registros
   * @param colunas - colunas que serão impressas
   * @param orientacao - orientação da página
   * @param nomePdf - nome do arquivo PDF
   * @param largura - vetor com as larguras das colunas
   * @param totalizar - colunas para totalizar ao fim do relatório
   */
  static imprimir(titulo: string, usuario: string, orgao: string, brasao: string,
    lista: any[], colunas: string[] | Coluna[], orientacao: 'landscape' | 'portrait', nomePdf?: string,
    largura?: (string | number)[], totalizar?: (string | {})[]) {
    if (!largura) {
      largura = [];
      for (let i = 0; i < colunas.length; i++) {
        const coluna: any = colunas[i];
        if (typeof coluna === 'string') {
          largura.push('*');
        } else {
          if (coluna['agrupar'] !== true) {
            largura.push('*');
          }
        }
      }
    }
    const conteudo: Array<Array<any>> = this.retornarConteudo(colunas, lista, totalizar);
    const content = [
      {
        layout: 'padrao',
        table: {
          headerRows: 1,
          widths: largura,

          body: conteudo
        }
      },
      { text: 'Total de registros: ' + lista.length, alignment: 'right', margin: [0, 10, 0, 0] }
    ];
    this.imprimirPersonalizado(titulo, usuario, orgao, brasao, content, orientacao, nomePdf);
  }

  static imprimirPersonalizado(
    titulo: string, usuario: string, orgao: string, brasao: string, conteudo: {}[],
    orientacao: 'landscape' | 'portrait', nomePdf?: string, layouts?: {}, ocultarCabecalho: boolean = false,
    ocultarRodape: boolean = false) {
    if (!layouts) {
      layouts = {
        padrao: {
          hLineWidth(i, node) {
            return (i === node.table.headerRows || i === 0) ? 2 : 0;
          },
          vLineWidth(i) {
            return 0;
          },
          hLineColor(i) {
            return i === 1 || i === 0 ? 'black' : '#aaa';
          },
          paddingLeft(i) {
            return i === 0 ? 0 : 3;
          },
          paddingRight(i, node) {
            return (i === node.table.widths.length - 1) ? 0 : 3;
          }
        }
      };
    } else {
      layouts['padrao'] = {
        hLineWidth(i, node) {
          return (i === node.table.headerRows || i === 0) ? 2 : 0;
        },
        vLineWidth(i) {
          return 0;
        },
        hLineColor(i) {
          return i === 1 || i === 0 ? 'black' : '#aaa';
        },
        paddingLeft(i) {
          return i === 0 ? 0 : 8;
        },
        paddingRight(i, node) {
          return (i === node.table.widths.length - 1) ? 0 : 8;
        }
      };
    }
    if (!orientacao) {
      orientacao = 'portrait';
    }
    let brasaoImage: {};
    if (brasao) {
      brasaoImage = {
        image: brasao,
        width: 70,
        alignment: 'center',
        margin: [0, 30, 0, 0]
      };
    } else {
      brasaoImage = { margin: [0, 30, 0, 0], text: '' };
    }
    let cabecalho = [];

    if (!ocultarCabecalho) {
      cabecalho = [
        brasaoImage,
        { text: orgao, style: 'header' },
        { text: titulo, style: 'sub_header' }
      ];
    }
    const dd: any = {
      info: {
        title: (nomePdf ? nomePdf : 'listagem')
      },
      header: cabecalho,
      footer(currentPage, pageCount, pageSize) {
        const hoje = new Date();
        return ocultarRodape ? [] : [{ canvas: [{ type: 'line', x1: 30, y1: 10, x2: pageSize.width - 30, y2: 10, lineWidth: 0.5 }] },
        {
          columns: [{
            text: (usuario ? 'Emitido por ' + usuario + ' - ' : '') + hoje.toLocaleString(),
            alignment: 'left', margin: [30, 5, 0, 0], style: 'footer'
          },
          {
            text: 'Página ' + currentPage.toString() + ' de ' + pageCount, alignment: 'right',
            margin: [0, 5, 30, 0], style: 'footer'
          }]
        }
        ];
      },
      content: conteudo,
      styles: {
        header: {
          bold: true,
          fontSize: 16,
          alignment: 'center'
        },
        sub_header: {
          fontSize: 12,
          alignment: 'center'
        },
        footer: {
          fontSize: 8
        }
      },
      defaultStyle: {
        fontSize: 8
      },
      pageMargins: [30, ocultarCabecalho ? 20 : brasao ? 140 : 80, 30, ocultarRodape ? 20 : 40],
      pageSize: 'A4',
      pageOrientation: orientacao
    };
    pdfMake.createPdf(dd, layouts, null, pdfFonts.pdfMake.vfs).open();
  }

  static retornarConteudo(colunas: string[] | Coluna[], lista: any[], totalizar: (string | {})[]): Array<Array<any>> {
    const retorno: Array<Array<any>> = new Array();
    const header = new Array();
    let qtdGrupos = 0;
    // varre as colunas para montar cabeçalho
    for (let i = 0; i < colunas.length; i++) {
      const coluna: string | Coluna = colunas[i];
      if (typeof coluna === 'string') {
        header.push({ text: coluna, bold: true });
      } else if (coluna.agrupar) {
        qtdGrupos++;
      } else {
        header.push({ text: coluna.titulo, bold: true, alignment: coluna.alignment ? coluna.alignment : 'left' });
      }
    }
    retorno.push(header);
    // método que agrupa os registros (funciona mesmo sem agrupamento)
    const linhas = this.conteudoAgrupado(colunas, lista, colunas.length, qtdGrupos, totalizar);
    if (totalizar) {
      const totalGeral = this.funcaoService.totalizar(lista, totalizar);
      const registroGeral = new Array();
      let indiceTotalizador = 0;
      let qtdeColunas = 0;
      // percorre as colunas para encontrar e procura o totalizador
      for_colunas:
      for (const col of colunas) {
        // caso a coluna seja de agrupamento ignora pois nao aparece como coluna
        if (typeof col !== 'string' && col.agrupar) {
          continue;
        } else {
          qtdeColunas++;
          const nomeColuna: string = (typeof col === 'string' ? col : col.coluna);

          // percorre os totalizadores para procurar a coluna atual, caso nao encontre inclui uma posição vazia
          for (const total of totalizar) {
            const nomeTotalizador: string = (typeof total === 'string' ? total : total['nome']);
            // caso encontre a coluna no totalizador a inclui e continua o laço das colunas
            if (nomeColuna === nomeTotalizador) {
              if (!indiceTotalizador) {
                indiceTotalizador = qtdeColunas - 1;
              }
              registroGeral.push({
                text: this.funcaoService.convertToBrNumber(totalGeral[(nomeTotalizador)], 2),
                bold: true, alignment: 'right',
                preserveLeadingSpaces: true,
                fontSize: 9, decoration: 'underline'
              });
              continue for_colunas;
            }
          }
          registroGeral.push('');
        }
      }

      // remove a primeira posição para incluir o nome do agrupamento
      registroGeral.shift();
      registroGeral.unshift({
        colSpan: indiceTotalizador < 1 ? 0 : indiceTotalizador - 1,
        text: 'Total Geral:',
        bold: true, alignment: 'left', preserveLeadingSpaces: true,
        fontSize: 10, decoration: 'underline'
      });
      linhas.push(registroGeral);
    }

    return retorno.concat(linhas);
  }

  static conteudoAgrupado(
    colunas: string[] | Coluna[], lista: any[], tamanho: number,
    qtdGrupos: number, totalizar?: (string | {})[], processados?: number): Array<Array<any>> {
    let retorno: Array<Array<any>> = new Array();
    if (!lista || lista.length === 0) {
      return retorno;
    }
    // varre as colunas procurando agrupamentos
    if (!processados) {
      processados = 0;
    }
    for (let i = processados; i < colunas.length; i++) {
      const coluna: string | Coluna = colunas[i];
      if (typeof coluna !== 'string') {
        if (coluna.agrupar) {
          // retorna o grupo com os registros e totalizadores
          const grupos = this.funcaoService.agrupar(lista, coluna.coluna, totalizar);
          for (const grupo of grupos) {
            const registroGrupo = new Array();
            // caso coluna seja um enum, converte para texto
            if (coluna.converter) {
              const valores = coluna.converter as Converter[];
              for (let c = 0; c < valores.length; c++) {
                const val = valores[c];
                if (val.id === grupo.grupo) {
                  grupo.grupo = val.nome;
                }
              }
            }

            let indiceTotalizador = 0;
            let qtdeColunas = 0;
            // percorre as colunas para encontrar e procura o totalizador
            for_colunas:
            for (const col of colunas) {
              // caso a coluna seja de agrupamento ignora pois nao aparece como coluna
              if (typeof col !== 'string' && col.agrupar) {
                continue;
              } else {
                qtdeColunas++;
                // caso haja totalizadores os inclui na posição de cada coluna correspondente
                if (totalizar) {
                  const nomeColuna: string = (typeof col === 'string' ? col : col.coluna);

                  // percorre os totalizadores para procurar a coluna atual, caso nao encontre inclui uma posição vazia
                  for (const total of totalizar) {
                    const nomeTotalizador: string = (typeof total === 'string' ? total : total['nome']);
                    // caso encontre a coluna no totalizador a inclui e continua o laço das colunas
                    if (nomeColuna === nomeTotalizador) {
                      if (!indiceTotalizador) {
                        indiceTotalizador = qtdeColunas - 1;
                      }
                      registroGrupo.push({
                        text: this.funcaoService.convertToBrNumber(
                          grupo.totalizadores[(nomeTotalizador)], 2),
                        bold: coluna.bold,
                        alignment: 'right', italics: coluna.italic, decoration: coluna.decoration
                      });
                      continue for_colunas;
                    }
                  }
                  registroGrupo.push('');
                } else {
                  registroGrupo.push('');
                }
              }
            }

            // remove a primeira posição para incluir o nome do agrupamento
            registroGrupo.shift();
            registroGrupo.unshift({
              colSpan: indiceTotalizador < 1 ? 0 : indiceTotalizador - 1,
              text: coluna.titulo + ' ' + this.funcaoService.retornaCelula(coluna, grupo.grupo, null),
              bold: coluna.bold, alignment: coluna.alignment, preserveLeadingSpaces: true,
              italics: coluna.italic, decoration: coluna.decoration, fontSize: coluna.fontSize
            });

            // adiciona a linha do grupo no relatório
            retorno.push(registroGrupo);
            // chamada recursiva para fazer subgrupos ou inserir linhas do grupo
            retorno = retorno.concat(this.conteudoAgrupado(colunas, grupo.registros, tamanho, qtdGrupos, totalizar, +processados + 1));
          }
          return retorno;
        } else {
          // caso não seja coluna de agrupamento, retorna as linhas do relatório (antigo Detail do jasper)
          return this.conteudoGeral(colunas, lista, tamanho, qtdGrupos);
        }
      } else {
        // caso não seja coluna de agrupamento, retorna as linhas do relatório (antigo Detail do jasper)
        return this.conteudoGeral(colunas, lista, tamanho, qtdGrupos);
      }
    }
  }

  // static espacos(quantidade: number): string {
  //   let retorno = '';
  //   for (let i = 0; i < quantidade; i++) {
  //     retorno += '    ';
  //   }
  //   return retorno;
  // }

  static conteudoGeral(colunas: string[] | Coluna[], lista: any[], tamanho: number, qtdGrupos: number): Array<Array<any>> {
    const retorno: Array<Array<any>> = new Array();
    // varre os registros para criar linha do relatório
    for (let i = 0; i < lista.length; i++) {
      const registro = new Array();
      const ent = lista[i];
      for (let a = qtdGrupos; a < colunas.length; a++) {
        const coluna: string | Coluna = colunas[a];
        if (typeof coluna === 'string') {
          registro.push(ent[coluna]);
        } else {
          registro.push({
            text: this.funcaoService.retornaCelula(coluna, this.funcaoService.retornaValorEntidade(ent, coluna.coluna), ent),
            alignment: coluna.alignment ? coluna.alignment : 'left', bold: coluna.bold, fontSize: coluna.fontSize,
            italics: coluna.italic, decoration: coluna.decoration, preserveLeadingSpaces: true
          });
        }
      }
      retorno.push(registro);
    }
    return retorno;
  }

}

