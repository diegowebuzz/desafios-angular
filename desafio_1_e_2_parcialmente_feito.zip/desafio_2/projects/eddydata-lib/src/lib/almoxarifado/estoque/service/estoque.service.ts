import { Injectable, Injector } from '@angular/core';
import { BaseResourceService } from '../../../models/services/base-resource.service';
import { Estoque } from '../../../entidade/almoxarifado/estoque.model';

@Injectable({
  providedIn: 'root'
})
export class EstoqueService extends BaseResourceService<Estoque> {

  constructor(
    protected injector: Injector
  ) {
    super(`estoques`, injector);
  }

}
