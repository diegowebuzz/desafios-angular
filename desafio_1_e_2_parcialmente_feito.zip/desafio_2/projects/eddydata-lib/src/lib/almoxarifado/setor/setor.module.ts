import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IMaskModule } from 'angular-imask';
import { AccordionModule } from 'primeng/accordion';
import { MessageService } from 'primeng/api';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { CalendarModule } from 'primeng/calendar';
import { ToastModule } from 'primeng/toast';
import { SetorAlmoxarifadoComponent } from './setor-almoxarifado/setor-almoxarifado.component';
import { SetorFormComponent } from './setor-form/setor-form.component';
import { SetorListComponent } from './setor-list/setor-list.component';
import { SetorRoutingModule } from './setor-routing.module';
import { SetorViewComponent } from './setor-view/setor-view.component';
import { SharedModule } from '../../util/shared.module';
import { UsuarioModule } from '../../usuario/usuario.module';

@NgModule({
  declarations: [
    SetorListComponent,
    SetorFormComponent,
    SetorViewComponent,
    SetorAlmoxarifadoComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    SetorRoutingModule,
    AutoCompleteModule,
    AccordionModule,
    CalendarModule,
    IMaskModule,
    ToastModule,
    UsuarioModule
  ],
  providers: [MessageService]
})
export class SetorModule { }
