import { Component, ElementRef, Input, OnChanges, OnDestroy, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { MessageService } from 'primeng/api';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SetorAlmoxarifadoService } from '../service/setor-almoxarifado.service';
import { SetorAlmoxarifado } from '../../../entidade/almoxarifado/setor-almoxarifado.model';
import { EddyAutoComplete } from '../../../models/form-components';
import { Estoque } from '../../../entidade/almoxarifado/estoque.model';
import { Setor } from '../../../entidade/almoxarifado/setor.model';
import { Login } from '../../../entidade/login/login';
import { FuncaoService } from '../../../util/funcao.service';
import { EstoqueService } from '../../estoque/service/estoque.service';

@Component({
  selector: 'app-setor-almoxarifado',
  templateUrl: './setor-almoxarifado.component.html'
})
export class SetorAlmoxarifadoComponent implements OnInit, OnChanges, OnDestroy {

  public itemAtual: SetorAlmoxarifado;
  public listaEstoques: Array<any>;
  public estoqueAutoComplete: EddyAutoComplete<Estoque>;
  protected unsubscribe: Subject<void> = new Subject();

  @Input() lista: Array<any>;
  @Input() entidade: Setor;
  @Input() login: Login;

  @ViewChild('btnAdicionar') public btnAdicionar: ElementRef;

  constructor(
    private messageService: MessageService,
    protected funcaoService: FuncaoService,
    protected setorAlmoxService: SetorAlmoxarifadoService,
    protected estoqueService: EstoqueService
  ) { }

  ngOnInit() {
    this.listaEstoques = this.lista;
    this.carregarAutoCompletes();
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.lista) {
      this.listaEstoques = this.lista;
    }
  }

  public adicionar() {
    this.itemAtual = new SetorAlmoxarifado();
    this.itemAtual.editavel = true;
    if (!this.lista) {
      this.lista = [];
    }
    this.lista.unshift(this.itemAtual);
    this.btnAdicionar.nativeElement.disabled = true;
  }

  public salvar(item: SetorAlmoxarifado) {
    try {
      if (!item.estoque) {
        throw new Error('Informe o estoque!');
      }

      // envia a entidade para ser salva no banco -----
      this.btnAdicionar.nativeElement.disabled = false;
      this.itemAtual.editavel = false;
    } catch (e) {
      this.messageService.add({ severity: 'error', summary: 'Validação', detail: e });
      throw e;
    }
  }

  public editar(item: SetorAlmoxarifado) {
    this.itemAtual = item;
    this.itemAtual.editavel = true;
    this.btnAdicionar.nativeElement.disabled = true;
  }

  public cancelar(item: SetorAlmoxarifado) {
    this.itemAtual = item;
    if (!this.itemAtual.estoque && !this.itemAtual.id) {
      this.lista.splice(this.lista.findIndex((itm) => { return itm === item }), 1);
    } else {
      this.itemAtual.editavel = false;
    }
    this.btnAdicionar.nativeElement.disabled = false;
  }

  public remover(item: SetorAlmoxarifado) {
    if (item.id) {
      this.setorAlmoxService.remover(item.id).pipe(takeUntil(this.unsubscribe))
        .subscribe((res) => {
          this.messageService.add({ severity: 'info', summary: 'Exclusão', detail: 'Registro removido com sucesso!' });
        });
    }
    this.lista.splice(this.lista.findIndex((itm) => { return itm === item }), 1);
    this.btnAdicionar.nativeElement.disabled = false;
  }

  private carregarAutoCompletes() {
    this.estoqueAutoComplete = new EddyAutoComplete(null, this.estoqueService,
      'id', ['id', 'nome'], { orgao_id: this.login.orgao.id, orderBy: 'nome' }, { number: ['id'], text: ['nome'] }
    );
  }

}
