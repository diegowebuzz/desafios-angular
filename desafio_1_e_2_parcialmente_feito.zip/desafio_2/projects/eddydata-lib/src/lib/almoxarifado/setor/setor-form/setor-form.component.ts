import { Component, ElementRef, ViewChild, Injector } from '@angular/core';
import { MessageService } from 'primeng/api';
import { Validators } from '@angular/forms';
import { SetorAlmoxarifado } from '../../../entidade/almoxarifado/setor-almoxarifado.model';
import { BaseResourceFormComponent } from '../../../models/base-resource-form';
import { Setor } from '../../../entidade/almoxarifado/setor.model';
import { LoginContabil } from '../../../entidade/login/login-contabil';
import { EddyAutoComplete } from '../../../models/form-components';
import { Unidade } from '../../../entidade/planejamento/unidade.model';
import { FuncaoService } from '../../../util/funcao.service';
import { GlobalService } from '../../../util/global.service';
import { UnidadeService } from '../../../unidade/service/unidade.service';
import { SetorService } from '../service/setor.service';


@Component({
  selector: 'app-setor-form',
  templateUrl: './setor-form.component.html'
})
export class SetorFormComponent extends BaseResourceFormComponent<Setor, LoginContabil> {

  /**
   * Declaração de variáveis
   */
  public estoques: SetorAlmoxarifado[];

  @ViewChild('sigla') inputSigla: ElementRef;

  public unidadeAutoComplete: EddyAutoComplete<Unidade>;

  /**
   * Construtor com as injeções de dependencias
   */
  constructor(
    protected injector: Injector,
    private messageService: MessageService,
    protected funcaoService: FuncaoService,
    protected globalService: GlobalService,
    protected unidadeService: UnidadeService,
    protected setorService: SetorService) {
    super(new Setor(), injector, Setor.converteJson, setorService);
  }

  // ========================================================================
  //                        MÉTODOS ABSTRAÍDOS
  // ========================================================================

  protected criarCamposForm(): void {
    this.entidadeForm = this.fb.group({
      id: [null],
      codigo: [null],
      nome: [null, [Validators.required]],
      cep: [null],
      endereco: [null],
      bairro: [null],
      telefone: [null],
      sigla: [null],
      email: [null],
      ativo: [null, [Validators.required]],
      responsavel: [null],
      cargo: [null],
      setor_protocolo: [null, [Validators.required]],
      aux: [null],
      orgao: [this.login.orgao, [Validators.required]],
      unidade: [null,],
      estoques: [null],
    });
  }

  protected parametrosExtras(): {} {
    return { relations: 'unidade,estoques.estoque,estoques.setor' };
  }

  protected afterLoad() {
    this.estoques = this.entidade.estoques;
  }

  protected afterInit(): void {
    this.carregarAutoCompletes();
  }

  protected campoFoco(): ElementRef {
    return this.inputSigla;
  }

  protected beforeSubmit() {
    try {
      if (this.entidadeForm.get('nome').value === '') {
        throw new Error('Informe o nome do setor!');
      }
    } catch (e) {
      this.messageService.add({ severity: 'error', summary: 'Validação', detail: e });
      throw e;
    }
  }

  protected afterSubmit(modelo: Setor) {
  }

  // ========================================================================
  //                            MÉTODOS DA CLASSE
  // ========================================================================

  private carregarAutoCompletes() {
    // autocomplete para unidade
    this.unidadeAutoComplete = new EddyAutoComplete(this.entidadeForm.get('unidade'), this.unidadeService,
      'id', ['codigo', 'nome'], {
      orderBy: 'nome', 'ppa.id': this.login.ppa.id
    }, { number: ['codigo'], text: ['nome'] }
    );
  }

}
