import { Component, Injector } from '@angular/core';
import { Observable } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Coluna, FormatoExportacao } from '../../../components/types';
import { Setor } from '../../../entidade/almoxarifado/setor.model';
import { LoginContabil } from '../../../entidade/login/login-contabil';
import { BaseResourceListComponent, Filtro } from '../../../models/base-resource-list';
import { SetorService } from '../service/setor.service';

@Component({
  selector: 'app-setor-list',
  templateUrl: './setor-list.component.html'
})
export class SetorListComponent extends BaseResourceListComponent<Setor, LoginContabil> {
  /**
   * Declaração de variáveis
   */

  /**
   * Construtor com as injeções de dependencias
   */
  constructor(
    protected injector: Injector,
    private setorService: SetorService) {
    super(setorService, injector);
  }

  // ========================================================================
  //                        MÉTODOS ABSTRAÍDOS
  // ========================================================================

  protected relations(): string {
    return 'orgao';
  }

  protected condicoesGrid(): {} {
    return {
      ['orgao.id']: this.login.orgao.id
    };
  }

  protected ordenacaoGrid(): string[] {
    return ['id$ASC'];
  }

  protected filtrosGrid(): Filtro {
    return {
      number: ['id'],
      text: ['nome', 'sigla', 'endereco', 'telefone'],
    };
  }

  protected afterInit(): void {
  }

  protected acaoRemover(model: Setor): Observable<Setor> {
    return null;
  }

  protected colunasRelatorio(): string[] | Coluna[] {
    return [
      { titulo: 'Id', coluna: 'id' },
      { titulo: 'Nome', coluna: 'nome' },
      { titulo: 'Responsável', coluna: 'responsavel' },
      { titulo: 'Telefone', coluna: 'telefone' }
    ];
  }

  public exportarListagem(formato: FormatoExportacao) {
    const parametros = this.obterParametros();
    parametros['relations'] = 'orgao';
    this.setorService
      .filtrar(1, -1,
        parametros
      )
      .pipe(takeUntil(this.unsubscribe))
      .subscribe(
        lista => {
          if (formato === 'pdf') {
            this.imprimir(`LISTAGEM DE SETORES`,
              this.login.usuario.nome, this.login.orgao.nome, this.login.brasao, 'portrait',
              'Listagem setores', ['auto', '*', 'auto', 'auto'], lista.content);
          } else {
            this.exportar(formato, lista.content);
          }
        },
        () => alert('erro ao retornar lista')
      );
  }

}
