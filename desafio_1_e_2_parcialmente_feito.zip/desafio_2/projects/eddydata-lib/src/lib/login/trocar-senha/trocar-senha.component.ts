import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import * as toastr from 'toastr';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { Login } from '../../entidade/login/login';
import { UsuarioService } from '../../usuario/service/usuario.service';
import { LoginService } from '../servico/login.service';
import { Router } from '@angular/router';


@Component({
  selector: 'lib-trocar-senha',
  templateUrl: './trocar-senha.component.html'
})
export class TrocarSenhaComponent implements OnInit, OnDestroy {

  public login: Login = new Login();
  public senhaAtual: string;
  public senhaNova: string;
  protected unsubscribe: Subject<void> = new Subject();

  constructor(
    protected router: Router,
    private usuarioService: UsuarioService,
    private loginService: LoginService
  ) {
  }

  ngOnInit() {
    this.login = JSON.parse(sessionStorage.getItem('login'));
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  enviar() {
    this.login.usuario.senha = this.senhaAtual;
    this.login.usuario.senha_nova = this.senhaNova;
    this.usuarioService.trocarSenha(this.login.usuario).pipe(takeUntil(this.unsubscribe))
      .subscribe((res) => {
        toastr.success('Senha foi alterada com sucesso!');
        this.login.usuario.orgao = this.login.orgao;
        this.loginService.desconectar(this.login.usuario);
      }, (error) => {
        toastr.error('Senha informada não confere, tente novamente!');
      });
    this.senhaAtual = null;
    this.senhaNova = null;
  }

}
