import { Component, OnInit, Injector, Input } from '@angular/core';
import { LoginService } from './../servico/login.service';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'lib-recuperar-senha',
  templateUrl: './recuperar-senha.component.html',
  styleUrls: ['./recuperar-senha.component.css']
})
export class RecuperarSenhaComponent implements OnInit {

  public msgs: string;
  public email: string;

  protected router: Router;

  constructor(
    protected injector: Injector,
    private messageService: MessageService,
    private authService: LoginService) {
    this.router = this.injector.get(Router);
  }

  ngOnInit() {
  }

  async enviarEmail() {
    try {
      const resultado = await this.authService.recuperarSenha(this.email);
      if (resultado && resultado.error) {
        this.msgs = resultado.error.message;
      } else {
        this.router.navigate([`/recuperar-senha-sucesso`]);
      }
    } catch (ex) {
      this.messageService.add({ severity: 'error', summary: 'Atenção', detail: ex.error });
    }
  }

  voltar() {
    this.router.navigate([`/login`]);
  }

}
