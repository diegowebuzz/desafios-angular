import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-login-registro-sucesso',
  templateUrl: './login-registro-sucesso.component.html',
  styleUrls: ['./login-registro-sucesso.component.css']
})
export class LoginRegistroSucessoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
