import { Component, OnInit, Injector, Input } from '@angular/core';
import { LoginService } from './servico/login.service';
import { Router } from '@angular/router';
import { FuncaoService } from '../util/funcao.service';
import { Sistemas } from '../components/types';
import { environment } from '../../environments/environment';

@Component({
  selector: 'lib-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  @Input() sistema: Sistemas;

  protected router: Router;

  public msgs: string;
  public email: string;
  public senha: string;
  public maskConfig = {
    mask: [
      {
        mask: '000.000.000-00'
      },
      {
        mask: /^\S*@?\S*$/
      }
    ]
  };

  constructor(
    protected injector: Injector,
    private authService: LoginService) {
    this.router = this.injector.get(Router);
    const login = JSON.parse(sessionStorage.getItem('login'));
    if (login && login.usuario && login.usuario.sistema) {
      new FuncaoService().navegarPara(login.usuario.sistema, this.router, login);
    }
  }

  ngOnInit() {
    this.authService.mostrarMenuEmitter.emit(false);
  }

  async fazerLogin() {
    const resultado = await this.authService.autenticar(this.email, this.senha, this.sistema);
    if (resultado && !resultado.entidade) {
      this.msgs = resultado.error ? resultado.error.message : resultado.message;
    }
  }

  recuperarSenha() {
    this.authService.mostrarMenuEmitter.emit(false);
    this.router.navigate([`/recuperar-senha`]);
  }

  registroUsuario() {
    this.authService.mostrarMenuEmitter.emit(false);
    this.router.navigate([`/registro`]);
  }

  loginEntidade() {
    this.authService.mostrarMenuEmitter.emit(false);
    this.router.navigate([`/login-entidade`]);
  }

  mostrarVersao(): string {
    return environment?.versao;
  }

}
