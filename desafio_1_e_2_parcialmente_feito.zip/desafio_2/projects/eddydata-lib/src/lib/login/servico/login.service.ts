import { Injectable, EventEmitter, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Usuario } from '../../entidade/comum/usuario.model';
import { Subject } from 'rxjs';
import { Sistemas } from '../../components/types';
import { FuncaoService } from '../../util/funcao.service';
import { ProgressoService } from '../../components/progresso/service/progresso.service';
import { Login } from '../../entidade/login/login';
import { LoginContabil } from '../../entidade/login/login-contabil';
import { LoginEntidade } from '../../entidade/login/login-entidade';
import { LoginPublico } from '../../entidade/login/login-publico';
import { LoginProtocolo } from '../../entidade/login/login-protocolo';
import { LoginFolha } from '../../entidade/login/login-folha';
import { Orgao } from '../../entidade/comum/orgao.model';
import { takeUntil } from 'rxjs/operators';
import { OrgaoService } from '../../orgao/service/orgao.service';
import { ExercicioService } from '../../exercicio/service/exercicio.service';
import { UsuarioService } from '../../usuario/service/usuario.service';
import { UsuarioAcessoService } from '../../usuario/service/usuario-acesso.service';
import { environment } from '../../../environments/environment';
import { ParametroContabilService } from './parametro-contabil.service';
import { PpaService } from './ppa.service';

@Injectable({
  providedIn: 'root'
})
export class LoginService implements OnDestroy {

  private usuario: Usuario;
  public usuarioAutenticado = false;
  protected unsubscribe: Subject<void> = new Subject();
  mostrarMenuEmitter = new EventEmitter<boolean>();
  mostrarMenuLateralEmitter = new EventEmitter<boolean>();
  sistemaEmitter = new EventEmitter<Sistemas>();
  mostrarContrasteEmitter = new EventEmitter<boolean>();

  error = {
    error: {
      message: ''
    }
  };

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  constructor(
    private router: Router,
    private orgaoServico: OrgaoService,
    private funcaoServico: FuncaoService,
    private usuarioServico: UsuarioService,
    private exercicioServico: ExercicioService,
    private parametroServico: ParametroContabilService,
    private ppaServico: PpaService,
    private usuarioAcessoServico: UsuarioAcessoService,
    private progressoServico: ProgressoService) { }

  async autenticar(email: string, senha: string, sistema: Sistemas, cnpj?: string) {
    try {
      this.error = {
        error: {
          message: ''
        }
      };
      const dados = await this.usuarioServico.autenticar(email, senha, sistema).toPromise();
      if (dados.entidade) {
        this.usuario = dados.entidade;
        if (this.usuario.favorecido && this.usuario.sistema !== 'portal-entidade') {
          this.error.error.message = 'Você esta cadastrado no sistema como usuário de uma entidade do terceiro setor!';
          sessionStorage.setItem('login', null);
          sessionStorage.clear();
          return this.error;
        }
        if (this.usuario.favorecido && (!cnpj || cnpj === '')) {
          this.error.error.message = 'Informe o CNPJ da Entidade!';
          sessionStorage.setItem('login', null);
          sessionStorage.clear();
          return this.error;
        }
        let login = new Login();
        switch (this.usuario.sistema) {
          case 'controle-interno':
          case 'contabil':
          case 'compras':
          case 'terceiro-setor':
          case 'indicador-gestao':
          case 'diario-oficial':
          case 'legislativo':
          case 'licitacao':
            login = new LoginContabil();
            break;
          case 'portal-entidade':
          case 'portal-cidadao':
            login = new LoginEntidade();
            break;
          case 'e-sic':
          case 'transparencia':
          case 'almoxarifado':
          case 'site':
            login = new LoginPublico();
            break;
          case 'protocolo':
          case 'protocolo-cidadao':
            login = new LoginProtocolo();
            break;
          case 'recursos-humanos':
            login = new LoginFolha();
            break;
        }
        const usuario = new Usuario();
        usuario.id = this.usuario.id;
        usuario.nome = this.usuario.nome;
        usuario.convidado = this.usuario.convidado;
        usuario.sobrenome = this.usuario.sobrenome;
        usuario.cpf = this.usuario.cpf;
        usuario.telefone = this.usuario.telefone;
        usuario.email = this.usuario.email;
        usuario.administrador = this.usuario.administrador;
        usuario.sistema = await this.getSistema(login, sistema);
        usuario.setor = this.usuario.setor;
        usuario.unidade = this.usuario.unidade;
        usuario.estoque = this.usuario.estoque;
        login.usuario = usuario;
        const orgao = new Orgao();
        orgao.id = this.usuario.orgao.id;
        orgao.codigo = this.usuario.orgao.codigo;
        orgao.nome = this.usuario.orgao.nome;
        orgao.cnpj = this.usuario.orgao.cnpj;
        orgao.endereco = this.usuario.orgao.endereco;
        orgao.cep = this.usuario.orgao.cep;
        orgao.bairro = this.usuario.orgao.bairro;
        orgao.especie = this.usuario.orgao.especie;
        orgao.telefone = this.usuario.orgao.telefone;
        orgao.site = this.usuario.orgao.site;
        login.orgao = orgao;

        login.brasao = this.usuario.orgao.brasao ? this.usuario.orgao.brasao.brasao : '';
        login.sistema = sistema;
        login.versao = environment.versao;

        login.cidade = this.usuario.orgao.cidade;
        const ano = new Date().getFullYear();

        login.token = 'JWT ' + dados.token;
        login.acessos = this.usuario.acessos;
        login.limite = 20;
        sessionStorage.setItem('login', JSON.stringify(login));
        const ex = await this.exercicioServico.obterPorAno(ano, login.cidade.id).toPromise();

        if (!ex.content[0]) {
          this.error.error.message = 'O exercício atual não foi cadastrado, por favor entre em contato com o administrador do sistema!';
          sessionStorage.setItem('login', null);
          sessionStorage.clear();
          return this.error;
        }
        login.exercicio = ex.content[0];
        if (usuario.sistema === 'contabil' || usuario.sistema === 'compras' || usuario.sistema === 'terceiro-setor' || usuario.sistema === 'diario-oficial'
          || usuario.sistema === 'controle-interno' || usuario.sistema === 'indicador-gestao' || usuario.sistema === 'licitacao') {
          const loginContabil = login as LoginContabil;
          await this.loginContabilidade(loginContabil, ano);
          if (!loginContabil.ppa) {
            this.error.error.message =
              'Não foi encontrado um plano plurianual para o ano corrente, entre em contato com o Administrador do sistema!';
            sessionStorage.setItem('login', null);
            sessionStorage.clear();
            return this.error;
          }
          login = loginContabil;
        } else if (usuario.sistema === 'portal-entidade' || usuario.sistema === 'protocolo-cidadao') {
          const loginEntidade = login as LoginEntidade;
          if (await this.loginEntidade(loginEntidade, cnpj)) {
            sessionStorage.setItem('login', null);
            sessionStorage.clear();
            return this.error;
          }
          login = loginEntidade;
        } else if (usuario.sistema === 'e-sic' || usuario.sistema === 'site' || usuario.sistema === 'transparencia' || usuario.sistema === 'almoxarifado') {
          const loginPublico = login as LoginPublico;
          await this.loginContabilidade(loginPublico, ano);
          login = loginPublico;
          if (!loginPublico.ppa) {
            this.error.error.message =
              'Não foi encontrado um plano plurianual para o ano corrente, entre em contato com o Administrador do sistema!';
            sessionStorage.setItem('login', null);
            sessionStorage.clear();
            return this.error;
          }
        } else if (usuario.sistema === 'protocolo') {
          const loginProtocolo = login as LoginProtocolo;
          await this.loginContabilidade(loginProtocolo, ano);
          login = loginProtocolo;
        } else if (usuario.sistema === 'recursos-humanos') {
          const loginFolha = login as LoginFolha;
          await this.loginFolha(loginFolha, ano);
          login = loginFolha;
          if (!loginFolha.ppa) {
            this.error.error.message =
              'Não foi encontrado um plano plurianual para o ano corrente, entre em contato com o Administrador do sistema!';
            sessionStorage.setItem('login', null);
            sessionStorage.clear();
            return this.error;
          }
        }
        sessionStorage.setItem('login', JSON.stringify(login));
        this.usuarioServico.login = login;
        this.exercicioServico.login = login;
        this.parametroServico.login = login;
        this.ppaServico.login = login;
        this.orgaoServico.login = login;
        this.progressoServico.login = login;
        this.usuarioAutenticado = true;
        if (this.error.error.message !== '') {
          sessionStorage.setItem('login', null);
          sessionStorage.clear();
          return this.error;
        } else {
          this.mostrarMenuEmitter.emit(true);
          this.sistemaEmitter.emit(usuario.sistema);
          this.funcaoServico.navegarPara(usuario.sistema, this.router, login);
        }
      } else {
        this.usuarioAutenticado = false;
        this.mostrarMenuEmitter.emit(false);
        const login = new Login();
        this.sistemaEmitter.emit(await this.getSistema(login, sistema));
        return '';
      }
    } catch (e) {
      return e;
    }
  }

  public async autenticarTransparencia(email: string, senha: string, sistema: Sistemas) {
    try {
      this.error = {
        error: {
          message: ''
        }
      };
      const dados = await this.usuarioServico.autenticar(email, senha, sistema).toPromise();
      if (dados.entidade) {
        this.usuario = dados.entidade;
        let login = new LoginPublico();

        const usuario = new Usuario();
        usuario.id = this.usuario.id;
        usuario.nome = this.usuario.nome;
        usuario.convidado = this.usuario.convidado;
        usuario.sobrenome = this.usuario.sobrenome;
        usuario.cpf = this.usuario.cpf;
        usuario.telefone = this.usuario.telefone;
        usuario.email = this.usuario.email;
        usuario.administrador = this.usuario.administrador;
        usuario.sistema = 'transparencia';
        usuario.setor = this.usuario.setor;
        usuario.unidade = this.usuario.unidade;
        login.usuario = usuario;

        const orgao = new Orgao();
        orgao.id = this.usuario.orgao.id;
        orgao.codigo = this.usuario.orgao.codigo;
        orgao.nome = this.usuario.orgao.nome;
        orgao.cnpj = this.usuario.orgao.cnpj;
        orgao.endereco = this.usuario.orgao.endereco;
        orgao.cep = this.usuario.orgao.cep;
        orgao.bairro = this.usuario.orgao.bairro;
        orgao.especie = this.usuario.orgao.especie;
        orgao.telefone = this.usuario.orgao.telefone;
        orgao.site = this.usuario.orgao.site;
        login.orgao = orgao;

        login.brasao = this.usuario.orgao.brasao ? this.usuario.orgao.brasao.brasao : '';
        login.cidade = this.usuario.orgao.cidade;
        login.token = 'JWT ' + dados.token;
        login.acessos = [];
        login.limite = 20;
        login.versao = environment.versao;
        sessionStorage.setItem('login', JSON.stringify(login));

        const ano = new Date().getFullYear();
        const ex = await this.exercicioServico.obterPorAno(ano, login.cidade.id).toPromise();
        if (!ex.content[0]) {
          this.error.error.message = 'O exercício atual não foi cadastrado, por favor entre em contato com o administrador do sistema!';
          sessionStorage.setItem('login', null);
          sessionStorage.clear();
          return this.error;
        }
        login.exercicio = ex.content[0];
        const loginPublico = login as LoginPublico;
        await this.loginContabilidade(loginPublico, ano);
        login = loginPublico;
        if (!loginPublico.ppa) {
          this.error.error.message =
            'Não foi encontrado um plano plurianual para o ano corrente, entre em contato com o Administrador do sistema!';
          sessionStorage.setItem('login', null);
          sessionStorage.clear();
          return this.error;
        }

        sessionStorage.setItem('login', JSON.stringify(login));
        this.usuarioServico.login = login;
        this.exercicioServico.login = login;
        this.parametroServico.login = login;
        this.ppaServico.login = login;
        this.orgaoServico.login = login;
        this.progressoServico.login = login;
        this.usuarioAutenticado = true;
        if (this.error.error.message !== '') {
          sessionStorage.setItem('login', null);
          sessionStorage.clear();
          return this.error;
        } else {
          this.mostrarMenuEmitter.emit(true);
          this.sistemaEmitter.emit(usuario.sistema);
          this.router.navigate(['/transparencia/parametros-transparencia']);
        }
      }
    } catch (e) {
      return e;
    }
  }

  async getSistema(login: Login, sistemaLogin: string) {
    switch (sistemaLogin) {
      case 'controle-interno':
      case 'contabilidade':
      case 'compras':
      case 'terceiro-setor':
      case 'diario-oficial':
      case 'indicador-gestao':
      case 'legislativo':
        if (login instanceof LoginContabil) {
          return sistemaLogin as Sistemas;
        } else {
          return null;
        }
      default:
        return sistemaLogin as Sistemas;

    }
  }

  async loginContabilidade(loginContabil: LoginContabil, ano: number) {
    const ppa = await this.ppaServico.obterPorAno(ano, loginContabil.cidade.id).toPromise();
    if (!ppa) {
      this.usuarioAutenticado = false;
      this.mostrarMenuEmitter.emit(false);
      loginContabil = null;
      return null;
    } else {
      loginContabil.ppa = ppa;
      const parametro = await this.parametroServico.obter({
        'orgao.id': this.usuario.orgao.id
      }, loginContabil.cidade.id).toPromise();
      loginContabil.redirecionar_liquidar_pagar = parametro ? parametro.redirecionar_liquidar_pagar : false;
      loginContabil.dias_bloquear_alteracoes = parametro ? parametro.dias_bloquear_alteracoes : 1;
      loginContabil.repetir_dados_empenho = parametro ? parametro.repetir_dados_empenho : false;
      return loginContabil;
    }
  }

  async loginPublico(loginPublico: LoginPublico, ano: number) {
    const ppa = await this.ppaServico.obterPorAno(ano, loginPublico.cidade.id).toPromise();
    if (!ppa) {
      this.usuarioAutenticado = false;
      this.mostrarMenuEmitter.emit(false);
      loginPublico = null;
      return null;
    } else {
      loginPublico.ppa = ppa;
      return loginPublico;
    }
  }

  async loginFolha(loginFolha: LoginFolha, ano: number) {
    const ppa = await this.ppaServico.obterPorAno(ano, loginFolha.cidade.id).toPromise();
    if (!ppa) {
      this.usuarioAutenticado = false;
      this.mostrarMenuEmitter.emit(false);
      loginFolha = null;
      return null;
    } else {
      loginFolha.ppa = ppa;
      return loginFolha;
    }
  }

  async loginEntidade(loginEntidade: LoginEntidade, cnpj: string) {
    loginEntidade.favorecido = this.usuario.favorecido;

    if (!loginEntidade.favorecido) {
      this.usuarioAutenticado = false;
      this.mostrarMenuEmitter.emit(false);
      this.error.error.message = 'Para acessar o sistema você tem que se cadastrar se vinculando a uma entidade.';
      sessionStorage.setItem('login', null);
      sessionStorage.clear();
      return this.error;
    }

    if (loginEntidade.favorecido && loginEntidade.favorecido.cpf_cnpj !== cnpj) {
      this.usuarioAutenticado = false;
      this.mostrarMenuEmitter.emit(false);
      this.error.error.message = `Você não esta cadastrado na entidade ${cnpj}, tente novamente! `;
      sessionStorage.setItem('login', null);
      sessionStorage.clear();
      return this.error;
    }

    return null;

  }

  async recuperarSenha(email: string) {
    try {
      const res = await this.usuarioServico.recuperarSenha(email).toPromise();
    } catch (e) {
      return e;
    }
  }

  usuarioEstaAutenticado() {
    if (!this.usuarioAutenticado) {
      if (sessionStorage.getItem('login')) {
        const log = JSON.parse(sessionStorage.getItem('login'));
        this.usuarioAutenticado = true;
        this.mostrarMenuEmitter.emit(true);
        this.sistemaEmitter.emit(log.usuario.sistema);
      }
    }
    return this.usuarioAutenticado ? JSON.parse(sessionStorage.getItem('login')) : null;
  }

  async usuarioEstaAutenticadoFake(): Promise<boolean> {
    // recupera login pela sessao
    let login: LoginPublico = JSON.parse(sessionStorage.getItem('login'));

    // se nao possui login gera um login publico
    if (!login) {
      login = new LoginPublico();

      const dados = await this.usuarioServico.gerarTokenPublico().toPromise();
      login.token = 'JWT ' + dados.token;
      login.acessos = [];

      login.versao = environment.versao;
      login.limite = 25;
      login.contraste = false;

      sessionStorage.setItem('login', JSON.stringify(login));

      const orgao: Orgao = await (await this.orgaoServico.obterPorCodigo(environment.orgao, environment.cidade).toPromise()).content;
      const ano = new Date().getFullYear();
      const ex = await this.exercicioServico.obterPorAno(ano, environment.cidade).toPromise();
      const ppa = await this.ppaServico.obterPorAno(ano, environment.cidade).toPromise();

      login.orgao = orgao;
      login.cidade = orgao.cidade;
      login.exercicio = ex.content[0];
      login.ppa = ppa;
    }

    // se perdeu o token ou não possui gera um novo token publico
    if (!login.token) {
      const dados = await this.usuarioServico.gerarTokenPublico().toPromise();
      login.token = 'JWT ' + dados.token;
      login.acessos = [];
    }

    // armazena login na sessao
    login.usuario.sistema = 'transparencia';
    sessionStorage.setItem('login', JSON.stringify(login));

    // configura sistema para TRANSPARENCIA
    this.mostrarMenuEmitter.emit(true);
    this.sistemaEmitter.emit(login.usuario.sistema);
    this.usuarioAutenticado = false;
    return true;
  }

  desconectar(usuario: Usuario) {
    const login: Login = JSON.parse(sessionStorage.getItem('login'));
    this.usuarioAcessoServico.salvarLogoff(usuario, login.sistema).pipe(takeUntil(this.unsubscribe))
      .subscribe(() => {
        this.usuarioAutenticado = false;
        this.mostrarMenuEmitter.emit(false);
        this.sistemaEmitter.emit('transparencia');
        sessionStorage.setItem('login', null);
        sessionStorage.clear();
        if (login.sistema === 'e-sic') {
          this.router.navigate(['/e-sic/login']);
        } else {
          if (login && login.usuario.sistema === 'protocolo-cidadao') {
            this.router.navigate(['/protocolo/login-cidadao']);
          } else if (login && login.usuario.sistema === 'portal-entidade') {
            this.router.navigate(['/login-entidade']);
          } else {
            this.router.navigate(['/login']);
          }
        }
      });
  }

  desconectarRegistrar(usuario: Usuario) {

    const login: Login = JSON.parse(sessionStorage.getItem('login'));
    this.usuarioAcessoServico.salvarLogoff(usuario, login.sistema).pipe(takeUntil(this.unsubscribe))
      .subscribe(() => {
        this.usuarioAutenticado = false;
        this.mostrarMenuEmitter.emit(false);
        this.sistemaEmitter.emit('transparencia');
        sessionStorage.setItem('login', null);
        sessionStorage.clear();
        this.router.navigate(['/registro']);

      });
  }

}
