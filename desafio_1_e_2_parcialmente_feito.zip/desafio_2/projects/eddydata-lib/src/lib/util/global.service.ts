import { Injectable } from '@angular/core';
import { Sistemas, EspecieAlmoxarifado } from '../../public-api';

declare function atualizarMascarasData(): any;
declare function convertEnterParaTab(): any;

@Injectable({
  providedIn: 'root'
})
export class GlobalService {

  public calendarMascara() {
    atualizarMascarasData();
  }

  public convertEnterParaTab() {
    convertEnterParaTab();
  }

  public obterMes(mes: number, abreviado?: boolean): string {
    switch (mes) {
      case 1: {
        return abreviado ? 'JAN' : 'JANEIRO';
      }
      case 2: {
        return abreviado ? 'FEV' : 'FEVEREIRO';
      }
      case 3: {
        return abreviado ? 'MAR' : 'MARÇO';
      }
      case 4: {
        return abreviado ? 'ABR' : 'ABRIL';
      }
      case 5: {
        return abreviado ? 'MAI' : 'MAIO';
      }
      case 6: {
        return abreviado ? 'JUN' : 'JUNHO';
      }
      case 7: {
        return abreviado ? 'JUL' : 'JULHO';
      }
      case 8: {
        return abreviado ? 'AGO' : 'AGOSTO';
      }
      case 9: {
        return abreviado ? 'SET' : 'SETEMBRO';
      }
      case 10: {
        return abreviado ? 'OUT' : 'OUTUBRO';
      }
      case 11: {
        return abreviado ? 'NOV' : 'NOVEMBRO';
      }
      case 12: {
        return abreviado ? 'DEZ' : 'DEZEMBRO';
      }
      default: {
        return String(mes);
      }
    }
  }

  public obterListaMeses() {
    return [
      { id: '1', nome: 'JANEIRO' },
      { id: '2', nome: 'FEVEREIRO' },
      { id: '3', nome: 'MARÇO' },
      { id: '4', nome: 'ABRIL' },
      { id: '5', nome: 'MAIO' },
      { id: '6', nome: 'JUNHO' },
      { id: '7', nome: 'JULHO' },
      { id: '8', nome: 'AGOSTO' },
      { id: '9', nome: 'SETEMBRO' },
      { id: '10', nome: 'OUTUBRO' },
      { id: '11', nome: 'NOVEMBRO' },
      { id: '12', nome: 'DEZEMBRO' }
    ];
  }

  public obterDataBR() {
    // atualizarMascarasData();
    const ptBR = {
      firstDayOfWeek: 0,
      dayNames: ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'],
      dayNamesShort: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'],
      dayNamesMin: ['Do', 'Se', 'Te', 'Qu', 'Qu', 'Se', 'Sa'],
      monthNames: [
        'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
        'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
      ],
      monthNamesShort: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
      today: 'Hoje',
      clear: 'Limpar'
    };

    return ptBR;
  }

  public obterAvaliacoes() {
    return [
      { id: '1', nome: 'EMPENHOS' },
      { id: '2', nome: 'CONTRATOS' },
      { id: '3', nome: 'LICITAÇÕES' },
      { id: '4', nome: 'PATRIMÔNIO' },
      { id: '5', nome: 'ADIANTAMENTOS' },
      { id: '20', nome: 'AUDIÊNCIA PÚBLICA' },
      { id: '21', nome: 'LEI DE DIRETRIZES ORÇAMENTÁRIAS' },
      { id: '22', nome: 'ANEXO DE METAS FISCAIS' },
      { id: '23', nome: 'DISPONIBILIZAÇÃO DOS ESTUDOS E ESTIMATIVAS DA RECEITA' },
      { id: '24', nome: 'CRONOGRAMA MENSAL DE DESEMBOLSOS' },
      { id: '25', nome: 'METAS BIMESTRAIS DE ARRECADAÇÃO' },
      { id: '26', nome: 'ANEXO DE RISCOS FISCAIS' },
      { id: '27', nome: 'LIMITAÇÃO DE EMPENHO E MOVIMENTAÇÃO FINANCEIRA' },
      { id: '28', nome: 'OPERAÇÕES DE CRÉDITO' },
      { id: '29', nome: 'DÍVIDA CONSOLIDADA LÍQUIDA' },
      { id: '30', nome: 'APLICAÇÃO DA RECEITA DE ALIENAÇÃO DE BENS' },
      { id: '31', nome: 'CONSOLIDAÇÃO DAS CONTAS' },
      { id: '32', nome: 'UTILIZAÇÃO DOS RECURSOS VINCULADOS' },
      { id: '33', nome: 'IDENTIFICAÇÃO DE BENEFICIÁRIOS DE PAGAMENTOS DE SENTENÇAS JUDICIAIS' },
      { id: '34', nome: 'RENÚNICA DE RECEITA' },
      { id: '35', nome: 'PUBLICAÇÃO DO RELATÓRIO RESUMIDO DA EXECUÇÃO ORÇAMENTÁRIA – RREO' },
      { id: '36', nome: 'PUBLICAÇÃO DO RELATÓRIO DE GESTÃO FISCAL – RGF' },
      { id: '37', nome: 'DESPESAS COM PESSOAL' },
      { id: '38', nome: 'INSTITUIÇÃO, PREVISÃO E EFETIVA ARRECADAÇÃO DE TRIBUTOS' }
    ];
  }

  public obterSituacao(idx: string) {
    switch (idx) {
      case '1':
        return 'AGUARDANDO';
      case '2':
        return 'ANDAMENTO';
      case '3':
        return 'FINALIZADO';
      case '4':
        return 'CANCELADO';
      case '99':
        return 'CANCELADO';
      default:
        return '-';
    }
  }

  public obterTipo(idx: number) {
    switch (idx) {
      case 1:
        return 'ADIANTAMENTO';
      case 2:
        return 'CONTRATO';
      case 3:
        return 'LICITAÇÃO';
      case 4:
        return 'PATRIMÔNIO';
      case 5:
        return 'PROTOCOLO';
      case 99:
        return 'OUTROS';
      default:
        return '-';
    }
  }

  public obterContratacao(idx: string) {
    switch (idx) {
      case '1':
        return 'FORNECIMENTO DE MATERIAL';
      case '2':
        return 'FORNECIMENTO DE SERVIÇOS';
      case '3':
        return 'OBRAS';
      case '4':
        return 'LOCAÇÃO';
      case '5':
        return 'SERVIÇOS DE UTILIDADE PÚBLICA';
      case '6':
        return 'CONTRATO DE GESTÃO';
      case '7':
        return 'TERMO DE PARCERIA';
      case '8':
        return 'PARCERIA PÚBLICO PRIVADA';
      case '9':
        return 'OPERAÇÕES DE CRÉDITO';
      case '10':
        return 'CONSÓRCIOS';
      case '11':
        return 'PERMISSÃO/CONCESSÃO';
      case '12':
        return 'PERMISSÃO';
      case '13':
        return 'CONTRATAÇÃO DE MATERIAIS E SERVIÇOS';
      case '95':
        return 'FORNECIMENTO DE SERVIÇOS TERCEIRIZADOS';
      case '96':
        return 'OUTROS - SEGUROS';
      case '97':
        return 'OUTROS - PARCELAMENTOS';
      case '98':
        return 'OUTROS - EMPRÉSTIMOS';
      case '99':
        return 'OUTROS';
      default:
        return idx;
    }
  }

  public obterEspecie(idx: string) {
    switch (idx) {
      case 'ABE':
        return 'ABERTURA DE EXERCICIOS - ABE';
      case 'ALG':
        return 'ALIENAÇÃO DE BENS - GANHO - ALG';
      case 'ALP':
        return 'ALIENAÇÃO DE BENS - PERDA - ALP';
      case 'EOA':
        return 'ANULAÇÃO DE EMPENHOS ORÇAMENTÁRIOS - EOA';
      case 'ADI':
        return 'ADIANTAMENTOS - ADI';
      case 'ADD':
        return 'ADIANTAMENTOS DEVOLVIDOS - ADD';
      case 'AAD':
        return 'ADIANTAMENTOS APROPRIAÇÃO DE DESPESA - AAD';
      case 'ADU':
        return 'ADIANTAMENTOS UTILIZADOS - ADU';
      case 'RPE':
        return 'APLICAÇÃO EDUCAÇÃO - RPE';
      case 'ADA':
        return 'ARRECADAÇÃO DIVIDA ATIVA TRIBUTARIAS - CONCOMITANTE - ADA';
      case 'ADN':
        return 'ARRECADAÇÃO DIVIDA ATIVA NAO TRIBUTARIAS - CONCOMITANTE - ADN';
      case 'ACC':
        return 'AUXÍLIO, SUBVENÇÃO E CONTRIBUIÇÃO CONCESSÃO ASS. C - ACC';
      case 'ASC':
        return 'AUXÍLIO, SUBVENÇÃO E CONTRIBUIÇÃO RECEBIDO ASS. C - ASC';
      case 'CAA':
        return 'CONTRATO ASSINATURA ALUGUEL - CAA';
      case 'CTA':
        return 'CONTRATOS DE ALUGUÉIS - CTA';
      case 'CAE':
        return 'CONTRATO ASSINATURA EMPRESTIMOS CONCEDIDOS - CAE';
      case 'CTE':
        return 'CONTRATOS EMPRESTIMOS CONCEDIDOS - CTE';
      case 'CTV':
        return 'CONTRATOS DE CONVENIOS - CTV';
      case 'CAB':
        return 'CONTRATO ASSINATURA DE BENS - CAB';
      case 'CTB':
        return 'CONTRATOS DE FORNECIMENTO DE BENS - CTB';
      case 'CAG':
        return 'CONTRATO ASSINATURA GESTÃO - CAG';
      case 'CAS':
        return 'CONTRATO ASSINATURA SERVIÇO - CAS';
      case 'CAM':
        return 'CONTRATOS ASSINATURA SERVIÇOS E MATERIAIS - CAM';
      case 'CTS':
        return 'CONTRATOS DE FORNECIMENTO DE SERVIÇOS - CTS';
      case 'CAP':
        return 'CONTRATO ASSINATURA PARCELAMENTO - CAP';
      case 'CTP':
        return 'CONTRATOS DE PARCELAMENTOS - CTP';
      case 'CSS':
        return 'CONTRATOS DE SEGUROS - CSS';
      case 'CSM':
        return 'CONTRATOS DE SERVIÇOS E MATERIAIS - CSM';
      case 'COS':
        return 'CONSIGNAÇÃO RETENÇÃO - CONCOMITANTE PGTO EXTRA - COS';
      case 'COV':
        return 'CONVENIOS AUXILIOS E SUBVENCOES - COV';
      case 'CRE':
        return 'CRÉDITOS ADICIONAIS - CRE';
      case 'CR1':
        return 'CRÉDITOS ADICIONAIS - CR1';
      case 'CR2':
        return 'CRÉDITOS ADICIONAIS - CR2';
      case 'CR3':
        return 'CRÉDITOS ADICIONAIS - CR3';
      case 'CR4':
        return 'CRÉDITOS ADICIONAIS - CR4';
      case 'CR5':
        return 'CRÉDITOS ADICIONAIS - CR5';
      case 'CR6':
        return 'CRÉDITOS ADICIONAIS - CR6';
      case 'CR7':
        return 'CRÉDITOS ADICIONAIS - CR7';
      case 'CR8':
        return 'CRÉDITOS ADICIONAIS - CR8';
      case 'DDC':
        return 'DEVOLUÇÃO DEPÓSITOS E CAUÇÕES - DDC';
      case 'DRP':
        return 'DEVOLUÇÃO DE RECURSOS PREFEITURA - DRP';
      case 'DRC':
        return 'DEVOLUÇÃO DE RECURSOS CAMARA - DRC';
      case 'ELO':
        return 'EM LIQUIDAÇÃO ORÇAMENTÁRIA - ELO';
      case 'ELR':
        return 'EM LIQUIDAÇÃO RESTOS - ELR';
      case 'EMP':
        return 'EMPENHOS COM PRÉ-EMPENHO - EMP';
      case 'EPA':
        return 'EMPENHOS COM PRÉ-EMPENHO - ANULAÇÃO - EPA';
      case 'EMO':
        return 'EMPENHOS ORÇAMENTÁRIOS - EMO';
      case 'ESP':
        return 'EMPENHOS REFORÇO - SEM PRÉ-EMPENHO - ESP';
      case 'ECP':
        return 'EMPENHOS REFORÇO - COM PRÉ-EMPENHO - ECP';
      case 'ERD':
        return 'EMPENHOS RESERVA DE DOTAÇÃO - ERD';
      case 'CRA':
        return 'EXCESSO DE ARRECADAÇÃO - ANULAÇÃO - CRA';
      case 'FOD':
        return 'FIXAÇÃO ORÇAMENTARIA DA DESPESA - FOD';
      case 'INC':
        return 'INCORPORAÇÃO DE OBRAS E INSTALAÇÕES - INC';
      case 'LEO':
        return 'LIQUIDAÇÃO ORÇAMENTÁRIA - LEO';
      case 'PLO':
        return 'LIQUIDAÇÃO DE PRÉ LIQUIDAÇÃO - PLO';
      case 'PLR':
        return 'LIQUIDAÇÃO DE PRÉ LIQUIDAÇÃO DE RESTO - PLR';
      case 'LRP':
        return 'LIQUIDAÇÃO DE RESTOS A PAGAR - PROCESSADOS - LRP';
      case 'LRN':
        return 'LIQUIDAÇÃO DE RESTOS A PAGAR - NÃO PROCESSADOS - LRN';
      case 'CAO':
        return 'CONTRATO ASSINATURA OUTRO TERCEIRO - CAO';
      case 'CTO':
        return 'OUTROS CONTRATOS COM TERCEIROS - CTO';
      case 'COR':
        return 'OUTROS CONVENIOS RECEBIDOS - REMUNERAÇÃO DE APLICAÇÃO - COR';
      case 'SAR':
        return 'OUTROS AUXILIOS, SUBVENÇÕES, CONTRIBUIÇÕES RECEBIDOS - REMUNERAÇÃO - SAR';
      case 'COC':
        return 'OUTROS CONVÊNIOS CONCEDIDOS - COC';
      case 'OCC':
        return 'OUTROS CONVÊNIOS CONCEDIDOS ASS. C - OCC';
      case 'OCR':
        return 'OUTROS CONVÊNIOS RECEBIDO ASS. C - OCR';
      case 'PGO':
        return 'PAGAMENTOS ORÇAMENTÁRIOS - PGO';
      case 'PEE':
        return 'PAGAMENTOS EXTRA ORÇAMENTÁRIOS - PEE';
      case 'PGE':
        return 'PAGAMENTOS EXTRA ORÇAMENTÁRIOS - RETENÇÕES - PGE';
      case 'TDE':
        return 'PAGAMENTOS EXTRA ORÇAMENTÁRIOS SEM ORIGEM TRANSF DISP. EXTRA - TDE';
      case 'PGR':
        return 'PAGAMENTOS DE RESTOS A PAGAR - PGR';
      case 'PRN':
        return 'PAGAMENTO DE RESTOS A PAGAR NÃO PROCESSADOS - CONCOMITANTE - PRN';
      case 'PRP':
        return 'PAGAMENTO DE RESTOS A PAGAR PROCESSADOS  - CONCOMITANTE - PRP';
      case 'PDL':
        return 'PARCELAMENTO DE DIVIDA - BAIXA - PDL';
      case 'PAD':
        return 'PREVISÃO ADICIONAL DA DESPESA - PAD';
      case 'PED':
        return 'PREVISÃO REDUTORA DA DESPESA - PED';
      case 'PAR':
        return 'PREVISÃO ADICIONAL DA RECEITA - PAR';
      case 'PIR':
        return 'PREVISÃO INICIAL DA RECEITA - PIR';
      case 'PRR':
        return 'PREVISÃO INICIAL REDUTORES DA RECEITA - PRR';
      case 'RRP':
        return 'PREVISÃO INICIAL RENUNCIA DE RECEITA - RRP';
      case 'PRS':
        return 'PREVISÃO INICIAL RESTITUIÇÃO DE RECEITA - PRS';
      case 'PTC':
        return 'PREVISÃO TRANSFERENCIAS A CONCEDER - PTC';
      case 'PTR':
        return 'PREVISÃO TRANSFERENCIAS A RECEBER - PTR';
      case 'PCA':
        return 'PREVISÃO TRANSFERENCIAS CONCEDIDA ADICIONAL - PCA';
      case 'PCE':
        return 'PREVISÃO TRANSFERENCIAS CONCEDIDA REDUÇÃO - PCE';
      case 'PRA':
        return 'PREVISÃO TRANSFERENCIAS RECEBER ADICIONAL - PRA';
      case 'PRE':
        return 'PREVISÃO TRANSFERENCIAS RECEBER REDUÇÃO - PRE';
      case 'QCE':
        return 'QUITAÇÃO DE CONVENIO - RECEBIDOS QCE';
      case 'QCO':
        return 'QUITAÇÃO DE CONVENIO - CONCEDIDOS - QCO';
      case 'QEA':
        return 'QUITAÇÃO DE CONVENIO - AUXILIOS QEA';
      case 'QCR':
        return 'QUITAÇÃO DE CONVENIO - RECEBIMENTOS - QCR';
      case 'QDA':
        return 'QUADRO DETALHAMENTO DESPESA - ACRÉSCIMO - QDA';
      case 'QDD':
        return 'QUADRO DETALHAMENTO DESPESA - DECRÉSCIMOS - QDD';
      case 'QCC':
        return 'QUITAÇÃO DE CONVENIO - CONCESSÃO - QCC';
      case 'REE':
        return 'RECEITAS EXTRA ORÇAMENTÁRIAS - REE';
      case 'REA':
        return 'RECEITAS EXTRA ORÇAMENTÁRIAS ANULADAS DE RETENÇÕES - REA';
      case 'REO':
        return 'RECEITAS ORÇAMENTÁRIAS - REO';
      case 'ROC':
        return 'RECEITAS ORÇAMENTÁRIAS - RECOLHIDA POR COMPETÊNCIA - ROC';
      case 'ROR':
        return 'RECEITAS ORÇAMENTÁRIAS - REDUTORES - ROR';
      case 'RES':
        return 'RECEITAS ORÇAMENTÁRIAS - RESTITUIÇÃO - RES';
      case 'CON':
        return 'RECEBIMENTO DE CONVENIOS - CON';
      case 'ASR':
        return 'RECEBIMENTO DE AUXÍLIO SUBVENÇÃO CONTRIBUIÇÃO - ASR';
      case 'RDO':
        return 'RESERVA DE DOTAÇÃO ORÇAMENTÁRIA - RDO';
      case 'RDA':
        return 'RESERVA DE DOTAÇÃO ORÇAMENTÁRIA ANULA- RDA';
      case 'RED':
        return 'RETENÇÕES - CONCOMITANTE AO PAGAMENTO - RED';
      case 'RET':
        return 'RETENÇÕES - LIQUIDAÇÃO - RET';
      case 'RED':
        return 'RETENÇÕES - CONCOMITANTE AO PAGAMENTO - RED';
      case 'RER':
        return 'RETENÇÕES - LIQUIDAÇÃO RESTOS - RER';
      case 'ROE':
        return 'RETENÇÕES ORÇAMENTÁRIAS EM EMPENHOS EXTRA - ROE';
      case 'REP':
        return 'RETENÇÕES - PAGAMENTO - REP';
      case 'RTD':
        return 'RECEITA TRANSFERÊNCIA DUODÉCIMO - RTD';
      case 'RDD':
        return 'RECEITA TRANSFERÊNCIA DEVOLUCAO DUODÉCIMO - RDD';
      case 'TRS':
        return 'TRANSFERENCIA DE SALDO BANCARIO - TRS';
      case 'TDP':
        return 'TRANSFERENCIA DUODÉCIMO PREFEITURA - TDP';
      case 'TDC':
        return 'TRANSFERENCIA DUODÉCIMO CÂMARA - TDC';
      case 'TRF':
        return 'TRANSFERENCIA FINANCEIRA - TRF';
      case 'TIP':
        return 'TRANSFERENCIA - INTERVENIÊNCIA PASSIVA - TIP';
      case 'TIA':
        return 'TRANSFERENCIA - INTERVENIÊNCIA ATIVA - TIA';
      case 'TPP':
        return 'TPP';
      case 'TPI':
        return 'TPI';
      case 'TRP':
        return 'TRP';
      case 'TRI':
        return 'TRI';
      case 'TRE':
        return 'TRANSFERENCIA DECENDIAL EDUCACAO - TRE';
      case 'TRR':
        return 'TRANSFERÊNCIA BANCÁRIA - RECURSOS - TRR';
      case 'VAR':
        return 'VARIAÇÃO PATRIMONIAL - VAR';
      case 'QCS':
        return 'QUITAÇÃO SUBVENÇÃO - CONCEDIDO - QCS';
      case 'APC':
        return 'CONTRATOS ASSINATURA PERMISSÃO E CONCESSÃO - APC';
      case 'CAC':
        return 'CONTRATOS DE CONSÓRCIOS - CAC';
      default:
        return idx;
    }
  }

  public obterEspecieMeta(idx: string) {
    switch (idx) {
      case 'I':
        return 'INICIAL';
      case 'A':
        return 'ALTERAÇÃO';
      case 'E':
        return 'EXCLUSÃO';
    }
    return '-';
  }

  public obterPrioridade(idx: string) {
    switch (idx) {
      case 'B':
        return 'BAIXA';
      case 'N':
        return 'NORMAL';
      case 'A':
        return 'ALTA';
      case 'U':
        return 'URGENTE';
      default:
        return '-';
    }
  }

  public obterSituacaoPatrimonio(idx: string) {
    switch (idx) {
      case 'B':
        return 'BAIXADO';
      case 'E':
        return 'EXCLUÍDO';
      case 'A':
        return 'NORMAL';
      default:
        return '-';
    }
  }

  public listaSituacaoPatrimonio() {
    return [
      { id: 'B', nome: 'BAIXADO' },
      { id: 'E', nome: 'EXCLUÍDO' },
      { id: 'A', nome: 'NORMAL' },
    ];
  }
  public obterConservacaoPatrimonio(idx: string) {
    switch (idx) {
      case '1':
        return 'ÓTIMO';
      case '2':
        return 'BOM';
      case '3':
        return 'REGULAR';
      case '4':
        return 'RUIM';
      case '5':
        return 'INSERVÍVEL';
      default:
        return '-';
    }
  }

  public listaConservacaoPatrimonio() {
    return [
      { id: '1', nome: 'ÓTIMO' },
      { id: '2', nome: 'BOM' },
      { id: '3', nome: 'REGULAR' },
      { id: '4', nome: 'RUIM' },
      { id: '5', nome: 'INSERVÍVEL' }
    ];
  }

  public listaEstados(): Array<any> {
    return [
      { codigo_ibge: 12, uf: 'AC', nome: 'Acre' },
      { codigo_ibge: 27, uf: 'AL', nome: 'Alagoas' },
      { codigo_ibge: 13, uf: 'AM', nome: 'Amazonas' },
      { codigo_ibge: 16, uf: 'AP', nome: 'Amapá' },
      { codigo_ibge: 29, uf: 'BA', nome: 'Bahia' },
      { codigo_ibge: 23, uf: 'CE', nome: 'Ceará' },
      { codigo_ibge: 53, uf: 'DF', nome: 'Distrito Federal' },
      { codigo_ibge: 32, uf: 'ES', nome: 'Espírito Santo' },
      { codigo_ibge: 52, uf: 'GO', nome: 'Goiás' },
      { codigo_ibge: 21, uf: 'MA', nome: 'Maranhão' },
      { codigo_ibge: 31, uf: 'MG', nome: 'Minas Gerais' },
      { codigo_ibge: 50, uf: 'MS', nome: 'Mato Grosso do Sul' },
      { codigo_ibge: 51, uf: 'MT', nome: 'Mato Grosso' },
      { codigo_ibge: 15, uf: 'PA', nome: 'Pará' },
      { codigo_ibge: 25, uf: 'PB', nome: 'Paraíba' },
      { codigo_ibge: 26, uf: 'PE', nome: 'Pernambuco' },
      { codigo_ibge: 22, uf: 'PI', nome: 'Piauí' },
      { codigo_ibge: 41, uf: 'PR', nome: 'Paraná' },
      { codigo_ibge: 33, uf: 'RJ', nome: 'Rio de Janeiro' },
      { codigo_ibge: 24, uf: 'RN', nome: 'Rio Grande do Norte' },
      { codigo_ibge: 11, uf: 'RO', nome: 'Rondônia' },
      { codigo_ibge: 14, uf: 'RR', nome: 'Roraima' },
      { codigo_ibge: 43, uf: 'RS', nome: 'Rio Grande do Sul' },
      { codigo_ibge: 42, uf: 'SC', nome: 'Santa Catarina' },
      { codigo_ibge: 28, uf: 'SE', nome: 'Sergipe' },
      { codigo_ibge: 35, uf: 'SP', nome: 'São Paulo' },
      { codigo_ibge: 17, uf: 'TO', nome: 'Tocantins' }
    ];
  }


  public obterTiposCreditos(idx: string) {
    switch (idx) {
      case '1':
        return 'SUPLEMENTAR';
      case '2':
        return 'ESPECIAL';
      case '3':
        return 'EXTRAORDINÁRIO';
      default:
        return '-';
    }
  }

  public obterTipoEmpenho(idx: string) {
    switch (idx) {
      case 'O':
        return 'ORDINÁRIA';
      case 'E':
        return 'ESTIMATIVA';
      case 'G':
        return 'GLOBAL';
      default:
        return idx;
    }
  }

  public obterListaTiposEmpenhos() {
    return [
      { id: 'O', nome: 'ORDINÁRIA' },
      { id: 'E', nome: 'ESTIMATIVA' },
      { id: 'G', nome: 'GLOBAL' }
    ];
  }

  public obterListaTiposCreditos() {
    return [
      { id: '1', nome: 'SUPLEMENTAR' },
      { id: '2', nome: 'ESPECIAL' },
      { id: '3', nome: 'EXTRAORDINÁRIO' }
    ];
  }

  public obterOcorrenciasCreditos(idx: string) {
    switch (idx) {
      case '1':
        return 'ANULAÇÃO PARCIAL OU TOTAL DE DOTAÇÃO';
      case '2':
        return 'EXCESSO DE ARRECADAÇÃO';
      case '3':
        return 'SUPERÁVIT FINANCEIRO';
      case '4':
        return 'OPERAÇÕES DE CRÉDITO';
      case '5':
        return 'RESERVA DE CONTINGÊNCIA';
      case '6':
        return 'PARAGRAFO 8˚ DO ARTIGO 166 DA CONSTITUIÇÃO FEDERAL';
      case '7':
        return 'REMANEJAMENTO';
      default:
        return '-';
    }
  }

  public obterListaOcorrenciasCreditos() {
    return [
      { id: '1', nome: 'ANULAÇÃO PARCIAL OU TOTAL DE DOTAÇÃO' },
      { id: '2', nome: 'EXCESSO DE ARRECADAÇÃO' },
      { id: '3', nome: 'SUPERÁVIT FINANCEIRO' },
      { id: '4', nome: 'OPERAÇÕES DE CRÉDITO' },
      { id: '5', nome: 'RESERVA DE CONTINGÊNCIA' },
      { id: '6', nome: 'PARAGRAFO 8˚ DO ARTIGO 166 DA CONSTITUIÇÃO FEDERAL' },
      { id: '7', nome: 'REMANEJAMENTO' }
    ];
  }

  public obterListaTiposFichasExtra() {
    return [
      { id: '1', nome: 'RESTOS A PAGAR' },
      { id: '2', nome: 'ANTECIPAÇÃO DE RECEITA' },
      { id: '3', nome: 'CONSIGNAÇÕES' },
      { id: '4', nome: 'RECEITA A CLASSIFICAR' },
      { id: '5', nome: 'CONVÊNIOS' },
      { id: '6', nome: 'TRANSFERÊNCIA DE RECURSOS' }
    ];
  }

  public obterListaContratacao() {
    return [
      { id: '1', nome: 'FORNECIMENTO DE MATERIAL' },
      { id: '2', nome: 'FORNECIMENTO DE SERVIÇOS' },
      { id: '3', nome: 'OBRAS' },
      { id: '4', nome: 'LOCAÇÃO' },
      { id: '5', nome: 'SERVIÇOS DE UTILIDADE PÚBLICA' },
      { id: '6', nome: 'CONTRATO DE GESTÃO' },
      { id: '7', nome: 'TERMO DE PARCERIA' },
      { id: '8', nome: 'PARCERIA PÚBLICO PRIVADA' },
      { id: '9', nome: 'OPERAÇÕES DE CRÉDITO' },
      { id: '10', nome: 'CONSÓRCIOS' },
      { id: '11', nome: 'CONCESSÃO' },
      { id: '12', nome: 'PERMISSÃO' },
      { id: '13', nome: 'FORNECIMENTO MATERIAL E SERVIÇOS' },
      { id: '14', nome: 'OUTROS' },
    ];
  }

  public obterListaTipoContrato() {
    return [
      { id: '1', nome: 'CONCESSÃO' },
      { id: '2', nome: 'PERMISSÃO' },
      { id: '3', nome: 'OUTROS' }
    ];
  }

  public obterLegislacao() {
    return [
      { id: '1', nome: 'LEI FEDERAL' },
      { id: '2', nome: 'LEI ESTADUAL' },
      { id: '3', nome: 'LEI MUNICIPAL' },
      { id: '4', nome: 'DECRETO FEDERAL' },
      { id: '5', nome: 'DECRETO ESTADUAL' },
      { id: '6', nome: 'DECRETO MUNICIPAL' }
    ];
  }

  public obterListaTipoFornecedores() {
    return [
      { id: '1', nome: 'CNPJ - PESSOA JURÍDICA' },
      { id: '2', nome: 'CPF - PESSOA FÍSICA' },
      { id: '3', nome: 'IDENTIFICAÇÃO ESPECIAL' },
      { id: '4', nome: 'INSCRIÇÃO GENÉRICA-RESTOS A PAGAR-EXERCÍCIOS ANTERIORES' },
      { id: '5', nome: 'INSCRIÇÃO GENÉRICA-SENTENÇAS JUDICIAIS-NATUREZA ALIMENTAR' },
      { id: '6', nome: 'INSCRIÇÃO GENÉRICA-SENTENÇAS JUDICIAIS-OUTROS' },
      { id: '7', nome: 'INSCRIÇÃO GENÉRICA-PRECATÓRIOS-NATUREZA ALIMENTAR' },
      { id: '8', nome: 'INSCRIÇÃO GENÉRICA-PRECATÓRIOS-OUTROS' },
      { id: '9', nome: 'INSCRIÇÃO GENÉRICA-OUTROS' }
    ];
  }

  public obterListaEnquadramentoFornecedores() {
    return [
      { id: '1', nome: 'MEI' },
      { id: '2', nome: 'ME' },
      { id: '3', nome: 'EPP' },
      { id: '4', nome: 'EMPRESA NORMAL' },
      { id: '5', nome: 'PESSOA FÍSICA' }
    ];
  }

  public obterListaTipoContasBancarias() {
    return [
      { id: 'M', nome: 'CONTA COMUM/CONTA MOVIMENTO' },
      { id: 'V', nome: 'CONTA VINCULADA' },
      { id: 'A', nome: 'CONTA APLICAÇÃO' },
      { id: 'U', nome: 'CONTA ÚNICA' },
      { id: 'C', nome: 'CAIXA' }
    ];
  }

  public obterListaModalidadeRepasses() {
    return [
      { id: 'C', nome: 'CHAMAMENTO' },
      { id: 'D', nome: 'DISPENSA' },
      { id: 'I', nome: 'INEXIGIBILIDADE' },
    ];
  }

  public obterListaAtoUnidades() {
    return [
      { id: '1', nome: 'LEI' },
      { id: '2', nome: 'DECRETO' },
      { id: '3', nome: 'PORTARIA' },
      { id: '4', nome: 'OUTROS' }
    ];
  }
  public obterListaTiposPpa() {
    return [
      { id: 'I', nome: 'INICIAL' },
      { id: 'A', nome: 'ALTERAÇÃO' },
      { id: 'E', nome: 'EXCLUSÃO' }
    ];
  }

  public obterListaProgramas() {
    return [
      { id: 'I', nome: 'PROGRAMA FINALÍSTICO' },
      { id: 'A', nome: 'PROGRAMA DE APOIO ADMINISTRATIVO' },
      { id: 'E', nome: 'PROGRAMA DE OPERAÇÃO ESPECIAL' }
    ];
  }

  public obterListaTipoLOA() {
    return [
      { id: 'O', nome: 'ORÇAMENTÁRIA' },
      { id: 'S', nome: 'SUPLEMENTAR' },
      { id: 'E', nome: 'EXTRAORDINÁRIA' }
    ];
  }

  public obterListaJulgamentosLicitacao() {
    return [
      { id: '1', nome: 'TÉCNICA E PREÇO' },
      { id: '2', nome: 'MENOR PREÇO' },
      { id: '3', nome: 'MELHOR TÉCNICA OU CONTEÚDO ARTÍSTICO' },
      { id: '4', nome: 'MAIOR LANCE OU OFERTA' },
      { id: '5', nome: 'MAIOR DESCONTO' },
      { id: '6', nome: 'MAIOR OFERTA DE PREÇO' },
      { id: '7', nome: 'MAIOR RETORNO ECONÔMICO' },
      { id: '8', nome: 'MENOR VALOR DA TARIFA DO SERVIÇO PÚBLICO' }
    ];
  }

  public obterListaHomologacaoLicitacao() {
    return [
      { id: '1', nome: 'ADJUDICADA' },
      { id: '2', nome: 'ANULADA' },
      { id: '3', nome: 'DESERTA' },
      { id: '4', nome: 'FRACASSADA' },
      { id: '5', nome: 'HOMOLOGADA PARCIAL' },
      { id: '6', nome: 'HOMOLOGADA' },
      { id: '7', nome: 'HOMOLOGADA REGISTRO DE PREÇO' },
      { id: '8', nome: 'OUTRA' },
      { id: '9', nome: 'REVOGADA' }
    ];
  }

  public obterListaTipoOrgaos() {
    return [
      { id: 'P', nome: 'PREFEITURA MUNICIPAL' },
      { id: 'C', nome: 'CÂMARA MUNICIPAL' },
      { id: 'A', nome: 'AUTARQUIA MUNICIPAL' },
      { id: 'F', nome: 'FUNDAÇÃO MUNICIPAL' },
      { id: 'E', nome: 'EMPRESA MUNICIPAL' },
      { id: 'I', nome: 'INSTITUTO DE PREVIDÊNCIA' }
    ];
  }

  public obterListaSistemas(): { id: Sistemas, nome: string }[] {
    return [
      { id: 'controle-interno', nome: 'CONTROLE-INTERNO' },
      { id: 'planejamento', nome: 'PLANEJAMENTO' },
      { id: 'tesouraria', nome: 'TESOURARIA' },
      { id: 'compras', nome: 'COMPRA' },
      { id: 'contabil', nome: 'CONTABILIDADE' },
      { id: 'patrimonio', nome: 'PATRIMÔNIO' },
      { id: 'recursos-humanos', nome: 'FOLHA' },
      { id: 'protocolo', nome: 'PROTOCOLO' },
      { id: 'almoxarifado', nome: 'ALMOXARIFADO' },
      { id: 'terceiro-setor', nome: 'TERCEIRO SETOR' },
      { id: 'indicador-gestao', nome: 'INDICADOR DE GESTÃO' },
      { id: 'legislativo', nome: 'LEGISLATIVO' },
      { id: 'portal-entidade', nome: 'PORTAL DA ENTIDADE' },
      { id: 'portal-cidadao', nome: 'PORTAL DO CIDADÃO' },
      { id: 'diario-oficial', nome: 'DIÁRIO OFICIAL' },
      { id: 'transparencia', nome: 'PORTAL DA TRANSPARÊNCIA' },
    ];
  }

  public obterListaTiposRepasse() {
    return [
      { id: '1', nome: 'AUXÍLIO-CONCESSÃO' },
      { id: '2', nome: 'SUBVENÇÃO-CONCESSÃO' },
      { id: '3', nome: 'CONTRIBUIÇÃO-CONCESSÃO' },
      { id: '4', nome: 'AUXÍLIO-RECEBIDO' },
      { id: '5', nome: 'SUBVENÇÃO-RECEBIDO' },
      { id: '6', nome: 'CONTRIBUIÇÃO-RECEBIDO' },
      { id: '7', nome: 'TERMO DE COLABORAÇÃO' },
      { id: '8', nome: 'TERMO DE FOMENTO' },
      { id: '9', nome: 'OUTROS' },
      { id: '10', nome: 'ACORDO DE COOPERAÇÃO' },
      { id: '11', nome: 'CONTRATO DE GESTÃO' },
      { id: '90', nome: 'TERMO DE PARCERIA' },
      { id: '91', nome: 'OUTROS CONVÊNICOS RECEBIDOS' },
      { id: '92', nome: 'OUTROS - CONVENIOS CONCEDIDOS' }
    ];
  }

  public obterListaSituacaoChamamento() {
    return [
      { nome: 'ABERTO', id: '1' },
      { nome: 'EM ANDAMENTO', id: '2' },
      { nome: 'FINALIZADO', id: '3' },
      { nome: 'CANCELADO', id: '4' }
    ];
  }

  public obterListaNatureza() {
    return [
      { id: '1', nome: '1 - RECURSOS HUMANOS (5)' },
      { id: '2', nome: '2 - RECURSOS HUMANOS (6)' },
      { id: '3', nome: '3 - MEDICAMENTOS' },
      { id: '5', nome: '5 - MATERIAL MÉDICO E HOSPITALAR (*)' },
      { id: '6', nome: '6 - GÊNEROS ALIMENTÍCIOS' },
      { id: '7', nome: '7 - OUTROS MATERIAIS DE CONSUMO' },
      { id: '8', nome: '8 - SERVIÇOS MÉDICOS' },
      { id: '9', nome: '9 - OUTROS SERVIÇOS DE TERCEIROS' },
      { id: '10', nome: '10 - LOCAÇÃO DE IMÓVEIS' },
      { id: '11', nome: '11 - LOCAÇÃO DIVERSAS' },
      { id: '12', nome: '12 - UTILIDADES PÚBLICAS (7)' },
      { id: '13', nome: '13 - COMBUSTÍVEL' },
      { id: '14', nome: '14 - BENS E MATERIAIS PERMANENTES' },
      { id: '15', nome: '15 - OBRAS' },
      { id: '16', nome: '16 - DESPESAS FINANCEIRAS E BANCÁRIAS' },
      { id: '17', nome: '17 - OUTRAS DESPESAS' },
    ];
  }

  // recursos humanos
  public obterEscolaridade() {
    return [
      { nome: '02- Alfabetização', id: '02- Alfabetização' },
      { nome: '03- Ensino Básico', id: '03- Ensino Básico' },
      { nome: '04- Ensino Básico incompleto', id: '04- Ensino Básico incompleto' },
      { nome: '05- Ensino Médio', id: '05- Ensino Médio' },
      { nome: '06- Ensino Técnico', id: '06- Ensino Técnico' },
      { nome: '07- Ensino Superior', id: '07- Ensino Superior' },
      { nome: '08- Especialização', id: '08- Especialização' },
    ];
  }

  public obterAtividade() {
    return [
      { nome: '1- Efetivo', id: '1- Efetivo' },
      { nome: '2- Efetivo em Comissão ', id: '2- Efetivo em Comissão' },
      { nome: '3- Temporário', id: '3- Temporário' },
      { nome: '4- Aposentado', id: '4- Aposentado' },
      { nome: '5- Exclusivamente em Comissão', id: '5- Exclusivamente em Comissão' },
      { nome: '7- Eletivo', id: '7- Eletivo' },
      { nome: '8- Outros', id: '8- Outros' },
      { nome: '9- Outros (não Informado)', id: '8- Outros (não Informa)' },
    ];
  }

  public obterRegimeJuridico() {
    return [
      { nome: '1- CLT', id: '1- CLT' },
      { nome: '2- Estatutário', id: '2- Estatutário' }
    ];
  }

  public obterProvimento() {
    return [
      { nome: '1- Concurso Público', id: '1- Concurso Público' },
      { nome: '2- Tempo Determinado', id: '2- Tempo Determinado' },
      { nome: '3- Livre Provimento', id: '3- Livre Provimento' },
      { nome: '4- Eleição', id: '4- Eleição' },
    ];
  }

  public obterNorma() {
    return [
      { nome: '06- Lei', id: '06- Lei' },
      { nome: '07- Lei complementar', id: '07- Lei complementar' }
    ];
  }

  public listaTipoCalculoFolha() {
    return [
      { id: 'V', nome: 'VALOR' },
      { id: 'P', nome: 'PERCENTUAL' },
      { id: 'H', nome: 'HORA' },
      { id: 'D', nome: 'DIA' }
    ];
  }

  public obterEspeciesAlmoxarifado(tipo?: 'E' | 'S'): { id: EspecieAlmoxarifado, nome: string }[] {
    const list: { id: EspecieAlmoxarifado, nome: string }[] = [
      { id: 'C', nome: 'Compra' },
      { id: 'O', nome: 'Doação' },
      { id: 'V', nome: 'Devolução' },
      { id: 'I', nome: 'Inventário' },
      { id: 'B', nome: 'Baixa' },
      { id: 'T', nome: 'Transferência' },
      { id: 'E', nome: 'Estorno' },
    ];

    if (tipo === 'E') {
      list.splice(list.findIndex((itm) => { return itm.id === 'B' }), 1);
    } else if (tipo === 'S') {
      list.splice(list.findIndex((itm) => { return itm.id === 'C' }), 1);
    }
    list.splice(list.findIndex((itm) => { return itm.id === 'T' }), 1); // transferencia não é permitida como opção
    list.splice(list.findIndex((itm) => { return itm.id === 'E' }), 1); // estorno não é permitida como opção

    return list;
  }


  public listarSituacaoDocumentoTerceiroSetor() {
    return [
      { nome: 'N', id: 'NÃO ENVIADO' },
      { nome: 'E', id: 'ENVIADO E AGUARDANDO VALIDAÇÃO' },
      { nome: 'A', id: 'APROVADO' }
    ];
  }

  public obterSituacaoDocumentoTerceiroSetor(idx: string) {
    switch (idx) {
      case 'N':
        return 'NÃO ENVIADO';
      case 'E':
        return 'ENVIADO E AGUARDANDO VALIDAÇÃO';
      case 'A':
        return 'APROVADO';
      case 'R':
        return 'REJEITADO';
      case 'D':
        return 'ADEQUAÇÃO';
    }
    return '-';
  }

  public traduzirSistema(sistema: Sistemas): string {
    switch (sistema) {
      case 'controle-interno':
        return 'Controle Interno';
      case 'diario-oficial':
        return 'Diário Oficial';
      case 'indicador-gestao':
        return 'Indicador de Gestão';
      case 'portal-cidadao':
        return 'Portal do Cidadão';
      case 'portal-entidade':
        return 'Portal da Entidade';
      case 'protocolo-cidadao':
        return 'Protocolo (cidadão)';
      case 'recursos-humanos':
        return 'Recursos Humanos';
      case 'terceiro-setor':
        return 'Terceiro Setor';
      case 'transparencia':
        return 'Transparência Pública';
      case 'site':
        return 'Site Institucional';
      case 'comum':
        return 'Geral';
      default:
        return sistema.replace(/\w\S*/g, (txt: string) => {
          return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        });
    }
  }
}

