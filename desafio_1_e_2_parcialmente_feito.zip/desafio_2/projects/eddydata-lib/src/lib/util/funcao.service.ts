import { DatePipe } from '@angular/common';
import { ElementRef, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Document, Packer, Paragraph, TextRun } from 'docx';
import htmlToPdfMake from 'html-to-pdfmake';
import jwt_decode from 'jwt-decode';
import { MessageService } from 'primeng/api';
import { AutoComplete } from 'primeng/autocomplete';
import { Calendar } from 'primeng/calendar';
import { tsXLXS } from 'ts-xlsx-export';
import X2JS from 'x2js';
import { CpfPipe } from '../components/pipe/cpf.pipe';
import { TelefonePipe } from '../components/pipe/telefone.pipe';
import { Coluna, DIA_TIME, EspecieAlmoxarifado, FormatoExportacao, Sistemas } from '../components/types';
import { Login } from '../entidade/login/login';
import { GlobalService } from './global.service';

@Injectable({
  providedIn: 'root'
})
export class FuncaoService {

  public navegarPara(sistema: Sistemas, router: Router, login?: Login) {
    switch (sistema) {
      case 'transparencia': {
        router.navigate(['/transparencia/parametros-transparencia']);
        break;
      }
      case 'portal-entidade': {
        router.navigate(['/portal-entidade']);
        break;
      }
      case 'site': {
        router.navigate(['/portal-site']);
        break;
      }
      default: {
        router.navigate(['/']);
        break;
      }
    }
  }

  public converteDataBR(dateStr: string | Date) {
    if (typeof dateStr !== 'string') {
      dateStr = dateStr.toISOString();
    }
    if (dateStr.match(/\d{2}\/\d{2}\/\d{4}/)) {
      return dateStr.match(/\d{2}\/\d{2}\/\d{4}/)[0];
    }

    if (dateStr.length > 10) {
      dateStr = dateStr.substring(0, 10);
    }
    var parts = dateStr.split("-");
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  }

  public converteDataHoraBR(dt: string): string {
    try {
      return new Intl.DateTimeFormat('pt-br', {
        year: 'numeric', month: 'numeric', day: 'numeric',
        hour: 'numeric', minute: 'numeric', second: 'numeric',
        hour12: false,
      }).format(new Date(dt));
    } catch (err) {
      return new Intl.DateTimeFormat('pt-br').format(new Date(dt));
    }
  }

  public ultimoDiaMes(mes: number, ano?: number): number {
    switch (mes) {
      case 1:
      case 3:
      case 5:
      case 7:
      case 8:
      case 10:
      case 12:
        return 31;
      case 2:
        ano = ano ? ano : new Date().getFullYear();
        return ano % 4 === 0 ? 29 : 28;
      default:
        return 30;
    }
  }

  public isNumerico(str: any) {
    const er = /^[0-9]+$/;
    return (er.test(str));
  }

  public formatarData(now: Date) {
    const year = '' + now.getFullYear();
    let month = '' + (now.getMonth() + 1); if (month.length === 1) { month = '0' + month; }
    let day = '' + now.getDate(); if (day.length === 1) { day = '0' + day; }
    let hour = '' + now.getHours(); if (hour.length === 1) { hour = '0' + hour; }
    let minute = '' + now.getMinutes(); if (minute.length === 1) { minute = '0' + minute; }
    let second = '' + now.getSeconds(); if (second.length === 1) { second = '0' + second; }
    return year + '-' + month + '-' + day + ' ' + hour + ':' + minute + ':' + second;
  }

  public toInteger(value: any): number {
    return parseInt(`${value}`, 10);
  }

  toString(value: any): string {
    return value !== undefined && value !== null ? `${value}` : '';
  }

  getValueInRange(value: number, max: number, min = 0): number {
    return Math.max(Math.min(value, max), min);
  }

  isString(value: any): value is string {
    return typeof value === 'string';
  }

  isNumber(value: any): value is number {
    if (value.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
      return false;
    } else {
      return !isNaN(+value);
    }
  }

  isInteger(value: any): value is number {
    return (
      typeof value === 'number' &&
      isFinite(value) &&
      Math.floor(value) === value
    );
  }

  isDefined(value: any): boolean {
    return value !== undefined && value !== null;
  }

  padNumber(value: number) {
    if (this.isNumber(value)) {
      return `0${value}`.slice(-2);
    } else {
      return '';
    }
  }

  regExpEscape(text) {
    return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
  }

  hasClassName(element: any, className: string): boolean {
    return (
      element &&
      element.className &&
      element.className.split &&
      element.className.split(/\s+/).indexOf(className) >= 0
    );
  }

  isDate(d) {
    const date = new Date(d);
    let day = '' + date.getDate();
    if (day.length === 1) {
      day = '0' + day;
    }
    let month = '' + (date.getMonth() + 1);
    if (month.length === 1) {
      month = '0' + month;
    }
    const year = '' + date.getFullYear();

    return month + '/' + day + '/' + year === d;
  }

  public toDate(dateStr: any) {
    let dateObject: Date;
    if (dateStr) {
      const dateParts = dateStr.split('/');
      dateObject = new Date(dateParts[2], dateParts[1] - 1, dateParts[0]); // month is 0-based
    }
    return dateObject;
  }

  public diaDaSemana(dia: number): string {
    switch (dia) {
      case 0:
        return 'Domingo';
        break;
      case 1:
        return 'Segunda-feira';
        break;
      case 2:
        return 'Terça-feira';
        break;
      case 3:
        return 'Quarta-feira';
        break;
      case 4:
        return 'Quinta-feira';
        break;
      case 5:
        return 'Sexta-feira';
        break;
      case 6:
        return 'Sábado';
        break;
    }
  }

  converteDataSQL(dateStr: any) {
    if (dateStr) {
      const parts = dateStr.split('/');
      return `${parts[2]}-${parts[1]}-${parts[0]}`;
    } else {
      return dateStr;
    }
  }

  converteValorSQL(valor: number) {
    return Number(valor.toString().replace(/[^0-9.-]+/g, ''));
  }

  public convertArrayOfObjectsToCSV(args: any) {
    let result: string;
    let ctr: number;
    let keys: any;
    let columnDelimiter: string;
    let lineDelimiter: string;
    let data: any;

    data = args.data || null;
    if (data == null || !data.length) {
      return null;
    }

    columnDelimiter = args.columnDelimiter || ',';
    lineDelimiter = args.lineDelimiter || '\n';

    keys = Object.keys(data[0]);

    result = '';
    result += keys.join(columnDelimiter);
    result += lineDelimiter;

    console.log(data)

    data.forEach((item) => {
      ctr = 0;
      keys.forEach((key) => {
        if (ctr > 0) { result += columnDelimiter; }
        result += item[key];
        ctr++;
      });
      result += lineDelimiter;
    });
    return result;
  }

  public downloadCSV(args: any, fileJSON: any) {
    let data: any;
    let filename: any;
    let link: any;
    let csv = this.convertArrayOfObjectsToCSV({
      data: fileJSON
    });
    if (csv == null) { return; }

    filename = args.filename || 'export.csv';

    if (!csv.match(/^data:text\/csv/i)) {
      csv = 'data:text/csv;charset=utf-8,' + csv;
    }

    data = encodeURI(csv);

    link = document.createElement('a');
    link.setAttribute('content', 'text/csv;charset=utf-8');
    link.setAttribute('href', data);
    link.setAttribute('download', filename);
    link.click();
  }

  public mascarar(mascara: string, valor: string) {
    if (!valor) {
      return valor;
    }
    let sb = '';
    let j = 0;
    for (let i = 0; i < mascara.length; i++) {
      if (j >= valor.length) {
        break;
      } else if (mascara.charAt(i) === '0' || mascara.charAt(i) === '#') {
        sb += valor.charAt(j);
        j++;
      } else if (mascara.charAt(i) === '*') {
        sb += valor.substring(j, valor.length);
        return sb;
      } else {
        sb += mascara.charAt(i);
      }
    }
    return sb;
  }

  public capitalizeFirstLetter(texto: string) {
    return texto.replace(/\w\S*/g, (txt: string) => {
      return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
    });
  }

  public strZero(obj: any, tamanho: number): string {
    let sb = '';
    let strValue = this.extrairStr(obj).trim();
    strValue = this.desmascarar('.', strValue);
    let diff = tamanho - strValue.length;
    if (diff < 0) {
      return obj;
    }
    while (diff > 0) {
      sb += '0';
      diff--;
    }
    sb += strValue;

    return sb;
  }

  public desmascarar(mascara: string, valor: string): string {
    if (mascara == null) {
      return valor;
    } else {
      const hm = new Map();
      for (let j = 0; j < mascara.length; j++) {
        if ((mascara.charAt(j) === '0' || mascara.charAt(j) === '#') === false) {
          hm.set(mascara.charAt(j), null);
        }

      }

      let sb = valor;
      for (let j = 0; j < sb.length; j++) {
        if (hm.get(sb.charAt(j))) {
          sb = this.remove_character(sb, j);
          j--;

        }
      }
      return sb;
    }
  }

  private remove_character(str: string, charPos: number) {
    const part1 = str.substring(0, charPos);
    const part2 = str.substring(charPos + 1, str.length);
    return (part1 + part2);
  }

  public extrairStr(val: any): string {
    if (!val) {
      return '';
    } else {
      return String(val);
    }
  }

  public convertToBrNumber(numero: number | string, decimais?: number, negativoParenteses?: boolean): string {
    if (!decimais) {
      decimais = 2;
    }
    if (!numero) {
      if (numero !== 0) {
        numero = 0;
      }
    }
    if (typeof numero === 'string') {
      numero = Number(numero);
    }
    if (negativoParenteses && numero < 0) {
      return '(' + (+numero * -1).toLocaleString('de-DE', { minimumFractionDigits: decimais, maximumFractionDigits: decimais }) + ')';
    } else {
      return numero.toLocaleString('de-DE', { minimumFractionDigits: decimais, maximumFractionDigits: decimais });
    }
  }


  /**
   * Verifica diferença de dias entre data1 (geralmente maior) e data2
   * @param data1 -
   * @param data2 -
   */
  public diferencaEmDias(data1: Date, data2: Date): number {
    if (!data1 || !data2) {
      return 0;
    } else {
      return (data1.getTime() - data2.getTime()) / (1000 * 3600 * 24);
    }
  }

  public adicionarDiasData(dias: number) {
    const hoje = new Date();
    const dataVenc = new Date(hoje.getTime() + (dias * DIA_TIME));
    return dataVenc.getDate() + '/' + (dataVenc.getMonth() + 1) + '/' + dataVenc.getFullYear();
  }

  public agrupar(
    lista: {}[], campo: string | string[],
    totalizadores?: (string | {})[]): { grupo: string | {}, totalizadores: {}, registros: any[] }[] {
    const listaRetorno: { grupo: string | {}, totalizadores: {}, registros: any[] }[] = [];
    let linha: { grupo: string | {}, totalizadores: {}, registros: any[] };
    if (!lista || lista.length === 0) {
      return listaRetorno;
    }
    for (const registro of lista) {
      if (!linha || this.trocarGrupo(campo, linha, registro)) {
        if (linha) {
          listaRetorno.push(linha);
        }
        const totais = {};
        if (totalizadores) {
          for (const totalizador of totalizadores) {
            if (typeof totalizador === 'string') {
              totais[totalizador] = 0.0;
            } else {
              totais[totalizador['nome']] = 0.0;
            }
          }
        }
        if (typeof campo === 'string') {
          linha = { grupo: registro[campo], totalizadores: totais, registros: [] };
        } else {
          const grupo = {};
          for (const chave of campo) {
            grupo[chave] = registro[chave];
          }
          linha = { grupo, totalizadores: totais, registros: [] };
        }
      }
      if (totalizadores) {
        for (const totalizador of totalizadores) {
          if (typeof totalizador === 'string') {
            linha.totalizadores[totalizador] += +registro[totalizador];
          } else {
            linha.totalizadores[totalizador['nome']] += this.processarFuncao(totalizador['funcao'], registro);
          }
        }
      }
      linha.registros.push(registro);
    }
    listaRetorno.push(linha);
    return listaRetorno;
  }

  private trocarGrupo(campo: string | string[], linha: { grupo: string | {}, totalizadores: {}, registros: any[] }, registro: {}): boolean {
    if (typeof campo === 'string') {
      return linha.grupo !== registro[campo];
    } else {
      let diferente = false;
      for (const chave of campo) {
        if (linha.grupo[chave] !== registro[chave]) {
          diferente = true;
        }
      }
      return diferente;
    }
  }

  public totalizar(lista: {}[], totalizadores: (string | {})[]): {} {
    const linha = {};
    for (const totalizador of totalizadores) {
      if (typeof totalizador === 'string') {
        linha[totalizador] = 0.0;
      } else {
        linha[totalizador['nome']] = 0.0;
      }
    }
    for (const registro of lista) {
      for (const totalizador of totalizadores) {
        if (typeof totalizador === 'string') {
          linha[totalizador] += +registro[totalizador];
        } else {
          linha[totalizador['nome']] += this.processarFuncao(totalizador['funcao'], registro);
        }
      }
    }
    return linha;
  }

  retornaValorEntidade(ent: any, coluna: string): string {
    if (!ent || !coluna) {
      return '';
    }
    const retorno: string = ent[coluna];
    try {
      if (coluna.includes('.')) {
        const fields = coluna.split('.');
        for (let i = 0; i < fields.length; i++) {
          ent = ent ? ent[fields[i]] : null;
        }
        return ent ? ent : retorno;
      } else {
        return retorno;
      }
    } catch (e) {
      return retorno;
    }
  }

  /**
   * Formata o valor da célula
   * @param coluna - coluna a ser formatada
   * @param valorColuna - valor da célula
   * @param ent - entidade da linha
   */
  retornaCelula(coluna: Coluna, valorColuna: any, ent: any): string {
    try {
      if (coluna.funcao) {
        const retornoFuncao: number | string = this.processarFuncao(coluna, ent);
        if (typeof retornoFuncao === 'number') {
          coluna.alignment = coluna.alignment ? coluna.alignment : 'right';
          return this.convertToBrNumber(retornoFuncao, 2);
        } else {
          return retornoFuncao;
        }
      } else if (coluna.tipo === 'HTML') {
        return htmlToPdfMake(valorColuna).toString();
      } else if (coluna.decimais) {
        return this.convertToBrNumber(valorColuna, coluna.decimais);
      } else if (typeof valorColuna === 'number') {
        coluna.alignment = coluna.alignment ? coluna.alignment : 'right';
        return valorColuna.toFixed();
      } else if (typeof valorColuna === 'boolean') {
        coluna.alignment = coluna.alignment ? coluna.alignment : 'center';
        return (valorColuna ? 'Sim' : 'Não');
      } else if (valorColuna && valorColuna instanceof Date) {
        coluna.alignment = coluna.alignment ? coluna.alignment : 'center';
        return this.converteDataBR(valorColuna);
      } else if (valorColuna && valorColuna.match(/^\d+(\.\d{1,2})?$/) && valorColuna.match(/^\d+(\.\d{1,2})?$/)[1]) {
        coluna.alignment = coluna.alignment ? coluna.alignment : 'right';
        return this.convertToBrNumber(valorColuna, valorColuna.match(/^\d+(\.\d{1,2})?$/)[1].length - 1);
      } else if (valorColuna && valorColuna.match(/^\d{4}-(\d{2}|\d{1})-(\d{2}|\d{1})$/)) {
        coluna.alignment = coluna.alignment ? coluna.alignment : 'center';
        return this.converteDataBR(valorColuna);
      } else if (valorColuna && valorColuna.match(/^\d{4}-(\d{2}|\d{1})-(\d{2}|\d{1})T\d{2}:\d{2}:\d{2}.\d{3}Z$/)) {
        coluna.alignment = coluna.alignment ? coluna.alignment : 'center';
        let dt = new DatePipe('pt').transform(valorColuna, 'dd/MM/yyyy HH:mm:ss', 'GMT');
        if (dt.endsWith(' 00:00:00')) {
          dt = dt.substring(0, dt.length - ' 00:00:00'.length);
        }
        return dt;
      } else if (coluna.coluna === 'especie') {
        return new GlobalService().obterEspecie(valorColuna);
      } else if (coluna.coluna === 'tipo_empenho') {
        return new GlobalService().obterTipoEmpenho(valorColuna);
      } else if (coluna.coluna === 'situacao') {
        return new GlobalService().obterSituacao(valorColuna);
      } else if (coluna.coluna === 'prioridade') {
        return new GlobalService().obterPrioridade(valorColuna);
      } else if (coluna.coluna === 'ocorrencia') {
        return new GlobalService().obterOcorrenciasCreditos(valorColuna);
      } else if (coluna.coluna.includes('cpf') || coluna.coluna.includes('cnpj')) {
        coluna.alignment = coluna.alignment ? coluna.alignment : 'center';
        return new CpfPipe().transform(valorColuna, []);
      } else if (coluna.coluna.includes('telefone') || coluna.coluna.includes('celular')) {
        return new TelefonePipe().transform(valorColuna, []);
      } else {
        return valorColuna;
      }
    } catch (e) {
      console.log(`Não foi possível converter coluna ${coluna.coluna}, retornando valor padrao (${valorColuna})`, e);
      return valorColuna;
    }
  }

  public processarFuncao(colFuncao: Coluna | any, ent: any): number | string {
    let resultado = 0.0;
    let operador = '+';
    let operadorRecursivo = '+';

    // percorre expressoes da coluna
    const exp: any = (colFuncao.funcao ? colFuncao.funcao : colFuncao);
    for (const expressao of exp) {
      let valorReal: (number | '-' | '+' | '(' | ')' | '*' | '/' | string | {})[];

      if (expressao.valor) { // se usou a expressao 'valor'
        valorReal = expressao.valor;
      } else if (expressao.se) { // se usou a expressao 'se'
        // separa a condicao e o valor em um vetor
        const cond = expressao.se.condicao.split('=');
        // caso tenha operadores especiais separa por $
        const fieldCond = expressao.se.condicao.split('$');
        // verifica se a condicao passada é verdadeira ou falsa
        let testeVerdadeiro = false;
        if (fieldCond.length > 1) {
          switch (fieldCond[1].split('=')[0]) {
            case 'gt':
              testeVerdadeiro = ent[fieldCond[0]] > cond[1];
              break;
            case 'ge':
              testeVerdadeiro = ent[fieldCond[0]] >= cond[1];
              break;
            case 'lt':
              testeVerdadeiro = ent[fieldCond[0]] < cond[1];
              break;
            case 'le':
              testeVerdadeiro = ent[fieldCond[0]] <= cond[1];
              break;
            case 'ne':
              testeVerdadeiro = ent[fieldCond[0]] !== cond[1];
              break;
            default:
              testeVerdadeiro = ent[fieldCond[0]] === cond[1];
              break;
          }
        } else {
          testeVerdadeiro = ent[cond[0]] === cond[1];
        }
        // armazena o valor caso a condicao seja verdadeira ou falsa
        valorReal = testeVerdadeiro ? expressao.se.verdadeiro : expressao.se.falso;
      }

      // percorre o valor para executar a fórmula
      let resultadoRecursivo = -1;
      for (const valor of valorReal) {
        if (valor === '(') {
          resultadoRecursivo = resultado;
          resultado = 0;
          continue;
        }
        if (resultadoRecursivo >= 0 && valor === ')') {
          switch (operadorRecursivo) {
            case '+':
              resultado += resultadoRecursivo;
              break;
            case '-':
              resultado -= resultadoRecursivo;
              break;
            case '*':
              resultado *= resultadoRecursivo;
              break;
            case '/':
              resultado /= resultadoRecursivo;
              break;
          }
          resultadoRecursivo = -1;
          continue;
        }
        // caso o valor contenha apostrofe será considerado um texto e retornará o texto sem apostrofe
        if (String(valor).match(/\'/)) {
          return String(valor).split('\'').join('');
        }

        if (valor[0] && valor[0]['se']) {
          return this.processarFuncao(valor, ent);
        }
        // inicia variavel como number ou boolean para saber se é um operador ou numero
        let numero: number | boolean = false;
        if (typeof valor === 'number') { // se for number armazena o numero explicito
          numero = valor;
        } else if (typeof valor === 'string') {
          if (ent[valor]) { // tenta pegar o valor por nome de coluna ent[<coluna>] para calcular
            numero = +ent[valor];
          } else { // caso contrário armazena o operador
            operador = valor;
            operadorRecursivo = resultadoRecursivo >= 0 ? operadorRecursivo : operador;
          }
        }
        // caso nao seja um operador executa a fórmula de acordo com o operador
        if (typeof numero === 'number') {
          switch (operador) {
            case '+':
              resultado += numero;
              break;
            case '-':
              resultado -= numero;
              break;
            case '*':
              resultado *= numero;
              break;
            case '/':
              resultado /= numero;
              break;
          }
        }
      }
    }
    if (colFuncao.funcao) {
      ent[colFuncao.coluna] = resultado;
    }
    return resultado;
  }

  public removerAcentos(texto: string): string {
    if (!texto) {
      return '';
    }
    return texto.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  }

  public removerPontos(texto: string): string {
    if (!texto) {
      return '';
    }
    return texto
      .split('.').join('')
      .split(',').join('')
      .split(':').join('')
      .split(';').join('')
      .split('/').join('')
      .split('-').join('');
  }

  public obterObjetoPorChave(list: { id: number, nome: string }[], id: number | string): { id: number, nome: string } {
    return list.find((t) => t.id === id);
  }

  public obterNomePorChave(list: { id: EspecieAlmoxarifado, nome: string }[], id: number | string): string {
    const obj: { id: EspecieAlmoxarifado, nome: string } = list.find((t) => t.id === id);
    return obj ? obj.nome : '';
  }

  public formatXml(xml: string) { // tab = optional indent value, default is tab (\t)
    var reg = /(>)\s*(<)(\/*)/g; // updated Mar 30, 2015
    var wsexp = / *(.*) +\n/g;
    var contexp = /(<.+>)(.+\n)/g;
    xml = xml.replace(reg, '$1\n$2$3').replace(wsexp, '$1\n').replace(contexp, '$1\n$2');
    var pad = 0;
    var formatted = '';
    var lines = xml.split('\n');
    var indent = 0;
    var lastType = 'other';
    // 4 types of tags - single, closing, opening, other (text, doctype, comment) - 4*4 = 16 transitions 
    var transitions = {
      'single->single': 0,
      'single->closing': -1,
      'single->opening': 0,
      'single->other': 0,
      'closing->single': 0,
      'closing->closing': -1,
      'closing->opening': 0,
      'closing->other': 0,
      'opening->single': 1,
      'opening->closing': 0,
      'opening->opening': 1,
      'opening->other': 1,
      'other->single': 0,
      'other->closing': -1,
      'other->opening': 0,
      'other->other': 0
    };

    for (var i = 0; i < lines.length; i++) {
      var ln = lines[i];

      // Luca Viggiani 2017-07-03: handle optional <?xml ... ?> declaration
      if (ln.match(/\s*<\?xml/)) {
        formatted += ln + "\n";
        continue;
      }
      // ---

      var single = Boolean(ln.match(/<.+\/>/)); // is this line a single tag? ex. <br />
      var closing = Boolean(ln.match(/<\/.+>/)); // is this a closing tag? ex. </a>
      var opening = Boolean(ln.match(/<[^!].*>/)); // is this even a tag (that's not <!something>)
      var type = single ? 'single' : closing ? 'closing' : opening ? 'opening' : 'other';
      var fromTo = lastType + '->' + type;
      lastType = type;
      var padding = '';

      indent += transitions[fromTo];
      for (var j = 0; j < indent; j++) {
        padding += '\t';
      }
      if (fromTo == 'opening->closing')
        formatted = formatted.substr(0, formatted.length - 1) + ln + '\n'; // substr removes line break (\n) from prev loop
      else
        formatted += padding + ln + '\n';
    }

    return formatted;
  }

  public converterObjParaXML(obj: any) {
    let xml = '';
    // tslint:disable-next-line: forin
    for (const prop in obj) {
      xml += obj[prop] instanceof Array ? '' : '<' + prop + '>';
      if (obj[prop] instanceof Array) {
        // tslint:disable-next-line: forin
        for (const array in obj[prop]) {
          xml += '<' + prop + '>';
          xml += this.converterObjParaXML(new Object(obj[prop][array]));
          xml += '</' + prop + '>';
        }
      } else if (typeof obj[prop] === 'object') {
        xml += this.converterObjParaXML(new Object(obj[prop]));
      } else {
        xml += obj[prop];
      }
      xml += obj[prop] instanceof Array ? '' : '</' + prop + '>';
    }
    xml = xml.replace(/<\/?[0-9]{1,}>/g, '');
    return xml;
  }

  public isJSON(str: string): boolean {
    try {
      JSON.parse(str);
    } catch (e) {
      return false;
    }
    return true;
  }

  public removerTagsHTML(str: string): string {
    if (!str) {
      return '';
    }
    return str.split(/<.+?>/).join('');
  }

  public obterDataUTC(date: Date | string) {
    const dt: Date = date instanceof Date ? date : new Date(date);
    return new Date(Date.UTC(
      dt.getFullYear(),
      dt.getMonth(),
      dt.getDate(),
      dt.getHours(),
      dt.getMinutes(),
      dt.getSeconds(),
      dt.getMilliseconds()
    ));
  }

  public retornarDiaDoAno(date: Date): number {
    const inicioAno = new Date(date.getFullYear(), 0, 0);
    const dif = date.getTime() - inicioAno.getTime();
    const umDia = 1000 * 60 * 60 * 24;
    return Math.floor(dif / umDia);
  }

  public abreviarStr(str: string, n: number, ret?: boolean): string {
    if (!str || !n) {
      return '';
    }
    let retorno = str;
    retorno = retorno.trim();
    if (retorno.length > n) {
      retorno = retorno.substr(0, n);
      if (ret) {
        retorno = retorno.substr(0, n - 3).concat('...');
      }
    }
    return retorno;
  }

  public focarCampo(input: ElementRef | AutoComplete | Calendar): void {
    if (input as ElementRef) {
      if (input['el']) {
        setTimeout(() => (input['el'] as ElementRef).nativeElement.focus());
      } else {
        setTimeout(() => (input as ElementRef).nativeElement.focus());
      }
    } else if (input as AutoComplete) {
      setTimeout(() => (input as AutoComplete).focusInput());
    } else {
      console.log('Campo informado para foco não é válido', input);
    }
  }

  public campoJsonToken(token: string, campo: string) {

    if (!token) {
      return null;
    }
    const tokenJson = jwt_decode(token) as any;

    return tokenJson[campo];
  }

  public exportar(formato: FormatoExportacao, lista: any[], nome: string, colunas: Coluna[]) {
    const listaItens = new Array();

    if (formato === 'xlsx') {

      for (const item of lista) {
        const model = {};
        for (const col of colunas) {
          model[col.titulo] = this.retornaCelula(col, this.retornaValorEntidade(item, col.coluna), item);
        }
        listaItens.push(model);
      }
      tsXLXS().exportAsExcelFile(listaItens).saveAsExcelFile(nome);

    } else if (formato === 'xml') {

      const x2js = new X2JS({});
      for (const item of lista) {
        const model = {};
        for (const col of colunas) {
          model[this.removerPontos(this.removerAcentos(col.titulo.split(' ').join('')))] =
            this.retornaCelula(col, this.retornaValorEntidade(item, col.coluna), item);
        }
        listaItens.push(model);
      }
      const xmlDocStr = x2js.js2xml(
        {
          registros: {
            item: listaItens
          }
        }
      );
      const element = document.createElement('a');
      element.setAttribute('href', 'data:text/xml;charset=utf-8,' + encodeURIComponent(this.formatXml(xmlDocStr)));
      element.setAttribute('download', nome);
      element.style.display = 'none';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);

    } else if (formato === 'JSON') {

      const element = document.createElement('a');
      element.setAttribute('href', 'data:application/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(lista)));
      element.setAttribute('download', `${nome}`);
      element.style.display = 'none';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);

    } else if (formato === 'csv') {

      let arquivo = '';
      for (const col of colunas) {
        arquivo += col.titulo + ';';
      }
      arquivo += '\n';
      for (const item of lista) {
        for (const col of colunas) {
          let valor = this.retornaCelula(col, this.retornaValorEntidade(item, col.coluna), item);
          if (valor?.includes(';')) {
            valor = valor.split(';').join('');
          }
          arquivo += String(valor) + ';';
        }
        arquivo += '\n';
      }

      const element = document.createElement('a');
      element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(arquivo));
      element.setAttribute('download', `${nome}.csv`);
      element.style.display = 'none';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);

    } else if (formato === 'docx') {

      const paragrafos: Paragraph[] = [];
      for (const item of lista) {
        for (const col of colunas) {
          const parag = new Paragraph({
            children: [
              new TextRun({
                text: String(col.titulo.endsWith(':') ? col.titulo : col.titulo + ':') + '\t',
                bold: true,
              }),
              new TextRun({
                text: this.retornaCelula(col, this.retornaValorEntidade(item, col.coluna), item)
              }),
            ],
          })
          paragrafos.push(parag)
        }
        paragrafos.push(new Paragraph({}))
      }
      const doc = new Document({
        sections: [{
          properties: {},
          children: paragrafos
        }]
      });

      Packer.toBlob(doc).then(blob => {
        const downloadURL = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = downloadURL;
        link.download = `${nome}.docx`;
        link.target = '_blank';
        link.click();
        window.URL.revokeObjectURL(downloadURL);
      });

    }
  }
}

export class Mensagem {

  static sucesso(msgService: MessageService, mensagem: string): void;
  static sucesso(msgService: MessageService, mensagem: string, titulo: string): void;
  static sucesso(msgService: MessageService, mensagem: string, titulo: string, life: number): void;
  static sucesso(msgService: MessageService, mensagem: string, titulo?: string, life?: number): void {
    this.criarMensagem(msgService, 'success', titulo, mensagem, life);
  }

  static info(msgService: MessageService, mensagem: string): void;
  static info(msgService: MessageService, mensagem: string, titulo: string): void;
  static info(msgService: MessageService, mensagem: string, titulo: string, life: number): void;
  static info(msgService: MessageService, mensagem: string, titulo?: string, life?: number): void {
    this.criarMensagem(msgService, 'info', titulo ? titulo : 'Informação!', mensagem, life);
  }

  static alerta(msgService: MessageService, mensagem: string): void;
  static alerta(msgService: MessageService, mensagem: string, titulo: string): void;
  static alerta(msgService: MessageService, mensagem: string, titulo: string, life: number): void;
  static alerta(msgService: MessageService, mensagem: string, titulo?: string, life?: number): void {
    this.criarMensagem(msgService, 'warn', titulo ? titulo : 'Atenção!', mensagem, life);
  }

  static erro(msgService: MessageService, mensagem: string): void;
  static erro(msgService: MessageService, mensagem: string, titulo: string): void;
  static erro(msgService: MessageService, mensagem: string, titulo: string, life: number): void;
  static erro(msgService: MessageService, mensagem: string, titulo?: string, life?: number): void {
    this.criarMensagem(msgService, 'error', titulo ? titulo : 'Atenção!', mensagem, life);
  }

  private static criarMensagem(
    msgService: MessageService, severity: 'success' | 'info' | 'warn' | 'error', summary: string, detail: string, life?: number
  ): void {
    msgService.add({ severity: severity, summary: summary, detail: detail, life: life ? life : 5000 });
  }


}
