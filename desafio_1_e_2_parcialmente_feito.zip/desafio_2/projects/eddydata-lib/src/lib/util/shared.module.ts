import { CommonModule, registerLocaleData } from '@angular/common';
import localept from '@angular/common/locales/pt';
import { LOCALE_ID, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PageHeaderComponent } from '../components/page-header/page-header.component';
import { FormFieldErrorComponent } from '../components/form-field-error/form-field-error.component';
import { ServerErrorMessagesComponent } from '../components/server-error-messages/server-error-messages.component';
import { PaginacaoComponent } from '../components/paginacao/paginacao.component';
import { FiltroComponent } from '../components/filtro/filtro.component';
import { DivisorComponent } from '../components/divisor/divisor.component';
import { ConfirmacaoComponent } from '../components/confirmacao/confirmacao.component';
import { CpfPipe } from '../components/pipe/cpf.pipe';
import { TelefonePipe } from '../components/pipe/telefone.pipe';
import { ProgressoComponent } from '../components/progresso/progresso.component';
import { LoaderComponent } from '../components/loader/loader.component';
import { ExportListComponent } from '../components/export-list/export-list.component';

registerLocaleData(localept, 'pt');

@NgModule({
  declarations: [
    PageHeaderComponent,
    FormFieldErrorComponent,
    ServerErrorMessagesComponent,
    PaginacaoComponent,
    FiltroComponent,
    ExportListComponent,
    ProgressoComponent,
    DivisorComponent,
    LoaderComponent,
    ConfirmacaoComponent,
    CpfPipe, TelefonePipe
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [
    CommonModule,
    ReactiveFormsModule,
    PageHeaderComponent,
    FormFieldErrorComponent,
    ServerErrorMessagesComponent,
    PaginacaoComponent,
    FiltroComponent,
    ExportListComponent,
    DivisorComponent,
    ProgressoComponent,
    LoaderComponent,
    ConfirmacaoComponent,
    CpfPipe, TelefonePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'pt' }],
})
export class SharedModule { }
