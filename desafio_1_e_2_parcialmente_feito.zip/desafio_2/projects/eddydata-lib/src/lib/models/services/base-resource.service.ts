// tslint:disable: forin
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError, take } from 'rxjs/operators';
import * as toastr from 'toastr';
import { Injector } from '@angular/core';
import { Router } from '@angular/router';
import { BaseResourceModel } from '../base-resource.model';
import { Login } from '../../entidade/login/login';
import { Page } from '../../util/page';
import jwt_decode from 'jwt-decode';
import * as bcrypt from 'bcryptjs';

export abstract class BaseResourceService<T extends BaseResourceModel> {

  public login: Login = new Login();
  protected http: HttpClient;

  constructor(
    protected api: string,
    protected injector: Injector
  ) {
    this.http = injector.get(HttpClient);
    this.login = JSON.parse(sessionStorage.getItem('login'));
  }

  retornarRota(): string {
    return this.injector.get(Router).url;
  }

  protected httpOptions() {
    this.login = JSON.parse(sessionStorage.getItem('login'));
    if (this.login) {
      return {
        headers: new HttpHeaders(this.adicionarCriptografia({
          'Content-Type': 'application/json',
          Authorization: this.login.token
        })),
        reportProgress: true
      };
    } else {
      return {
        headers: new HttpHeaders(this.adicionarCriptografia({
          'Content-Type': 'application/json'
        })),
        reportProgress: true
      };
    }
  }

  protected adicionarCriptografia(header: {}) {
    this.login = JSON.parse(sessionStorage.getItem('login'));
    if (this.login && this.login.token) {
      const tokenJson = jwt_decode(this.login.token) as any;
      const agora = new Date().getTime();
      const comparar = ((agora - +tokenJson.iat) / +tokenJson.id).toFixed(0);
      const criptografado = bcrypt.hashSync(comparar, tokenJson.chave);

      header['agora'] = agora + '';
      header['codigo'] = criptografado;

    }

    return header;
  }

  todos(): Observable<Page>;
  todos(pagina: number, limite: number): Observable<Page>;
  todos(pagina?: number, limite?: number): Observable<Page> {
    if (!Number.isInteger(limite) || !Number.isInteger(pagina)) {
      pagina = 1;
      limite = 1000;
    }
    this.login = JSON.parse(sessionStorage.getItem('login'));
    return this.http.get<Page>(`${this.login.cidade.id}/${this.api}/${pagina}/${limite}`, this.httpOptions()).pipe(
      map(res => res),
      catchError(err => this.handleError(err))
    );
  }

  obterId(id: number, httpOptions?: {}): Observable<T> {
    return this.http.get<T>(this.obterUrl(id), (httpOptions ? httpOptions : this.httpOptions())).pipe(
      map(res => res),
      catchError(err => this.handleError(err))
    );
  }

  public obter(filtros?: {}): Observable<T> {
    let parametros = '';
    if (filtros) {
      for (const key in filtros) {
        if (parametros === '') {
          parametros += '?';
        } else {
          parametros += '&';
        }
        parametros += key + '=' + filtros[key];
      }
    }
    this.login = JSON.parse(sessionStorage.getItem('login'));
    return this.http.get<Page>(`${this.login.cidade.id}/${this.api}/obter${parametros}`,
      this.httpOptions()).pipe(
        take(1),
        map(res => res),
        catchError(err => this.handleError(err))
      );
  }

  inserir(resource: T): Observable<T> {
    this.login = JSON.parse(sessionStorage.getItem('login'));
    return this.http.post(`${this.login.cidade.id}/${this.api}`, resource, this.httpOptions()).pipe(
      map(res => res),
      catchError(err => this.handleError(err))
    );
  }

  atualizar(resource: T): Observable<T> {
    return this.http.put(this.obterUrl(resource.id), resource, this.httpOptions()).pipe(
      map(res => res),
      catchError(err => this.handleError(err))
    );
  }

  remover(id: number): Observable<T> {
    return this.http.delete(this.obterUrl(id), this.httpOptions()).pipe(
      map(() => null),
      catchError(err => this.handleError(err))
    );
  }

  private obterUrl(id: number) {
    this.login = JSON.parse(sessionStorage.getItem('login'));
    return `${this.login.cidade.id}/${this.api}/${id}`;
  }

  protected handleError(error: HttpErrorResponse): Observable<any> {
    if (error.status === 401) {
      this.login = JSON.parse(sessionStorage.getItem('login'));
      
      if (this.login && this.login.usuario.sistema === 'transparencia') {
        this.login = null;
        sessionStorage.setItem('login', null);
        location.reload();
      } else {
        toastr.warning('Sua sessão expirou, por favor faça o login novamente!', 'Sessão expirada');
        sessionStorage.clear();
        this.injector.get(Router).navigate(['/login']);
      }
    } else {
      return throwError(error);
    }
  }

  filtrar(pagina: number, limite: number, filtros: {}): Observable<Page> {
    let parametros = '';
    if (filtros) {
      for (const key in filtros) {
        if (parametros === '') {
          parametros += '?';
        } else {
          parametros += '&';
        }
        parametros += key + '=' + encodeURIComponent(filtros[key]);
      }
    }

    this.login = JSON.parse(sessionStorage.getItem('login'));
    return this.http.get<Page>(`${this.login.cidade.id}/${this.api}/${pagina}/${limite}${parametros}`, this.httpOptions()).pipe(
      map(res => res),
      catchError(err => this.handleError(err))
    );
  }

  public extendido(pagina: number, limite: number, filtros?: {}): Observable<Page> {
    let parametros = '';
    if (filtros) {
      for (const key in filtros) {
        if (parametros === '') {
          parametros += '?';
        } else {
          parametros += '&';
        }
        parametros += key + '=' + filtros[key];
      }
    }

    this.login = JSON.parse(sessionStorage.getItem('login'));
    return this.http.get<any>(`${this.login.cidade.id}/${this.api}/extendido/${pagina}/${limite}${parametros}`, this.httpOptions()).pipe(
      map(res => res),
      catchError(err => this.handleError(err))
    );
  }

  public download(nome: string): Observable<any> {
    this.login = JSON.parse(sessionStorage.getItem('login'));
    return this.http.get<any>(`${this.login.cidade.id}/${this.api}/download/${nome}`, {
      responseType: 'blob' as 'json',
      headers: new HttpHeaders(this.adicionarCriptografia({
        Authorization: this.login.token,
      }))
    }).pipe(
      map(res => res),
      catchError(err => this.handleError(err))
    );
  }

  public assinar(arquivo: any): Observable<any> {
    return this.http.post<any>(`http://localhost:5678/`, arquivo, { responseType: 'blob' as 'json' }).pipe(
      map(res => res),
      catchError(err => this.handleError(err))
    );
  }

}
