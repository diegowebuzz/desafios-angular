import { AfterViewInit, Directive, Injector, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConfirmationService } from 'primeng/api';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import * as toastr from 'toastr';
import { Relatorio } from '../components/report';
import { Coluna, FormatoExportacao } from '../components/types';
import { Login } from '../entidade/login/login';
import { FuncaoService } from '../util/funcao.service';
import { GlobalService } from '../util/global.service';
import { BaseResourceModel } from './base-resource.model';
import { BaseResourceService } from './services/base-resource.service';

@Directive()
export abstract class BaseResourceListComponent<T extends BaseResourceModel, U extends Login> implements OnInit, OnDestroy, AfterViewInit {

  // ========================================================================
  // ----------------------- DECLARAÇÃO DE VARIAVEIS ------------------------
  // ========================================================================
  public login: U;
  public lista: T[] = [];
  public paginaCorrente: number;
  public paginaTotal: number;
  public filtro: string;
  protected router: Router;
  protected confirmationService: ConfirmationService = new ConfirmationService();
  public usarExtendido = false;

  public col = 1;
  public ascendente = true;
  public imagem = 'sort_asc_az.png';
  private admin: boolean;

  // padrao de url para transparencia .../pagina/data1/data2 ou .../pagina/data1/data2/filtro
  private transparenciaRegexp: RegExp = /(.*)\/(\d+)\/\d{4}\-\d{2}\-\d{2}\/\d{4}\-\d{2}\-\d{2}(.*)|(.*)\/(\d+)\/([1-12])\/(\d+)\/\w+(.*)/;

  protected unsubscribe: Subject<void> = new Subject();

  // ========================================================================
  // ------------------------------ CONSTRUTOR ------------------------------
  // ========================================================================
  constructor(
    protected baseResourceService: BaseResourceService<T>,
    protected injector: Injector
  ) {
    this.login = JSON.parse(sessionStorage.getItem('login'));
    this.router = this.injector.get(Router);
  }

  // ========================================================================
  // -------------------------- MÉTODOS ABSTRAÍDOS --------------------------
  // ========================================================================
  /**
   * Método com as condições padrões da listagem
   * @example {
   * ['orgao.id']: this.login.orgao.id
   * }
   */
  protected abstract condicoesGrid(): {};
  /**
   * Método com as ordenações da listagem
   * @example ['nome', 'sobrenome$DESC']
   */
  protected abstract ordenacaoGrid(): string[];
  /**
   * Método com os campos de filtro da listagem de acordo com o valor digitado na pesquisa
   * @example {
   *  number: ['id', 'numero'],
   *  date: ['data'],
   *  text: ['nome', 'descricao'],
   * }
   */
  protected abstract filtrosGrid(): Filtro;
  /**
   * Método executado após `preencherGrid()` antes de finalizar o `ngOnInit()`
   */
  protected abstract afterInit(): void;
  /**
   * Ação que será executada no `accept` do método `delete()`
   * @example entidade.situacao = 'B';
   * this.service.atualizar(entidade);
   */
  protected abstract acaoRemover(model: T): Observable<T>;
  /**
   * Método com as colunas para geração do relatório em PDF
   * @example [
   * { coluna: 'numero', titulo: 'Número' },
   * { coluna: 'data', titulo: 'Cadastro', bold: true, alignment: 'left' }
   * ]
   */
  protected abstract colunasRelatorio(): string[] | Coluna[];
  /**
   * Método para exportação de listagens em todos formatos (será obrigatória na próxima atualização de estrutura)
   */
  // protected abstract exportarListagem(formato: FormatoExportacao): void;
  public exportarListagem(formato: FormatoExportacao) { }
  /**
   * Método com os relations necessários para a listagem
   * @example 'orgao,orgao.cidade,usuario'
   */
  protected abstract relations(): string;

  // ========================================================================
  // -------------------------- MÉTODOS DA CLASSE ---------------------------
  // ========================================================================
  /**
   * @see `ngOnInit`
   */
  public ngOnInit() {
    toastr.options.positionClass = 'toast-top-left';
    this.beforeInit();
    if (!this.paginaCorrente) {
      this.paginaCorrente = 1;
    }
    this.carregarFiltros();
    window.scrollTo(0, 0);
    this.preencherGrid();
    this.salvarFiltros();
    this.afterInit();
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  ngAfterViewInit() {
    new GlobalService().calendarMascara();
  }

  /**
   * Método usado para carregar opções atuais dos filtros após o `beforeInit()`
   *
   * @see `beforeInit`
   */
  private carregarFiltros(): void {
    //paginaCorrente
    if (this.baseResourceService.retornarRota().match(this.transparenciaRegexp)) {
      if (this.baseResourceService.retornarRota().match(this.transparenciaRegexp)[2]) {
        this.paginaCorrente = +this.baseResourceService.retornarRota().match(this.transparenciaRegexp)[2];
      } else {
        this.paginaCorrente = +this.baseResourceService.retornarRota().match(this.transparenciaRegexp)[5];
      }
    } else {
      this.paginaCorrente = +sessionStorage.getItem(`${this.retornarRota()}_paginaCorrente`);
    }
    this.paginaCorrente = this.paginaCorrente ? this.paginaCorrente : 1;

    //filtro
    if (this.baseResourceService.retornarRota().match(this.transparenciaRegexp)) {
      this.filtro = this.baseResourceService.retornarRota().match(this.transparenciaRegexp)[3];
      if (this.filtro === undefined) {
        this.filtro = this.baseResourceService.retornarRota().match(this.transparenciaRegexp)[8];
      }
      if (this.filtro) {
        this.filtro = this.filtro.startsWith('/') ? this.filtro.substring(1) : this.filtro;
      }
    } else {
      this.filtro = sessionStorage.getItem(`${this.retornarRota()}_filtro`);
    }
    this.filtro = this.filtro ? this.filtro : '';
  }

  /**
   * Método usado para salvar as opções atuais dos filtros após o `preencherGrid()`
   *
   * @see `preencherGrid`
   */
  private salvarFiltros(): void {
    sessionStorage.setItem(`${this.retornarRota()}_paginaCorrente`, String(this.paginaCorrente));
    sessionStorage.setItem(`${this.retornarRota()}_filtro`, this.filtro);
  }

  private retornarRota(): string {
    const url = this.baseResourceService.retornarRota();
    if (url.match(this.transparenciaRegexp)) {
      return url.match(this.transparenciaRegexp)[1] ? url.match(this.transparenciaRegexp)[1] : url.match(this.transparenciaRegexp)[4];
    } else {
      return url;
    }
  }

  /**
   * Método executado ao iniciar o `ngOnInit()`
   *
   * @see `ngOnInit`
   */
  public beforeInit(): void {
  }

  /**
   * Método utilizado para retornar os parâmetros usados na listagem,
   * incluindo parametros de ordenação e filtros da listagem
   */
  public obterParametros(): {} {
    // inclui parametros da listagem
    const parametros = this.condicoesGrid();
    if (this.filtro) {
      this.filtro = this.filtro.trim();
      if (new FuncaoService().isNumber(this.filtro.split('.').join('').split(',').join('.').split('-').join(''))) { // caso a pesquisa seja de um número
        if (this.filtrosGrid().number) {
          let filtroNumber: number | string = this.filtro.split('.').join('').split(',').join('.').split('-').join('');
          if (this.filtro.startsWith('0') && +filtroNumber > 0) {
            filtroNumber = +this.filtro.split('.').join('').split(',').join('.').split('-').join('');
          }
          let filtroNumberOR: string[] = [];
          for (const f of this.filtrosGrid().number) {
            filtroNumberOR = filtroNumberOR.concat(f.concat('$like=').concat(String(filtroNumber + '%')));
          }
          parametros['OR'] = filtroNumberOR.join(',');
        }
        if (this.filtrosGrid().text && this.filtro.startsWith('0')) {
          /* new FuncaoService().removerAcentos(this.filtro);
           * removi essa função porque no typeOrm tem que ter uma funcao para remover os acentos também
          */
          let filtroSemAcentos = this.filtro;
          if (new FuncaoService().isNumber(this.filtro.split('.').join('').split(',').join('.').split('-').join(''))) { // caso a pesquisa seja de um número
            filtroSemAcentos = this.filtro.split('.').join('').split(',').join('.').split('-').join('');
          }

          let filtroTextOR: string[] = [];
          for (const f of this.filtrosGrid().text) {
            filtroTextOR = filtroTextOR.concat(f.concat('$like=%').concat(filtroSemAcentos).concat('%'));
          }
          if (parametros['OR']) {
            parametros['OR'] += ',' + filtroTextOR.join(',');
          } else {
            parametros['OR'] = filtroTextOR.join(',');
          }
        }
      } else if (this.filtro.match(/^\d{2}\/\d{2}\/\d{4}$/)) { // caso a pesquisa seja de uma data
        if (this.filtrosGrid().date) {
          // caso exista apenas um campo de filtro inclui como parametro normal, caso contrário inclui como `OR`
          if (this.filtrosGrid().date.length === 1) {
            parametros[this.filtrosGrid().date[0]] = this.filtro;
          } else {
            let filtroDateOR: string[] = [];
            for (const f of this.filtrosGrid().date) {
              filtroDateOR = filtroDateOR.concat(f.concat('=').concat(this.filtro));
            }
            parametros['OR'] = filtroDateOR.join(',');
          }
        }
      } else { // caso a pesquisa seja de um texto
        if (this.filtrosGrid().text) {
          /* new FuncaoService().removerAcentos(this.filtro);
           * removi essa função porque no typeOrm tem que ter uma funcao para remover os acentos também
          */
          const filtroSemAcentos = this.filtro;
          // caso exista apenas um campo de filtro inclui como parametro normal, caso contrário inclui como `OR`
          if (this.filtrosGrid().text.length === 1) {
            parametros[this.filtrosGrid().text[0].concat('$like')] = '%'.concat(filtroSemAcentos).concat('%');
          } else {
            let filtroTextOR: string[] = [];
            for (const f of this.filtrosGrid().text) {
              filtroTextOR = filtroTextOR.concat(f.concat('$like=%').concat(filtroSemAcentos).concat('%'));
            }
            parametros['OR'] = filtroTextOR.join(',');
          }
        }
      }
    }

    // incluir ordenação
    parametros['orderBy'] = this.ordenacaoGrid().join(',');

    // retorna parâmetros
    return parametros;
  }

  /**
   * Método para preencher a listagem de acordo com os parâmetros em `obterParametros()` e com os `relations()`
   *
   * @see `obterParametros`
   * @see `relations`
   */
  public preencherGrid() {
    if (!this.usarExtendido) {
      this.baseResourceService
        .filtrar(this.paginaCorrente,
          this.login.limite,
          this.relations() ? Object.assign({}, { relations: this.relations() }, this.obterParametros()) : this.obterParametros())
        .pipe(takeUntil(this.unsubscribe))
        .subscribe(
          lista => {
            this.lista = lista.content;
            this.paginaTotal = lista.totalPages;
            this.aposPreencher();
          },
          error => alert('erro ao retornar lista')
        );
    } else {
      this.baseResourceService
        .extendido(this.paginaCorrente,
          this.login.limite,
          this.relations() ? Object.assign({}, { relations: this.relations() }, this.obterParametros()) : this.obterParametros())
        .pipe(takeUntil(this.unsubscribe))
        .subscribe(
          lista => {
            this.lista = lista.content;
            this.paginaTotal = lista.totalPages;
            this.aposPreencher();
          },
          error => alert('erro ao retornar lista')
        );
    }
    this.salvarFiltros();
  }

  /**
   * Método usado para ser executado após o `preencherGrid()`
   */
  public aposPreencher() {
  }

  /**
   * Método para recarregar a listagem após alteração de um objeto combo
   * @see `preencherGrid`
   */
  public onChange() {
    this.paginaCorrente = 1;
    this.preencherGrid();
    this.salvarFiltros();
  }

  /**
   * Método para recarregar a listagem após clique em um botão
   * @see `preencherGrid`
   */
  public onClick(valueEmitted?: string) {
    this.filtro = valueEmitted;
    this.paginaCorrente = 1;
    this.preencherGrid();
    this.salvarFiltros();
  }

  /**
   * Método para ordernar os registros no grid
   * @see `preencherGrid`
   */
  public ordenar(idx: number) {
    if (this.col === idx) {
      this.ascendente = !this.ascendente;
      this.imagem = this.ascendente ? 'sort_asc_az.png' : 'sort_desc_az.png';
    }
    this.col = idx;
    this.preencherGrid();
    this.salvarFiltros();
  }

  /**
   * Método para filtrar a listagem após a tecla `Enter` for pressionada no input `button-addon2`
   * @see `onClick`
   */
  public onKeydown(event: any) {
    if (event.key === 'Enter') {
      document.getElementById('button-addon2').click();
    }
  }

  /**
   * Percorre a listagem para a próxima página, caso seja a última página permanece na mesma
   * @see `preencherGrid`
   */
  public proximaPagina() {
    this.paginaCorrente = this.paginaCorrente === this.paginaTotal ? this.paginaTotal : this.paginaCorrente + 1;
    this.preencherGrid();
    this.salvarFiltros();
    window.scrollTo(0, 0);
  }

  /**
   * Percorre a listagem para a página anterior, caso seja a primeira página permanece na mesma
   * @see `preencherGrid`
   */
  public paginaAnterior() {
    this.paginaCorrente = this.paginaCorrente === 1 ? 1 : this.paginaCorrente - 1;
    this.preencherGrid();
    this.salvarFiltros();
    window.scrollTo(0, 0);
  }

  /**
   * Verifica se o login atual tem a opção de incluir a página informada no parâmetro `url`
   * @param url url da pagina a ser verificada, caso não informado será usada a rota atual em `retornarRota()`
   */
  public podeIncluir(url?: string) {
    if (this.login) {
      if (this.administrador()) {
        return true;
      }
      if (!url) {
        url = this.baseResourceService.retornarRota();
      }
      if (url.lastIndexOf('/') > 0) {
        url = url.substring(0, url.substring(1, url.length).indexOf('/') + 1);
      }
      for (const acesso of this.login.acessos) {
        if (url === acesso.pagina) {
          return acesso.permissao === 2;
        }
      }
    }
    return false;
  }

  administrador() {
    if (this.admin === null || this.admin === undefined) {
      this.admin = new FuncaoService().campoJsonToken(this.login.token, 'administrador') == true;
    }
    return this.admin;
  }

  /**
   * Verifica se a data informada permite alteração de acordo com parâmetro `Dias para bloquear alterações`
   * @param data data a ser verificada com a data atual
   */
  public podeAlterar(data: Date): boolean {
    if (this.login['dias_bloquear_alteracoes']) {
      return new FuncaoService().diferencaEmDias(new Date(), new Date(data)) < this.login['dias_bloquear_alteracoes'];
    } else {
      return true;
    }
  }

  /**
   * Método para remover o objeto passado via parâmetro
   * Ao aceitar a mensagem de confirmação será executado o método `acaoRemover()`
   * @see `acaoRemover`
   * @param resource entidade a ser removida
   */
  public delete(resource: T) {
    this.confirmationService.confirm({
      message: 'Deseja realmente remover esse registro?',
      header: 'Exclusão',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.acaoRemover(resource)
          .pipe(takeUntil(this.unsubscribe))
          .subscribe(() => {
            toastr.success('Registro excluído com sucesso!');
            this.lista = this.lista.filter(element => element !== resource);
          }, () => toastr.error('erro ao tentar excluir registro'));
      },
      reject: () => {
        toastr.info('Operação foi cancelada!');
      }
    });
  }

  /**
   * Método para imprimir os registros da listagem de acordo com o método `colunasRelatorio()`
   * @see `colunasRelatorio`
   */
  public imprimir(
    titulo: string, usuario: string, orgao: string, brasao: string, orientacao: 'landscape' | 'portrait',
    nomepdf?: string, largura?: (string | number)[], lista?: any[], totalizar?: (string | {})[]) {
    Relatorio.imprimir(titulo, usuario, orgao, brasao, lista ? lista : this.lista, this.colunasRelatorio(),
      orientacao, nomepdf, largura, totalizar);
  }

  public exportar(formato: FormatoExportacao, lista: any[], nome?: string) {
    if (!nome) {
      nome = this.baseResourceService.retornarRota().startsWith('/') ? this.baseResourceService.retornarRota().substr(1) : this.baseResourceService.retornarRota();
    }
    const colunas = this.colunasRelatorio() as Coluna[];

    new FuncaoService().exportar(formato, lista, nome, colunas);
  }

  /**
   * Método para verificação de objetos, usados em combos `<select>`
   */
  compareFn(c1: any, c2: any): boolean {
    return c1 && c2 && c1.id && c2.id ? c1.id === c2.id : c1 === c2;
  }

  /**
   * Método para retornar a página inicial do sistema logado em `login.usuario.sistema`
   */
  public sair() {
    new FuncaoService().navegarPara(this.login.usuario.sistema, this.router);
  }
}

export class Filtro {
  number?: string[];
  date?: string[];
  text?: string[];
}
