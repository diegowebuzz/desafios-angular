import { takeUntil } from 'rxjs/operators';
import { Directive, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import { BaseResourceService } from './services/base-resource.service';
import { FuncaoService } from '../util/funcao.service';
import { AbstractControl } from '@angular/forms';

@Directive()
export class EddyAutoComplete<T> implements OnDestroy {

  public lista: Array<T>;
  public id: number | string;
  protected unsubscribe: Subject<void> = new Subject();
  public limite = 10;

  constructor(
    private campoForm: AbstractControl,
    private service: BaseResourceService<T>,
    private campoChave: string,
    private campoLabel: string[],
    private parametros: {},
    private filtros: {
      number?: string[];
      date?: string[];
      text?: string[];
    },
    funcaoOnSelect?: any,
    limite?: any
  ) {
    if (funcaoOnSelect) {
      this.funcaoOnSelect = funcaoOnSelect;
    }
    if (limite) {
      this.limite = limite;
    }
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  public funcaoOnSelect = () => {
    // deverá ser sobrescrita nas classes filhas
  }

  public filtrar(event: any) {
    const filtro: string = String(event.query).trim();
    const parametrosCampo = {};
    if (filtro) {
      if (new FuncaoService().isNumber(filtro.split('.').join('').split(',').join('.').split('-').join(''))) { // caso a pesquisa seja de um número
        if (this.filtros.number) {
          let filtroNumber: number | string = filtro.split('.').join('').split(',').join('.').split('-').join('');
          if (filtro.startsWith('0') && +filtroNumber > 0) {
            filtroNumber = +filtro.split('.').join('').split(',').join('.').split('-').join('');
          }
          let filtroNumberOR: string[] = [];
          for (const f of this.filtros.number) {
            filtroNumberOR = filtroNumberOR.concat(f.concat('$like=').concat(String(filtroNumber + '%')));
          }
          parametrosCampo['OR'] = filtroNumberOR.join(',');
        }
        if (this.filtros.text && filtro.startsWith('0')) {
          /* new FuncaoService().removerAcentos(filtro);
           * removi essa função porque no typeOrm tem que ter uma funcao para remover os acentos também
          */
          let filtroSemAcentos = filtro;
          if (new FuncaoService().isNumber(filtro.split('.').join('').split(',').join('.').split('-').join(''))) { // caso a pesquisa seja de um número
            filtroSemAcentos = filtro.split('.').join('').split(',').join('.').split('-').join('');
          }

          let filtroTextOR: string[] = [];
          for (const f of this.filtros.text) {
            filtroTextOR = filtroTextOR.concat(f.concat('$like=%').concat(filtroSemAcentos).concat('%'));
          }
          if (parametrosCampo['OR']) {
            parametrosCampo['OR'] += ',' + filtroTextOR.join(',');
          } else {
            parametrosCampo['OR'] = filtroTextOR.join(',');
          }
        }
      } else if (filtro.match(/^\d{2}\/\d{2}\/\d{4}$/)) { // caso a pesquisa seja de uma data
        if (this.filtros.date) {
          // caso exista apenas um campo de filtro inclui como parametro normal, caso contrário inclui como `OR`
          if (this.filtros.date.length === 1) {
            parametrosCampo[this.filtros.date[0]] = filtro;
          } else {
            let filtroDateOR: string[] = [];
            for (const f of this.filtros.date) {
              filtroDateOR = filtroDateOR.concat(f.concat('=').concat(filtro));
            }
            parametrosCampo['OR'] = filtroDateOR.join(',');
          }
        }
      } else { // caso a pesquisa seja de um texto
        if (this.filtros.text) {
          /* new FuncaoService().removerAcentos(filtro);
           * removi essa função porque no typeOrm tem que ter uma funcao para remover os acentos também
          */
          const filtroSemAcentos = filtro;
          // caso exista apenas um campo de filtro inclui como parametro normal, caso contrário inclui como `OR`
          if (this.filtros.text.length === 1) {
            parametrosCampo[this.filtros.text[0].concat('$like')] = '%'.concat(filtroSemAcentos).concat('%');
          } else {
            let filtroTextOR: string[] = [];
            for (const f of this.filtros.text) {
              filtroTextOR = filtroTextOR.concat(f.concat('$like=%').concat(filtroSemAcentos).concat('%'));
            }
            parametrosCampo['OR'] = filtroTextOR.join(',');
          }
        }
      }
    }
    this.service
      .filtrar(1, this.limite, Object.assign({}, this.parametros, parametrosCampo))
      .pipe(takeUntil(this.unsubscribe))
      .subscribe(lista => { this.lista = lista.content; }
      );
  }

  public async atualizar(campoCodigo: boolean, model?: { ngModel: T, field: string }) {
    await new Promise(resolve => {
      if (campoCodigo) {
        const entidade: any = model ? model.ngModel[model.field] : this.campoForm.value;
        if (entidade) {
          this.id = entidade[this.campoChave];
          resolve(true);
        } else {
          resolve(true);
        }
      } else {
        if (this.id) {
          this.service
            .filtrar(1, this.limite, Object.assign({}, this.parametros, { [this.campoChave]: this.id }))
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(dados => {
              if (model)
                model.ngModel[model.field] = dados.content[0];
              else
                this.campoForm.setValue(dados.content[0]);
              resolve(true);
            }
            );
        } else {
          resolve(true);
        }
      }
    });
    this.funcaoOnSelect();
  }

  public conversor = (entidade: T) => {
    let retorno = '';

    for (const campo of this.campoLabel) {
      let valor: any;
      const campoSplit = campo.split('.');
      for (const coluna of campoSplit) {
        if (!valor) {
          valor = entidade[coluna];
        } else {
          valor = valor[coluna];
        }
      }
      retorno = retorno.concat(valor).concat(' - ');
    }

    return retorno.substring(0, retorno.length - ' - '.length);
  }

  public onDropDownClick(event: any) {
    event.query = '';
    this.campoForm.setValue(null);
    this.id = null;
  }
}
