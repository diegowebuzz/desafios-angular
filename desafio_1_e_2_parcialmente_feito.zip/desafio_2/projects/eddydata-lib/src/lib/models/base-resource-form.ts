import { OnInit, AfterContentChecked, Injector, AfterViewInit, ElementRef, OnDestroy, Directive } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as toastr from 'toastr';
import { switchMap, takeUntil } from 'rxjs/operators';
import { BaseResourceModel } from './base-resource.model';
import { AutoComplete } from 'primeng/autocomplete';
import { Calendar } from 'primeng/calendar';
import { Subject } from 'rxjs';
import { Login } from '../entidade/login/login';
import { GlobalService } from '../util/global.service';
import { BaseResourceService } from './services/base-resource.service';
import { LoginContabil } from '../entidade/login/login-contabil';
import { FuncaoService } from '../util/funcao.service';

@Directive()
export abstract class BaseResourceFormComponent<T extends BaseResourceModel, U extends Login>
  implements OnInit, AfterContentChecked, AfterViewInit, OnDestroy {

  // ========================================================================
  // ----------------------- DECLARAÇÃO DE VARIAVEIS ------------------------
  // ========================================================================
  public ptBR: any;
  public login: U;
  public pagTitulo: string;
  public entidadeForm: FormGroup;
  public currentActionRoute: 'novo' | 'editar';
  public disableButton = false;
  public serverErrorMessages: string[] = null;
  public limparTela = false;
  public skipRedirect = false;

  submitted = false;

  public imaskConfig = {
    mask: Number,
    scale: 2,
    signed: true,
    thousandsSeparator: '.',
    padFractionalZeros: true,
    normalizeZeros: true,
    radix: ','
  };

  public imaskQtd = {
    mask: Number,
    scale: 0,
    signed: false
  };
  public imaskValor = {
    mask: Number,
    scale: 5,
    signed: false,
    thousandsSeparator: '.',
    padFractionalZeros: true,
    normalizeZeros: true,
    radix: ','
  };
  public imaskDateGt = {
    mask: Date,
    pattern: 'd{.}`m{.}`Y',  // Pattern mask with defined blocks, default is 'd{.}`m{.}`Y'
    min: new Date(),
    autofix: false,
    overwrite: true,
    parse: function (str) {
      const yearMonthDay = str.split('.');
      return new Date(yearMonthDay[2], yearMonthDay[1] - 1, yearMonthDay[0]);
    },
  };
  public imaskDate = {
    mask: Date,
    pattern: 'd{.}`m{.}`Y',  // Pattern mask with defined blocks, default is 'd{.}`m{.}`Y'
    autofix: false,
    overwrite: true,
    parse: function (str) {
      const yearMonthDay = str.split('.');
      return new Date(yearMonthDay[2], yearMonthDay[1] - 1, yearMonthDay[0]);
    },
  };

  /**
   * Caso verdadeira, o formulário não persistirá as informações informadas
   */
  public readOnly = false;

  public mensagemSucesso = 'Solicitação processada com sucesso!';
  protected router: Router;
  protected fb: FormBuilder;
  protected activatedRoute: ActivatedRoute;

  protected unsubscribe: Subject<void> = new Subject();
  private admin: boolean;

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  get f() { return this.entidadeForm.controls; }

  // ========================================================================
  // ------------------------------ CONSTRUTOR ------------------------------
  // ========================================================================
  constructor(
    public entidade: T,
    protected injector: Injector,
    protected jsonDataToResourceFn: (json: any) => T,
    protected baseResourceService: BaseResourceService<T>) {
    this.router = this.injector.get(Router);
    this.fb = this.injector.get(FormBuilder);
    this.activatedRoute = this.injector.get(ActivatedRoute);
  }

  // ========================================================================
  // -------------------------- MÉTODOS ABSTRAÍDOS --------------------------
  // ========================================================================
  /**
   * Método para vincular os campos da entidade no formbuilder,
   * executado dentro do método `ngOnInit()` entre `setCurrentActionRoute` e `loadResource()`
   * @see `ngOnInit`
   * @example this.entidadeForm = this.fb.group({
   * id: [null],
   * nome: [null, Validators.required]
   * });
   */
  protected abstract criarCamposForm(): void;
  /**
   * Método com os parâmetros extras necessários para a listagem
   * @example {
   * relations: orgao,orgao.cidade,usuario,
   * orderBy: 'item.id'
   * }
   */
  protected abstract parametrosExtras(): {};
  /**
   * Método para tratativas após carregamento da entidade,
   * executado dentro do `loadResource()` antes do `patchValue` do formGroup
   */
  protected abstract afterLoad(): void;
  /**
   * Método executado dentro do método `ngOnInit()` após o `loadResource()`
   * @see `ngOnInit`
   */
  protected abstract afterInit(): void;
  /**
   * Método com as validações antes de submeter o formulário, executado dentro do método `submitForm()`
   * @see `submitForm`
   */
  protected abstract beforeSubmit(): void;
  /**
   * Método com as validações após de submeter o formulário, executado dentro do método `acaoSucesso()`
   * @see `acaoSucesso`
   */
  protected abstract afterSubmit(entidade: T): void;

  // ========================================================================
  // -------------------------- MÉTODOS DA CLASSE ---------------------------
  // ========================================================================
  ngOnInit() {
    this.login = JSON.parse(sessionStorage.getItem('login'));
    this.ptBR = new GlobalService().obterDataBR();
    toastr.options.positionClass = 'toast-top-left';
    this.skipRedirect = false;
    new GlobalService().convertEnterParaTab();
    if (!this.podeIncluir() && this.baseResourceService.retornarRota().includes('editar')) {
      toastr.warning('Você não possui permissão para este acesso!');
      this.sair();
      return;
    }

    this.setCurrentActionRoute();
    if (!this.readOnly) {
      this.criarCamposForm();
    }
    const x = this.loadResource().then(() => {
      window.scrollTo(0, 0);
      if (!this.readOnly && this.campoFoco()) {
        new FuncaoService().focarCampo(this.campoFoco());
      }
    });
    this.afterInit();
  }

  ngAfterContentChecked() {
    this.setTitulo();
  }

  ngAfterViewInit() {
    new GlobalService().calendarMascara();
  }

  async submitForm(limpa?: boolean) {
    if (this.readOnly) {
      toastr.error('Formulário em modo de apenas leitura');
      return;
    }
    this.limparTela = limpa ? true : false;
    this.disableButton = true;
    await this.beforeSubmit();
    this.submitted = true;
    if (this.entidadeForm.invalid) {
      toastr.error('Há campos obrigatórios não informados!');
      return;
    }
    if (this.currentActionRoute === 'novo') {
      this.criarEntidade();
    } else {
      this.atualizarEntidade();
    }
  }

  public podeIncluir(url?: string) {
    if (this.login) {
      if (this.administrador()) {
        return true;
      }
      if (!url) {
        url = this.baseResourceService.retornarRota();
      }
      if (url.lastIndexOf('/') > 0 && (url.includes('editar') || url.includes('visualizar') || url.includes('novo'))) {
        const idx = url.indexOf('/'.concat(url.includes('editar') ? 'editar' : url.includes('visualizar') ? 'visualizar' : 'novo'));
        url = url.substring(0, idx);
        if (url.substring(1, url.length).lastIndexOf('/') > 0) {
          url = url.substring(0, url.substring(1, url.length).lastIndexOf('/') + 1);
        }
      }
      for (const acesso of this.login.acessos) {
        if (url === acesso.pagina) {
          return acesso.permissao === 2;
        }
      }
    }
    return false;
  }

  administrador() {
    if (this.admin === null || this.admin === undefined) {
      this.admin = new FuncaoService().campoJsonToken(this.login.token, 'administrador') == true;
    }
    return this.admin;
  }

  protected setCurrentActionRoute() {
    this.currentActionRoute = undefined;
    for (const url of this.activatedRoute.snapshot.url) {
      if (url.path === 'novo' || url.path === 'editar' || url.path === 'visualizar') {
        this.currentActionRoute = url.path === 'novo' ? 'novo' : 'editar';
        break;
      }
    }
    if (!this.currentActionRoute) {
      const paramUrl = this.activatedRoute.snapshot.url[this.activatedRoute.snapshot.url.length - 1];
      if (paramUrl && paramUrl.path === 'novo') {
        this.currentActionRoute = 'novo';
      } else {
        this.currentActionRoute = 'editar';
      }
    }
  }

  protected async loadResource() {
    if (this.currentActionRoute === 'editar') {

      this.activatedRoute
        .paramMap
        .pipe(switchMap(params => this.baseResourceService.obter(
          Object.assign({}, { id: +params.get('id') }, this.parametrosExtras())
        )))
        .pipe(takeUntil(this.unsubscribe))
        .subscribe(
          (entidade) => {
            if (entidade) {
              this.entidade = entidade;
              this.afterLoad();
              if (!this.readOnly) {

                this.entidadeForm.patchValue(entidade);
              }
            } else {
              this.sair();
            }
          }, (error) => {
            this.sair();
          });
    }
  }

  protected setTitulo() {
    if (this.currentActionRoute === 'novo') {
      this.pagTitulo = this.criarPaginaTitulo();
    } else {
      this.pagTitulo = this.editarPaginaTitulo();
    }
  }

  protected criarPaginaTitulo(): string {
    return 'Novo';
  }

  protected editarPaginaTitulo(): string {
    return '';
  }

  protected criarEntidade() {
    if (this.readOnly) {
      toastr.error('Formulário em modo de apenas leitura');
      return;
    }
    const entidade: T = this.jsonDataToResourceFn(this.entidadeForm.value);
    this.baseResourceService
      .inserir(entidade)
      .pipe(takeUntil(this.unsubscribe))
      .subscribe(res => {
        this.submitted = false;
        this.acaoSucesso(res);
      },
        error => this.acaoErro(error));
  }

  protected atualizarEntidade() {
    if (this.readOnly) {
      toastr.error('Formulário em modo de apenas leitura');
      return;
    }
    const entidade: T = this.jsonDataToResourceFn(this.entidadeForm.value);
    this.baseResourceService
      .atualizar(entidade)
      .pipe(takeUntil(this.unsubscribe))
      .subscribe(res => {
        this.submitted = false;
        this.acaoSucesso(res);
      },
        error => this.acaoErro(error));
  }

  public podeAlterar(data: Date): boolean {
    if (!data) {
      return true;
    }
    if (this.login instanceof LoginContabil) {
      return new FuncaoService().diferencaEmDias(new Date(), new Date(data)) < this.login['dias_bloquear_alteracoes'];
    } else {
      return true;
    }
  }

  protected acaoSucesso(entidade: T) {
    this.afterSubmit(entidade);
    toastr.success(this.mensagemSucesso);
    if (!this.skipRedirect) {
      let url: string = this.baseResourceService.retornarRota();
      if (this.limparTela) { // salvar e novo
        if (url.includes('novo')) {
          const rota = this.baseResourceService.retornarRota();
          this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
            this.router.navigate([rota]));
        } else {
          this.router.navigate([this.baseResourceService.retornarRota().replace(/[0-9].*\/editar/g, 'novo')]);
        }
      } else { // salvar
        if (url.includes('novo')) {
          let params = '';
          if (url.lastIndexOf('/novo') > 0) {
            params = url.substring(url.indexOf('/novo') + +'/novo'.length);
            url = url.substring(0, url.substring(1, url.length).indexOf('/novo') + 1);
          }
          url = url + '/' + entidade.id + '/editar' + params;
          this.router.navigate([url]);
        }
      }
    }
    this.limparTela = false;
  }

  protected acaoErro(error: any) {
    console.log('Erro disparado: ', error);
    toastr.options.timeOut = 10000;
    toastr.options.closeButton = true;
    toastr.options.tapToDismiss = false;
    if (error.error && error.error.payload) {
      toastr.error(error.error.payload);
    } else {
      toastr.error('Ocorreu um erro ao processar a sua solicitação');
    }
    this.disableButton = false;

    if (error.status === 422) {
      this.serverErrorMessages = JSON.parse(error._body).errors;
    } else {
      this.serverErrorMessages = ['Falha na comunicação com o servidor. Por favor, tente mais tarde'];
    }
  }

  /**
   * Método com campo a ser incluído como foco principal
   */
  protected campoFoco(): ElementRef | AutoComplete | Calendar {
    return null;
  }

  /**
   * Método para verificação de objetos, usados em combos `<select>`
   */
  compareFn(c1: any, c2: any): boolean {
    if (c1 && c2) {
      if (c1.id && c2.id) {
        return c1.id === c2.id;
      } else if (c1.chave && c2.chave) {
        return c1.chave == c2.chave;
      } else {
        return c1 === c2;
      }
    } else {
      return false;
    }
  }

  /**
   * Método para retornar a página inicial do sistema logado em `login.usuario.sistema`
   */
  sair() {
    new FuncaoService().navegarPara(this.login.usuario.sistema, this.router);
  }

}
