import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-eddydata-lib',
  template: `
    <p>
      eddydata-lib works!
    </p>
  `,
  styles: []
})
export class EddydataLibComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
