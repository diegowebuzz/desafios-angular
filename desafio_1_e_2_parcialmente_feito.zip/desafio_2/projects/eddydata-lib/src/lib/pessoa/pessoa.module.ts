import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PessoaRoutingModule } from './pessoa-routing.module';
import { PessoaCadastroDlgComponent } from './pessoa-cadastro-dlg/pessoa-cadastro-dlg.component';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { CalendarModule } from 'primeng/calendar';
import { IMaskModule } from 'angular-imask';
import { ToastModule } from 'primeng/toast';
import { ChartModule } from 'primeng/chart';
import { InputMaskModule } from 'primeng/inputmask';
import { FormsModule } from '@angular/forms';
import { PessoaListComponent } from './pessoa-list/pessoa-list.component';
import { PessoaFormComponent } from './pessoa-form/pessoa-form.component';
import { MessageService, ConfirmationService } from 'primeng/api';
import { SharedModule } from '../util/shared.module';

@NgModule({
  declarations: [PessoaCadastroDlgComponent, PessoaListComponent, PessoaFormComponent],
  imports: [
    CommonModule,
    FormsModule,
    PessoaRoutingModule,
    SharedModule,
    AutoCompleteModule,
    CalendarModule,
    IMaskModule,
    ToastModule,
    ChartModule,
    InputMaskModule
  ],
  exports: [
    PessoaCadastroDlgComponent
  ],
  providers: [MessageService, ConfirmationService]
})
export class PessoaModule { }
