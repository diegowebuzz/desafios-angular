import { Component, ElementRef, Injector, OnInit, ViewChild } from '@angular/core';
import { Validators } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { PessoaService } from '../service/pessoa.service';
import { BaseResourceFormComponent } from '../../models/base-resource-form';
import { Pessoa } from '../../entidade/comum/pessoa.model';
import { LoginContabil } from '../../entidade/login/login-contabil';
import { FuncaoService } from '../../util/funcao.service';
import { GlobalService } from '../../util/global.service';

@Component({
  selector: 'lib-pessoa-form',
  templateUrl: './pessoa-form.component.html'
})
export class PessoaFormComponent extends BaseResourceFormComponent<Pessoa, LoginContabil> implements OnInit {
  /**
   * Declaração de variáveis
   */
  @ViewChild('tipo_') inputField: ElementRef;
  public listaTipos: Array<any>;

  /**
   * Construtor com as injeções de dependencias
   */
  constructor(
    protected injector: Injector,
    private messageService: MessageService,
    protected funcaoService: FuncaoService,
    protected globalService: GlobalService,
    protected pessoaService: PessoaService) {
    super(new Pessoa(), injector, Pessoa.converteJson, pessoaService);
  }

  // ========================================================================
  //                        MÉTODOS ABSTRAÍDOS
  // ========================================================================

  protected criarCamposForm(): void {
    this.entidadeForm = this.fb.group({
      id: [null],
      especie: [null, [Validators.required]],
      cpf_cnpj: [null, [Validators.required]],
      cartao: [0, [Validators.required]],
      sexo: [null],
      data_nascimento: [null],
      rg: [null],
      nome: [null, [Validators.required]],
      pis_pasep: [null],
      email: [null, [Validators.required]],
      telefone: [null, [Validators.required]],
      cep: [null, [Validators.required]],
      endereco: [null, [Validators.required]],
      numero: [null, [Validators.required]],
      bairro: [null, [Validators.required]],
      municipio: [null, [Validators.required]],
      cidade: [this.login.cidade, [Validators.required]],
    });
  }

  protected parametrosExtras(): {} {
    return { relations: 'cidade' };
  }

  protected afterLoad() {
  }

  protected afterInit(): void {
    this.listaTipos = this.globalService.obterListaTipoFornecedores();
  }

  protected campoFoco(): ElementRef {
    return this.inputField;
  }

  protected beforeSubmit() {
    try {
      if (this.entidadeForm.get('nome').value === '') {
        throw new Error('Informe o nome da pessoa!');
      }
      this.entidadeForm.get('pis_pasep').setValue('-');
      this.entidadeForm.get('rg').setValue('-');
      this.entidadeForm.get('sexo').setValue('N');
      this.entidadeForm.get('cidade').setValue(this.login.cidade);
    } catch (e) {
      this.messageService.add({ severity: 'error', summary: 'Validação', detail: e });
      throw e;
    }
  }

  protected afterSubmit(ent: Pessoa) {
    window.scrollTo(0, 0);
    setTimeout(() => this.inputField.nativeElement.focus());
    if (this.limparTela) {
      this.entidade.cidade = this.login.cidade;
      this.entidadeForm.get('cidade').setValue(this.login.cidade);
      this.router.navigate(['/pessoas', 'novo']);
    }
  }

  // ========================================================================
  //                            MÉTODOS DA CLASSE
  // ========================================================================


}
