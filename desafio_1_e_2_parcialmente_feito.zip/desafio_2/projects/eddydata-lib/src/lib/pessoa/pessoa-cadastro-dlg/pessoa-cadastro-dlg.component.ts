import { Component, Input, OnDestroy, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import * as toastr from 'toastr';
import { PessoaService } from '../service/pessoa.service';
import { Login } from '../../entidade/login/login';
import { Pessoa } from '../../entidade/comum/pessoa.model';
import { GlobalService } from '../../util/global.service';
import { FuncaoService } from '../../util/funcao.service';

declare var $: any;

@Component({
  selector: 'lib-pessoa-cadastro-dlg',
  templateUrl: './pessoa-cadastro-dlg.component.html'
})
export class PessoaCadastroDlgComponent implements OnInit, OnDestroy {

  @ViewChild('f') formGroup: any;
  @Input() login: Login;
  @Input() entity: Pessoa = new Pessoa();

  public listaTipos: Array<any>;
  protected unsubscribe: Subject<void> = new Subject();
  public encontrado = false;

  constructor(
    protected globalService: GlobalService,
    protected funcaoService: FuncaoService,
    protected pessoaService: PessoaService,
  ) { }

  ngOnInit() {
    this.listaTipos = this.globalService.obterListaTipoFornecedores();
    this.entity = new Pessoa();
    this.entity.especie = '2';
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  public buscar() {
    if (this.entity.cpf_cnpj) {
      this.encontrado = false;
      this.pessoaService.filtrar(0, 0, { cpf_cnpj: this.entity.cpf_cnpj, cidade_id: this.login.cidade.id })
        .pipe(takeUntil(this.unsubscribe)).subscribe((res) => {
          if (res.content && res.content[0]) {
            this.entity = res.content[0];
            this.encontrado = true;
          }
        });
    }
  }

  public salvar() {
    try {
      if (!this.entity.nome) {
        throw new Error('Informe o nome!');
      }
      if (!this.entity.endereco) {
        throw new Error('Informe o endereço!');
      }
      if (!this.entity.numero) {
        throw new Error('Informe o número!');
      }
      if (!this.entity.municipio) {
        throw new Error('Informe o município!');
      }
      if (!this.entity.bairro) {
        throw new Error('Informe o bairro!');
      }
      if (!this.entity.cpf_cnpj && this.entity.especie === '2') {
        throw new Error('Informe o CPF!');
      }
      if (!this.entity.cpf_cnpj && this.entity.especie === '1') {
        throw new Error('Informe o CNPJ!');
      }
      if (!this.entity.cpf_cnpj && this.entity.especie !== '1' && this.entity.especie !== '2') {
        throw new Error('Informe a inscrição!');
      }

      this.entity.cartao = !this.entity.cartao ? 0 : this.entity.cartao;
      this.entity.pis_pasep = !this.entity.pis_pasep ? '-' : this.entity.pis_pasep;
      this.entity.rg = !this.entity.rg ? '-' : this.entity.rg;
      this.entity.sexo = !this.entity.sexo ? 'N' : this.entity.sexo;
      this.entity.cidade = !this.entity.cidade ? this.login.cidade : this.entity.cidade;

      if (this.encontrado) {
        this.pessoaService.atualizar(this.entity).pipe(takeUntil(this.unsubscribe))
          .subscribe((res) => {
            this.entity = res;
            toastr.success('Registro salvo com sucesso');
            $('#dialogPessoa').modal('hide');
          });
      } else {
        this.pessoaService.inserir(this.entity).pipe(takeUntil(this.unsubscribe))
          .subscribe((res) => {
            this.entity = res;
            toastr.success('Registro inserido com sucesso');
            $('#dialogPessoa').modal('hide');
          });
      }
    } catch (e) {
      toastr.error(e.message, 'Validação');
      throw e;
    }
  }

}
