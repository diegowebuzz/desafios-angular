import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PessoaListComponent } from './pessoa-list/pessoa-list.component';
import { PessoaFormComponent } from './pessoa-form/pessoa-form.component';
import { AuthGuard } from '../util/auth.guard';

const routes: Routes = [
  { path: '', component: PessoaListComponent, canActivate: [AuthGuard] },
  { path: 'novo', component: PessoaFormComponent, canActivate: [AuthGuard] },
  { path: ':id/editar', component: PessoaFormComponent, canActivate: [AuthGuard] }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PessoaRoutingModule { }
