import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from 'eddydata-lib';
import { EmpresaFormComponent } from './formulario/empresa-form.component';
import { EmpresaListComponent } from './listagem/empresa-list.component';

const routes: Routes = [
  { path: '', component: EmpresaListComponent, canActivate: [AuthGuard] },
  { path: 'novo', component: EmpresaFormComponent, canActivate: [AuthGuard] }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EmpresaRoutingModule { }
