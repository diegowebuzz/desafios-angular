import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { SharedModule } from 'eddydata-lib';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { EmpresaFormComponent } from './formulario/empresa-form.component';
import { EmpresaFormModule } from './formulario/empresa-form.module';
import { EmpresaRoutingModule } from './empresa-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SharedModule,

    ToastModule
  ],
  exports: [
    
  ],
 
    providers: [MessageService, ConfirmationService]
})
export class EmpresaModule { }
