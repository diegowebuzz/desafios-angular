import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { LOCALE_ID, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {
  AuthGuard, AuthGuardFake, LoaderInterceptorService,
  NofificationService, SharedModule
} from 'eddydata-lib';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { InicioComponent } from './inicio/inicio.component';
import { LoginModeloModule } from './login/login-modelo/login-modelo.module';
import { LoginRecuperarSenhaSucessoModule } from './login/login-recuperar-senha-sucesso/login-recuperar-senha-sucesso.module';
import { LoginRecuperarSenhaModule } from './login/login-recuperar-senha/login-recuperar-senha.module';
import { LoginRegistroModule } from './login/login-registro/login-registro.module';
import { NavbarModule } from './navbar/navbar.module';
import { SidebarComponent } from './sidebar/sidebar.component';

@NgModule({
  declarations: [
    AppComponent,
    SidebarComponent,
    InicioComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SharedModule,
    NavbarModule,
    LoginModeloModule,
    LoginRegistroModule,
    LoginRecuperarSenhaModule,
    LoginRecuperarSenhaSucessoModule
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'pt' },
  { provide: LocationStrategy, useClass: HashLocationStrategy },
    AuthGuard, AuthGuardFake, {
    provide: HTTP_INTERCEPTORS,
    useClass: LoaderInterceptorService,
    multi: true
  }, NofificationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
