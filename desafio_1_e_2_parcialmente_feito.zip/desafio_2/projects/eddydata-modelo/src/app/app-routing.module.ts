import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard, LoginRegistroComponent } from 'eddydata-lib';
import { InicioComponent } from './inicio/inicio.component';
import { LoginModeloComponent } from './login/login-modelo/login-modelo.component';
import { LoginRecuperarSenhaSucessoComponent } from './login/login-recuperar-senha-sucesso/login-recuperar-senha-sucesso.component';
import { LoginRecuperarSenhaComponent } from './login/login-recuperar-senha/login-recuperar-senha.component';

const routes: Routes = [
  { path: '', component: InicioComponent, canActivate: [AuthGuard] },
  { path: 'login', component: LoginModeloComponent },
  { path: 'registro', component: LoginRegistroComponent },
  { path: 'recuperar-senha', component: LoginRecuperarSenhaComponent },
  { path: 'recuperar-senha-sucesso', component: LoginRecuperarSenhaSucessoComponent },



  
  {
    path: 'empresas', canActivate: [AuthGuard],
    loadChildren: () => import('./empresa/listagem/empresa-list.module').then(m => m.EmpresaListModule)
},
{
  path: 'empresas/:id/editar', canActivate: [AuthGuard],
  loadChildren: () => import('./empresa/formulario/empresa-form.module').then(m => m.EmpresaFormModule)
},
{
  path: 'empresas/novo', canActivate: [AuthGuard],
  loadChildren: () => import('./empresa/formulario/empresa-form.module').then(m => m.EmpresaFormModule)
},
{
  path: 'setores', canActivate: [AuthGuard],
  loadChildren: () => import('./setor/setor.module').then(m => m.SetorModule)
}

 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
