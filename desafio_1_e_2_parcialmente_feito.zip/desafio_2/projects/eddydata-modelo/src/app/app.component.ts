import { Component, OnInit, OnDestroy } from '@angular/core';
import { Sistemas, LoginService, GlobalService } from 'eddydata-lib';
import { PrimeNGConfig } from 'primeng/api';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {

  public mostrarMenu = true;
  public sistema: Sistemas = 'contabil';
  protected unsubscribe: Subject<void> = new Subject();

  constructor(private config: PrimeNGConfig, private authService: LoginService) {
  }

  ngOnInit() {
    this.config.setTranslation(new GlobalService().obterDataBR());
    this.authService.mostrarMenuEmitter.pipe(takeUntil(this.unsubscribe))
      .subscribe(
        (mostrar: boolean) => {
          this.mostrarMenu = mostrar;
        }
      );

    this.authService.sistemaEmitter.pipe(takeUntil(this.unsubscribe))
      .subscribe(
        (sistema: Sistemas) => {
          this.sistema = sistema;
        }
      );
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
